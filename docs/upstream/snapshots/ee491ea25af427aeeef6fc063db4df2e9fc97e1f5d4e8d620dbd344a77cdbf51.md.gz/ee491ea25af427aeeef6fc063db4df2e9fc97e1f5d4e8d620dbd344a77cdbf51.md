`POST https://ark.cn-beijing.volces.com/api/v3/chat/completions`

发送包含文本、图片、视频、音频等模态的消息列表，模型将生成对话中的下一条消息。

## 鉴权

本接口支持鉴权方式如下，详情请参见 [Base URL 及鉴权](https://ark.volcengine.com/region:cn-beijing/docs/base-url-and-authentication)。

* 【推荐】API Key 鉴权，请在 [API Key 管理](https://ark.volcengine.com/region:cn-beijing/apiKey) 页面，获取长效 API Key。

* 【可选】Access Key 鉴权，请在 [Access Key 管理](https://console.volcengine.com/iam/keymanage) 页面，获取 Access Key。

---

## 请求参数

### Body 参数

**messages** `object[]` `必选`  |  消息列表

不同模型支持不同类型的消息，如文本、图片、视频、音频等

系统消息 `object`

系统消息，模型需遵循的指令，包括扮演的角色、背景信息等。

**content** `string / object[]` `必选`  |  消息内容

`messages.content`

系统消息的内容，支持纯文本或多模态内容

纯文本 `string`

纯文本内容

多模态内容 `object[]`

多模态内容，支持文本、图片、视频、音频等模态内容。

文本信息 `object`

文本部分，多模态消息中文本模态的部分。

**text** `string` `必选`  |  文本内容

`messages.content.text`

文本模态部分的内容

**type** `string` `必选`  |  类型

`messages.content.type`

内容模态类型，此处固定为 `text`

图片信息 `object`

图片部分

**image_url** `object` `必选`  |  图片内容

`messages.content.image_url`

图片模态的内容。 图片输入支持**file_id、url**两个字段，需二选一传入。具体使用请参见 [图片理解说明](https://ark.volcengine.com/region:cn-beijing/docs/image-understanding)

**detail** `string`  |  图片解析粒度

`messages.content.image_url.detail`

图片解析粒度。

理解图片的精细度、不同模型默认取值及对应的具体像素区间，参见 [控制图片理解的精细度](https://ark.volcengine.com/region:cn-beijing/docs/image-understanding#bf4d9224)。可选值：`low`、`high`、`xhigh`。

**file_id** `string`  |  文件 ID

`messages.content.image_url.file_id`

文件 ID。

* 文件 ID 是通过 [Files API](https://ark.volcengine.com/region:cn-beijing/docs/upload-files-api)上传文件后返回的 id。

* **file_id** 对应的文件类型需要和 **type** 保持一致，且文件状态需要为**active**。

* **API Key** 所属项目与 **file_id** 上传时所属项目需保持一致

**image_pixel_limit** `object` `默认值 null`  |  图片像素限制

`messages.content.image_url.image_pixel_limit`

输入给模型的图片的像素范围，如不在此范围，图片会被等比例缩放至该范围。

* 生效优先级：高于 **detail** 字段，即同时配置 **detail** 与 **image_pixel_limit** 字段时，生效 **image_pixel_limit** 字段配置。

* 默认生效规则：若未设置**image_pixel_limit**，则使用 **detail** 配置的值对应的 **min_pixels** / **max_pixels** 值。

> **注意**

> 图片像素范围需在 [196, 36,000,000]，否则会直接报错。

**max_pixels** `integer`  |  最大像素

`messages.content.image_url.image_pixel_limit.max_pixels`

传入图片最大像素限制，大于此像素则等比例缩小至 `max_pixels` 字段取值以下。若未设置，则取值为 `detail` 配置的值对应的 `max_pixels` 值。

**最大值**：`9031680`

**min_pixels** `integer`  |  最小像素

`messages.content.image_url.image_pixel_limit.min_pixels`

传入图片最小像素限制，小于此像素则等比例放大至 `min_pixels` 字段取值以上。若未设置，则取值为 `detail` 配置的值对应的 `min_pixels` 值。

**最小值**：`1764`

**url** `string`  |  资源 URL

`messages.content.image_url.url`

发给模型的图片 URL。支持格式如下：

* 图片链接

* 图片的 Base64 编码

**type** `string` `必选`  |  类型

`messages.content.type`

内容模态类型，此处固定为 `image_url`

视频信息 `object`

视频部分

**type** `string` `必选`  |  类型

`messages.content.type`

内容模态类型，此处固定为 `video_url`

**video_url** `object` `必选`  |  视频内容

`messages.content.video_url`

视频消息的内容部分。 视频输入支持**file_id、url**两个字段，需二选一传入。具体使用请参见 [视频理解说明](https://ark.volcengine.com/region:cn-beijing/docs/video-understanding)

**file_id** `string`  |  文件 ID

`messages.content.video_url.file_id`

文件 ID。

* 文件 ID 是通过 [Files API](https://ark.volcengine.com/region:cn-beijing/docs/upload-files-api)上传文件后返回的 id。

* **file_id** 对应的文件类型需要和 **type** 保持一致，且文件状态需要为**active**。

* **API Key** 所属项目与 **file_id** 上传时所属项目需保持一致

**fps** `number` `默认值 1.0`  |  视频帧率

`messages.content.video_url.fps`

抽帧频率，详见 [视频理解](https://ark.volcengine.com/region:cn-beijing/docs/video-understanding)。

* 取值越高，对视频中画面变化越敏感。

* 取值越低，对视频中画面变化越迟钝，但 token 花费少，速度更快。

**取值范围**：`[0.2, 5]`

**url** `string`  |  资源 URL

`messages.content.video_url.url`

发给模型的视频 URL。支持格式如下：

* 视频链接

* 视频的 Base64 编码

音频信息 `object`

音频部分

**input_audio** `object` `必选`  |  音频内容

`messages.content.input_audio`

音频模态的内容。 音频输入支持**file_id、url、data**三个字段，需三选一传入。具体使用请参见 [音频理解](https://ark.volcengine.com/region:cn-beijing/docs/audio-understanding)

> **注意**

* > 文件大小不超过 25 MB。

* > 单次请求音频总时长不超过 120 分钟，仅统计纯音频时长，视频内嵌音频不计入统计。

* > 详细说明请参见 [音频理解](https://ark.volcengine.com/region:cn-beijing/docs/audio-understanding)。

**data** `string`  |  音频数据

`messages.content.input_audio.data`

音频内容的 Base64 编码

**file_id** `string`  |  文件 ID

`messages.content.input_audio.file_id`

文件 ID。

* 文件 ID 是通过 [Files API](https://ark.volcengine.com/region:cn-beijing/docs/upload-files-api)上传文件后返回的 id。

* **file_id** 对应的文件类型需要和 **type** 保持一致，且文件状态需要为**active**。

* **API Key** 所属项目与 **file_id** 上传时所属项目需保持一致

**format** `string`  |  音频格式

`messages.content.input_audio.format`

音频格式。当使用 **data** 时，该参数必填。支持的音频格式 `MIME` 类型如下： 纯音频格式：

* mp3：`audio/mpeg`

* wav：`audio/wav`

* aac：`audio/aac`

* m4a：`audio/mp4`

   视频内嵌音频格式：

* mp3：`audio/mpeg`

* wav：`audio/wav`

* aac：`audio/aac`

* m4a：`audio/mp4`

* pcm：`audio/L16`

* ac3：`audio/ac3`

* alac：`audio/mp4`

**url** `string`  |  资源 URL

`messages.content.input_audio.url`

音频内容的 URL

**type** `string` `必选`  |  类型

`messages.content.type`

内容模态类型，此处固定为 `input_audio`

文件信息 `object`

文件部分

**file** `object` `必选`  |  文件内容

`messages.content.file`

文件模态的内容，当前仅支持 PDF 文件。 文件输入支持**file_id、file_data、file_url**三个字段，需三选一传入。多模态理解示例见 [文档理解](https://ark.volcengine.com/region:cn-beijing/docs/document-understanding)

> **说明**

> 文档理解详细说明请参见 [文档理解](https://ark.volcengine.com/region:cn-beijing/docs/document-understanding)。

**file_data** `string`  |  文件数据

`messages.content.file.file_data`

文件内容的 Base64 编码。单个文件大小要求不超过 50 MB

**file_id** `string`  |  文件 ID

`messages.content.file.file_id`

文件 ID。

* 文件 ID 是通过 [Files API](https://ark.volcengine.com/region:cn-beijing/docs/upload-files-api)上传文件后返回的 id。

* **file_id** 对应的文件类型需要和 **type** 保持一致，且文件状态需要为**active**。

* **API Key** 所属项目与 **file_id** 上传时所属项目需保持一致

**file_url** `string`  |  资源 URL

`messages.content.file.file_url`

文件的可访问 URL。对应文件的大小要求不超过 50 MB

**filename** `string`  |  文件名

`messages.content.file.filename`

文件名。当使用 **file_data** 时该参数必填

**type** `string` `必选`  |  类型

`messages.content.type`

消息模态，此处固定为 `file`

**role** `string` `必选`  |  角色

`messages.role`

发送消息的角色

取值固定为 `system`。

**name** `string`  |  参与者名称

`messages.name`

参与者名称，帮助模型区分不同的参与者

用户消息 `object`

用户消息，用户角色发送的消息。不同模型支持的字段类型不同。

**role** `string` `必选`  |  角色

`messages.role`

发送消息的角色

取值固定为 `user`。

**content** `string / object[]`  |  消息内容

`messages.content`

用户消息的内容，支持纯文本或多模态内容。省略、传入 `null` 或传入空内容时，服务端会按空字符串处理。

纯文本 `string`

纯文本内容

多模态内容 `object[]`

多模态内容，支持文本、图片、视频、音频等模态内容。

文本信息 `object`

文本部分，多模态消息中文本模态的部分。

**text** `string` `必选`  |  文本内容

`messages.content.text`

文本模态部分的内容

**type** `string` `必选`  |  类型

`messages.content.type`

内容模态类型，此处固定为 `text`

图片信息 `object`

图片部分

**image_url** `object` `必选`  |  图片内容

`messages.content.image_url`

图片模态的内容。 图片输入支持**file_id、url**两个字段，需二选一传入。具体使用请参见 [图片理解说明](https://ark.volcengine.com/region:cn-beijing/docs/image-understanding)

**detail** `string`  |  图片解析粒度

`messages.content.image_url.detail`

图片解析粒度。

理解图片的精细度、不同模型默认取值及对应的具体像素区间，参见 [控制图片理解的精细度](https://ark.volcengine.com/region:cn-beijing/docs/image-understanding#bf4d9224)。可选值：`low`、`high`、`xhigh`。

**file_id** `string`  |  文件 ID

`messages.content.image_url.file_id`

文件 ID。

* 文件 ID 是通过 [Files API](https://ark.volcengine.com/region:cn-beijing/docs/upload-files-api)上传文件后返回的 id。

* **file_id** 对应的文件类型需要和 **type** 保持一致，且文件状态需要为**active**。

* **API Key** 所属项目与 **file_id** 上传时所属项目需保持一致

**image_pixel_limit** `object` `默认值 null`  |  图片像素限制

`messages.content.image_url.image_pixel_limit`

输入给模型的图片的像素范围，如不在此范围，图片会被等比例缩放至该范围。

* 生效优先级：高于 **detail** 字段，即同时配置 **detail** 与 **image_pixel_limit** 字段时，生效 **image_pixel_limit** 字段配置。

* 默认生效规则：若未设置**image_pixel_limit**，则使用 **detail** 配置的值对应的 **min_pixels** / **max_pixels** 值。

> **注意**

> 图片像素范围需在 [196, 36,000,000]，否则会直接报错。

**max_pixels** `integer`  |  最大像素

`messages.content.image_url.image_pixel_limit.max_pixels`

传入图片最大像素限制，大于此像素则等比例缩小至 `max_pixels` 字段取值以下。若未设置，则取值为 `detail` 配置的值对应的 `max_pixels` 值。

**最大值**：`9031680`

**min_pixels** `integer`  |  最小像素

`messages.content.image_url.image_pixel_limit.min_pixels`

传入图片最小像素限制，小于此像素则等比例放大至 `min_pixels` 字段取值以上。若未设置，则取值为 `detail` 配置的值对应的 `min_pixels` 值。

**最小值**：`1764`

**url** `string`  |  资源 URL

`messages.content.image_url.url`

发给模型的图片 URL。支持格式如下：

* 图片链接

* 图片的 Base64 编码

**type** `string` `必选`  |  类型

`messages.content.type`

内容模态类型，此处固定为 `image_url`

视频信息 `object`

视频部分

**type** `string` `必选`  |  类型

`messages.content.type`

内容模态类型，此处固定为 `video_url`

**video_url** `object` `必选`  |  视频内容

`messages.content.video_url`

视频消息的内容部分。 视频输入支持**file_id、url**两个字段，需二选一传入。具体使用请参见 [视频理解说明](https://ark.volcengine.com/region:cn-beijing/docs/video-understanding)

**file_id** `string`  |  文件 ID

`messages.content.video_url.file_id`

文件 ID。

* 文件 ID 是通过 [Files API](https://ark.volcengine.com/region:cn-beijing/docs/upload-files-api)上传文件后返回的 id。

* **file_id** 对应的文件类型需要和 **type** 保持一致，且文件状态需要为**active**。

* **API Key** 所属项目与 **file_id** 上传时所属项目需保持一致

**fps** `number` `默认值 1.0`  |  视频帧率

`messages.content.video_url.fps`

抽帧频率，详见 [视频理解](https://ark.volcengine.com/region:cn-beijing/docs/video-understanding)。

* 取值越高，对视频中画面变化越敏感。

* 取值越低，对视频中画面变化越迟钝，但 token 花费少，速度更快。

**取值范围**：`[0.2, 5]`

**url** `string`  |  资源 URL

`messages.content.video_url.url`

发给模型的视频 URL。支持格式如下：

* 视频链接

* 视频的 Base64 编码

音频信息 `object`

音频部分

**input_audio** `object` `必选`  |  音频内容

`messages.content.input_audio`

音频模态的内容。 音频输入支持**file_id、url、data**三个字段，需三选一传入。具体使用请参见 [音频理解](https://ark.volcengine.com/region:cn-beijing/docs/audio-understanding)

> **注意**

* > 文件大小不超过 25 MB。

* > 单次请求音频总时长不超过 120 分钟，仅统计纯音频时长，视频内嵌音频不计入统计。

* > 详细说明请参见 [音频理解](https://ark.volcengine.com/region:cn-beijing/docs/audio-understanding)。

**data** `string`  |  音频数据

`messages.content.input_audio.data`

音频内容的 Base64 编码

**file_id** `string`  |  文件 ID

`messages.content.input_audio.file_id`

文件 ID。

* 文件 ID 是通过 [Files API](https://ark.volcengine.com/region:cn-beijing/docs/upload-files-api)上传文件后返回的 id。

* **file_id** 对应的文件类型需要和 **type** 保持一致，且文件状态需要为**active**。

* **API Key** 所属项目与 **file_id** 上传时所属项目需保持一致

**format** `string`  |  音频格式

`messages.content.input_audio.format`

音频格式。当使用 **data** 时，该参数必填。支持的音频格式 `MIME` 类型如下： 纯音频格式：

* mp3：`audio/mpeg`

* wav：`audio/wav`

* aac：`audio/aac`

* m4a：`audio/mp4`

   视频内嵌音频格式：

* mp3：`audio/mpeg`

* wav：`audio/wav`

* aac：`audio/aac`

* m4a：`audio/mp4`

* pcm：`audio/L16`

* ac3：`audio/ac3`

* alac：`audio/mp4`

**url** `string`  |  资源 URL

`messages.content.input_audio.url`

音频内容的 URL

**type** `string` `必选`  |  类型

`messages.content.type`

内容模态类型，此处固定为 `input_audio`

文件信息 `object`

文件部分

**file** `object` `必选`  |  文件内容

`messages.content.file`

文件模态的内容，当前仅支持 PDF 文件。 文件输入支持**file_id、file_data、file_url**三个字段，需三选一传入。多模态理解示例见 [文档理解](https://ark.volcengine.com/region:cn-beijing/docs/document-understanding)

> **说明**

> 文档理解详细说明请参见 [文档理解](https://ark.volcengine.com/region:cn-beijing/docs/document-understanding)。

**file_data** `string`  |  文件数据

`messages.content.file.file_data`

文件内容的 Base64 编码。单个文件大小要求不超过 50 MB

**file_id** `string`  |  文件 ID

`messages.content.file.file_id`

文件 ID。

* 文件 ID 是通过 [Files API](https://ark.volcengine.com/region:cn-beijing/docs/upload-files-api)上传文件后返回的 id。

* **file_id** 对应的文件类型需要和 **type** 保持一致，且文件状态需要为**active**。

* **API Key** 所属项目与 **file_id** 上传时所属项目需保持一致

**file_url** `string`  |  资源 URL

`messages.content.file.file_url`

文件的可访问 URL。对应文件的大小要求不超过 50 MB

**filename** `string`  |  文件名

`messages.content.file.filename`

文件名。当使用 **file_data** 时该参数必填

**type** `string` `必选`  |  类型

`messages.content.type`

消息模态，此处固定为 `file`

**name** `string`  |  参与者名称

`messages.name`

参与者名称，帮助模型区分不同的参与者

模型消息 `object`

模型消息，历史对话中模型角色返回的消息。用以保持对话一致性，多在 [多轮对话](https://ark.volcengine.com/region:cn-beijing/docs/text-generation#f6222fec)及 [续写模式](https://ark.volcengine.com/region:cn-beijing/docs/continuation-mode)使用。

**role** `string` `必选`  |  角色

`messages.role`

发送消息的角色

取值固定为 `assistant`。

**content** `string`  |  消息内容

`messages.content`

模型消息的内容。省略、传入 `null` 或传入空内容时，服务端会按空字符串处理。

**encrypted_content** `string`  |  加密思考内容

`messages.encrypted_content`

思考内容加密原文。经加密及压缩处理后的思考内容加密原文。

在支持的模型调用时，必须回传思考内容加密原文，保证模型推理效果。

相关文档：

* [关键规则](https://ark.volcengine.com/region:cn-beijing/docs/agent-model-invocation-practice#key-rules)

* [回传思考内容加密块使用示例](https://ark.volcengine.com/region:cn-beijing/docs/agent-model-invocation-practice#encrypted-thinking-block-examples)

> **注意**

* > 回传 `encrypted_content` 内容需有效，篡改或无法还原时返回错误：`Invalid signature`。

* > `encrypted_content` 优先级高于 `reasoning_content`，回传 `encrypted_content` 时，将忽略 `reasoning_content` 内容。

**模型支持**：

* `doubao-seed-2-0-lite-260428 及后续版本`

**name** `string`  |  参与者名称

`messages.name`

参与者名称，帮助模型区分不同的参与者

**reasoning_content** `string`  |  思维链内容

`messages.reasoning_content`

模型消息中思维链内容。

**模型支持**：

* `seed 系列模型`

* `deepseek-v4-pro`

* `deepseek-v4-flash`

**tool_calls** `object[]`  |  工具调用

`messages.tool_calls`

模型消息中工具调用部分

**function** `object` `必选`  |  函数信息

`messages.tool_calls.function`

模型生成的工具调用函数信息。

**arguments** `string` `必选`  |  函数参数

`messages.tool_calls.function.arguments`

模型生成的用于调用函数的参数，JSON 格式。 模型并不总是生成有效的 JSON，并且可能会虚构出一些您的函数参数规范中未定义的参数。在调用函数之前，请在您的代码中验证这些参数是否有效

**name** `string` `必选`  |  函数名

`messages.tool_calls.function.name`

模型调用的函数名称

**type** `string` `必选`  |  类型

`messages.tool_calls.type`

工具类型，当前仅支持 `function`。

**id** `string`  |  工具调用 ID

`messages.tool_calls.id`

历史模型消息中的工具调用 ID，用于与后续工具消息的 `tool_call_id` 关联。省略或传入 `null` 时，服务端会按空字符串处理。

工具消息 `object`

工具消息，历史对话中调用工具返回的消息。工具调用场景中使用。

**role** `string` `必选`  |  角色

`messages.role`

发送消息的角色

取值固定为 `tool`。

**content** `string`  |  消息内容

`messages.content`

工具返回的消息。省略或传入 `null` 时，服务端会按空字符串处理。

**name** `string`  |  参与者名称

`messages.name`

参与者名称，帮助模型区分不同的参与者

**tool_call_id** `string`  |  工具调用 ID

`messages.tool_call_id`

工具结果关联的工具调用 ID。取值对应历史模型消息中 `tool_calls.id` 的值，用于让服务端将工具返回结果匹配到对应的工具调用。省略或传入 `null` 时，服务端会按空字符串处理。

**model** `string` `必选`  |  模型 ID

调用的模型 ID（Model ID）。[开通模型服务](https://ark.volcengine.com/region:cn-beijing/openManagement?LLM=%7B%7D&OpenTokenDrawer=false) 后可 [查询 Model ID](https://ark.volcengine.com/region:cn-beijing/docs/model-list)。

多个应用及精细管理场景，推荐使用推理接入点 ID 调用，详细请参考 [获取 Endpoint ID](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-standard)。

**frequency_penalty** `number` `默认值 0.0`  |  频率惩罚系数

如值为正，根据新 token 在文本中的出现频率对其进行惩罚，从而降低模型逐字重复的可能性。

> **注意**

* > doubao\-seed\-2.0 及后续系列、deepseek\-v4.1\-flash 都不支持该参数。

* > deepseek\-v4\-pro、deepseek\-v4\-flash 在思考模式下也不支持该参数。

* > glm\-5.3\-flash 支持该参数。

* > kimi\-k3\-1\-pro 该参数取值固定为 0.0，传入其他值会报错。

**取值范围**：`[-2.0, 2.0]`

**logit_bias** `object` `默认值 null`  |  Token 偏差

调整指定 token 在模型输出内容中出现的概率，使模型生成的内容更加符合特定的偏好。

`logit_bias` 接受一个 map。每个键为词表中的 token ID（可通过 tokenization 接口获取），每个值为该 token 的偏差值：

* 负值降低选择该 token 的可能性；`-100` 会完全禁止选择该 token。

* 正值增加选择该 token 的可能性；`100` 会导致仅可选择该 token。

示例：`{"<Token_ID>": -100}`。该参数的实际效果可能因模型而异。

> **注意**

> 带深度思考能力模型不支持该参数，即 [模型列表](https://ark.volcengine.com/region:cn-beijing/docs/model-list#32e9e053)中能力标签含"深度思考"的模型。

**取值范围**：`[-100, 100]`

**logprobs** `boolean` `默认值 false`  |  返回对数概率

是否返回输出 tokens 的对数概率。

* `false`：不返回对数概率信息。

* `true`：返回消息内容中每个输出 token 的对数概率。

> [深度思考能力模型](https://ark.volcengine.com/region:cn-beijing/docs/model-list)不支持该参数。其中，`deepseek-v4-1-flash-261017`、`deepseek-v4-1-flash-260910`、`deepseek-v4-1-flash-economy-261017`、`deepseek-v4-pro-ga-260813`、`deepseek-v4-flash-ga-260731` 支持该参数。

**max_completion_tokens** `integer`  |  最大输出长度

控制模型输出的最大长度（包括模型回答和模型思维链内容长度，单位 token）。

配置了该参数后，可以让模型输出超长内容，`max_tokens` 默认值失效，模型按需输出内容（回答和思维链），直到达到 `max_completion_tokens` 值。

不可与 `max_tokens` 参数同时设置。

> **注意**

> `deepseek-v4-1-flash-261017`、`deepseek-v4-1-flash-260910`、`deepseek-v4-1-flash-economy-261017` 模型该参数默认值 128k。支持该参数的模型及使用说明见 [文档](https://ark.volcengine.com/region:cn-beijing/docs/deep-thinking)。

**取值范围**：`[1, 65536]`

**max_tokens** `integer` `默认值 4096`  |  最大回答长度

模型回答最大长度（单位 token）。取值范围各个模型不同，详细见 [模型列表](https://ark.volcengine.com/region:cn-beijing/docs/model-list)。

> **说明**

* > `deepseek-v4-1-flash-261017`、`deepseek-v4-1-flash-260910`、`deepseek-v4-1-flash-economy-261017`：`max_tokens` 控制模型回答和模型思维链内容长度，超出长度后不报错，默认取值 128k。

* > 除上述模型的其他模型：`max_tokens` 控制模型回答长度，不包含思维链内容，模型回答 = 模型输出 \- 模型思维链（如有）

* > 输出 token 的总长度还受模型的上下文长度限制。

**parallel_tool_calls** `boolean` `默认值 true`  |  并行工具调用

本次请求，模型返回是否允许包含多个待调用的工具。

* `true`：允许返回多个待调用的工具。

* `false`：允许返回的待调用的工具小于等于 1。

**presence_penalty** `number` `默认值 0.0`  |  存在惩罚系数

如果值为正，会根据新 token 到目前为止是否出现在文本中对其进行惩罚，从而增加模型谈论新主题的可能性。

> **注意**

* > doubao\-seed\-2.0 及后续系列、deepseek\-v4.1\-flash 都不支持该参数。

* > deepseek\-v4\-pro、deepseek\-v4\-flash 在思考模式下也不支持该参数。

* > glm\-5.3\-flash 支持该参数。

* > kimi\-k3\-1\-pro 该参数取值固定为 0.0，传入其他值会报错。

**取值范围**：`[-2.0, 2.0]`

**prompt_cache_key** `string`  |  缓存路由标识

用于提升隐式缓存命中率的缓存路由标识。取值相同且 Endpoint、模型一致的请求会优先路由到更可能复用相同前缀缓存的服务。

* 该字段为可选路由优化，不是隐式缓存开关；省略该字段不会关闭隐式缓存。

* 上下文连续的请求使用同一取值；不同用户或并行会话使用不同取值。

* 同一取值对应的请求总流量建议控制在每分钟 15 个请求以内。超过该范围时，部分请求可能回退到常规路由。

* 使用不可读的内部 Session ID，避免传入手机号、邮箱、访问凭证或 Prompt 原文。

* 服务扩缩容、发布、故障切换、映射过期或保护策略触发时，请求可能重新路由，因此该字段无法保证每次请求都命中缓存。

**reasoning_effort** `string`  |  思考深度

限制思考的工作量。减少思考深度可提升速度，思考花费的 token 更少。

* `none`：关闭思考。

* `minimal`：关闭思考，直接回答。

* `low`：轻量思考，侧重快速响应。

* `medium`：均衡模式，兼顾速度与深度。

* `high`：深度分析，处理复杂问题。

* `xhigh`：更高程度思考。

* `max`：最高程度思考，适配高难度推理任务。

> **说明**

> 支持该字段的模型、默认取值、参数兼容映射规则，以及与 `thinking.type` 字段的关系，详见 [文档](https://ark.volcengine.com/region:cn-beijing/docs/deep-thinking)。

**response_format** `object`  |  回答格式

指定模型回答格式。默认值：`{"type": "text"}`

> **注意**

* > 支持该参数的模型请参见 [文档](https://ark.volcengine.com/region:cn-beijing/docs/structured-output-beta#3aae5325)。

* > 该能力尚在 beta 阶段，请谨慎在生产环境使用。

**json_schema** `object`  |  Schema 配置

`response_format.json_schema`

JSON 结构体的定义

**name** `string` `必选`  |  Schema 名称

`response_format.json_schema.name`

JSON Schema 的名称，用于标识本次响应格式

**schema** `object` `必选`  |  Schema 定义

`response_format.json_schema.schema`

回答格式的 JSON Schema 定义

**description** `string`  |  描述

`response_format.json_schema.description`

回答用途说明，模型据此判断如何按该格式生成回答

**strict** `boolean` `默认值 false`  |  严格模式

`response_format.json_schema.strict`

是否在生成输出时，启用严格遵循模式。

* `true`：模型将始终严格遵循 `schema` 字段中定义的格式。

* `false`：模型会尽可能遵循 `schema` 字段中定义的结构。

**type** `string`  |  类型

`response_format.type`

回答格式类型。可选值：`text`、`json_schema`、`json_object`。

**service_tier** `string`  |  推理模式

控制使用的在线推理模式。

* `fast`：本次请求优先使用 [在线推理（低延迟）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-low-latency) 模式。

   * 推理接入点（`model` 字段指定）有低延迟限流配额，本次请求将会优先使用低延迟限流配额，获得更高的服务等级（延迟、可用性等）。

   * 推理接入点无低延迟限流配额，或者限流配额已满，降级至 **在线推理（常规）**  模式，维持常规的服务等级。

* `auto`：本次请求优先使用 [在线推理（TPM 保障包）](https://ark.volcengine.com/region:cn-beijing/docs/tpm-guarantee-package) 模式。

   * 推理接入点有 TPM 保障包额度，本次请求将会优先使用 TPM 保障包额度，获得最高的服务等级。

   * 推理接入点无 TPM 保障包额度或用超额度，降级至 **在线推理（常规）**  模式，维持常规的服务等级。

* `default`：本次请求只使用 [在线推理（常规）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-standard) 模式，维持常规的服务等级。

   * 即使调用的推理接入点有 TPM 保障包额度 / 低延迟限流额度，也只使用在线推理（常规）模式。

* `flex`：本次请求使用 [在线推理（低优）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-flex) 模式。

**stop** `string / string[]` `默认值 null`  |  停止词

模型遇到 `stop` 字段所指定的字符串时将停止继续生成，这个词语本身不会输出。

* 默认最多支持 `4` 个停止词。

* DeepSeek V4 系列模型最多支持 `16` 个停止词。

* Kimi 系列模型最多支持 `5` 个停止词。

示例：`["你好", "天气"]`。

> [深度思考能力模型](https://ark.volcengine.com/region:cn-beijing/docs/model-list#32e9e053)默认不支持该参数；上述 DeepSeek V4 系列模型和 Kimi 系列模型除外。

**stream** `boolean` `默认值 false`  |  流式返回

响应内容是否流式返回。

* `false`：模型生成完所有内容后一次性返回结果。

* `true`：按 SSE 协议逐块返回模型生成内容，并以一条 `data: [DONE]` 消息结束。当 `stream` 为 `true` 时，可设置 `stream_options` 参数以获取 token 用量统计信息。

**stream_options** `object` `默认值 null`  |  流式选项

流式响应的选项。当 `stream` 为 `true` 时，可设置本参数。

**chunk_include_usage** `boolean` `默认值 false`  |  逐块用量信息

`stream_options.chunk_include_usage`

模型流式输出时，输出的每个 chunk 中是否输出本次请求到此 chunk 输出时刻的累计 token 用量信息。

* `true`：在返回的 `usage` 字段中，输出本次请求到此 chunk 输出时刻的累计 token 用量。

* `false`：不在每个 chunk 都返回 token 用量信息。

**include_usage** `boolean` `默认值 false`  |  输出用量信息

`stream_options.include_usage`

模型流式输出时，是否在输出结束前输出本次请求的 token 用量信息。

* `true`：在 `data: [DONE]` 消息之前会返回一个额外的 chunk。此 chunk 中，`usage` 字段中输出整个请求的 token 用量，`choices` 字段为空数组。

* `false`：输出结束前，没有一个 chunk 来返回 token 用量信息。

> **说明**

> `deepseek-v4-1-flash-261017`、`deepseek-v4-1-flash-economy-261017` 模型不支持通过该参数控制用量信息的返回方式。上述模型默认在带有 `finish_reason` 的 chunk 中返回本次请求的 `usage` 信息，不额外返回独立的用量信息 chunk。

**temperature** `number` `默认值 1.0`  |  采样温度

控制了生成文本时对每个候选词的概率分布进行平滑的程度。当取值为 0 时模型仅考虑对数概率最大的一个 token。

较高的值（如 0.8）会使输出更加随机，而较低的值（如 0.2）会使输出更加集中确定。

通常建议仅调整 `temperature` 或 `top_p` 其中之一，不建议两者都修改。

> **注意**

* > `doubao-seed-2-0-pro-260215`、`doubao-seed-2-0-lite-260215` 模型 **temperature** 参数取值固定为 `1.0`，手动指定的参数值将被忽略。

* > `kimi-k3-1-pro-261024` 模型 **temperature** 参数取值固定为 `1.0`，传入其他取值会报错。

**取值范围**：`[0, 2]`

**thinking** `object`  |  深度思考开关

控制模型是否开启深度思考模式。

> **注意**

> 不同模型是否支持以及默认取值不同，详情请查询 [文档](https://ark.volcengine.com/region:cn-beijing/docs/deep-thinking#14b5c6db)。

**type** `string`  |  类型

`thinking.type`

控制模型是否开启思考模式。

* `enabled`：开启思考模式，模型强制先思考再回答。

* `disabled`：关闭思考模式，模型直接回答问题，不进行思考。

**tool_choice** `string / object`  |  工具调用控制

本次请求，模型返回信息中是否有待调用的工具。

* `none`：模型不会调用工具，直接生成消息。当没有指定工具时，`none` 是默认值。

* `auto`：模型可以选择生成消息或调用工具。如果存在工具，则 `auto` 是默认值。

* `required`：模型必须调用一个或多个工具。

您也可以通过设置 `tool_choice` 为 object 类型，来强制模型调用指定工具。

枚举值 `string`

控制模型返回是否包含待调用的工具。

* `none`：模型返回信息中不可含有待调用的工具。

* `required`：模型返回信息中必须含待调用的工具。选择此项时请确认存在适合的工具，以减少模型产生幻觉的情况。

* `auto`：模型自行判断返回信息是否有待调用的工具。

指定工具 `object`

指定待调用工具的范围。模型返回信息中，只允许包含以下模型信息。

选择此项时请确认该工具适合用户需求，以减少模型产生幻觉的情况。

**function** `object` `必选`  |  函数信息

`tool_choice.function`

调用工具的信息

**name** `string` `必选`  |  函数名

`tool_choice.function.name`

要调用的函数名称

**type** `string` `必选`  |  类型

`tool_choice.type`

调用的类型，此处应为 `function`

**tools** `object[]` `默认值 null`  |  工具列表

待调用工具的列表，模型返回信息中可包含。

当您需要让模型返回待调用工具时，需要配置该结构体。支持该参数的模型请参见 [文档](https://ark.volcengine.com/region:cn-beijing/docs/model-list#f44ceef7)。

**function** `object` `必选`  |  函数信息

`tools.function`

模型返回中可包含待调用的工具

**name** `string` `必选`  |  函数名

`tools.function.name`

工具（函数）名称，供模型识别与调用

**description** `string`  |  描述

`tools.function.description`

调用的函数的描述，大模型会使用它来判断是否调用这个工具

**parameters** `object`  |  参数定义

`tools.function.parameters`

函数请求参数，以 JSON Schema 格式描述。具体格式请参考 [JSON Schema](https://json-schema.org/understanding-json-schema) 文档。

格式如下：

```JSON
{ "type": "object", "properties": { "参数名": { "type": "string | number | boolean | object | array", "description": "参数说明" } }, "required": ["必填参数"] }
```

使用要点：所有字段名大小写敏感；`parameters` 须是合规的 JSON Schema 对象；建议用英文字段名，中文置于 `description` 字段中。

**strict** `boolean`  |  严格模式

`tools.function.strict`

是否启用严格的 Schema 校验，确保模型生成的函数调用参数严格符合 `parameters` 定义。

**type** `string` `必选`  |  类型

`tools.type`

工具类型，此处应为 `function`

**top_logprobs** `integer` `默认值 0`  |  返回概率数量

指定每个输出 token 位置最有可能返回的 token 数量，每个 token 都有关联的对数概率。

> **注意**

* > 仅当 `logprobs=true` 时可以设置本参数。

* > [深度思考能力模型](https://ark.volcengine.com/region:cn-beijing/docs/model-list)不支持该参数。其中，`deepseek-v4-1-flash-261017`、`deepseek-v4-1-flash-260910`、`deepseek-v4-1-flash-economy-261017`、`deepseek-v4-pro-ga-260813`、`deepseek-v4-flash-ga-260731` 支持该参数。

**取值范围**：`[0, 20]`

**top_p** `number` `默认值 0.7`  |  核采样阈值

核采样概率阈值。模型会考虑概率质量在 `top_p` 内的 token 结果。

当取值为 0 时模型仅考虑对数概率最大的一个 token。0.1 意味着只考虑概率质量最高的前 10% 的 token，取值越大生成的随机性越高，取值越低生成的确定性越高。

通常建议仅调整 `temperature` 或 `top_p` 其中之一，不建议两者都修改。

> **注意**

* > `doubao-seed-2-0-pro-260215`、`doubao-seed-2-0-lite-260215` 模型 top_p 参数取值固定为 `0.95`，手动指定的参数值将被忽略。

* > `kimi-k3-1-pro-261024` 模型 top_p 参数取值固定为 `0.95`，传入其他值会报错。

* > `glm-5-3-flash-260828` 模型默认值为 `0.95`。

* > `deepseek-v4-1-flash-261017`、`deepseek-v4-1-flash-260910`、`deepseek-v4-1-flash-economy-261017` 模型 top_p 参数取值规则如下：

   * > 思考模式：参数生效。不传该参数时，使用 tool 时默认值为 0.95，其他情况默认值为 1。

      * <div data-tips="true" data-tips-type="warning">传入值 < 0.95：系统自动提升至 0.95。</div>

      * > 传入值 ≥ 0.95：按实际传入值使用。

   * > 非思考模式：参数取值固定为 1.0，传入的值将被忽略。

**取值范围**：`[0, 1]`

**web_search_options** `object`  |  联网搜索配置

Chat API 的联网搜索配置。当前仅支持豆包搜索 Custom 版。

支持联网搜索的模型、搜索源开通状态和鉴权条件均满足时，系统会在一次请求内由模型自行决定是否发起搜索，并在拿到搜索结果后继续生成最终回答。

> **说明**

* > `web_search_options` 仅用于启用 Chat API 内置联网搜索能力。传入 `{}` 或包含任意子参数的 object 都会触发搜索准入判定。

* > `web_search_options` 缺省、传入 `null` 或传入非 object 时，系统会静默忽略该参数，不会新增报错。

* > 如果请求同时携带 `tools` 与 `web_search_options`，系统会优先保留用户自定义工具，联网搜索不会生效。

**search_context_size** `string`  |  搜索上下文量

`web_search_options.search_context_size`

该参数不生效。可选值：`low`、`medium`、`high`。

**user_location** `object`  |  用户位置

`web_search_options.user_location`

该参数不生效。

**approximate** `object`  |  粗略位置

`web_search_options.user_location.approximate`

用户的粗略地理位置信息。

**city** `string`  |  城市

`web_search_options.user_location.approximate.city`

用户所在城市。

**country** `string`  |  国家

`web_search_options.user_location.approximate.country`

用户所在国家的两位 ISO 代码。

**region** `string`  |  地区

`web_search_options.user_location.approximate.region`

用户所在地区。

**timezone** `string`  |  时区

`web_search_options.user_location.approximate.timezone`

用户所在时区，使用 IANA 时区标识。

**type** `string`  |  类型

`web_search_options.user_location.type`

位置类型。当前固定使用 `approximate`。

## 响应参数

### 非流式调用响应

**choices** `object[]`  |  生成结果

本次请求的模型输出内容

**finish_reason** `string`  |  结束原因

`choices.finish_reason`

模型停止生成 token 的原因。

* `stop`：模型输出自然结束，或因命中请求参数 `stop` 中指定的字段而被截断。

* `length`：模型输出因达到模型输出限制而被截断，有以下原因：

   * 触发 `max_tokens` 限制（回答内容的长度限制）。

   * 触发 `max_completion_tokens` 限制（思维链内容 + 回答内容的长度限制）。

   * 触发 `context_window` 限制（输入内容 + 思维链内容 + 回答内容的长度限制）。

* `content_filter`：模型输出被内容审核拦截。

* `tool_calls`：模型调用了工具。

**index** `integer`  |  序号

`choices.index`

当前元素在 **choices** 列表的索引

**logprobs** `object`  |  选项对数概率详情

`choices.logprobs`

当前内容的对数概率信息

**content** `object[]`  |  消息内容

`choices.logprobs.content`

message 列表中每个 content 元素中的 token 对数概率信息

**bytes** `integer[]`  |  字节

`choices.logprobs.content.bytes`

当前 token 的 UTF\-8 值，格式为整数列表。当一个字符由多个 token 组成（表情符号或特殊字符等）时可以用于字符的编码和解码。如果 token 没有 UTF\-8 值则为空

**logprob** `number`  |  对数概率值

`choices.logprobs.content.logprob`

当前 token 的对数概率

**token** `string`  |  Token

`choices.logprobs.content.token`

当前 token

**top_logprobs** `object[]`  |  候选概率

`choices.logprobs.content.top_logprobs`

在当前 token 位置最有可能的标记及其对数概率的列表。在一些情况下，返回的数量可能比请求参数 top_logprobs 指定的数量要少

**bytes** `integer[]`  |  字节

`choices.logprobs.content.top_logprobs.bytes`

当前 token 的 UTF\-8 值，格式为整数列表。当一个字符由多个 token 组成（表情符号或特殊字符等）时可以用于字符的编码和解码。如果 token 没有 UTF\-8 值则为空

**logprob** `number`  |  对数概率值

`choices.logprobs.content.top_logprobs.logprob`

当前 token 的对数概率

**token** `string`  |  Token

`choices.logprobs.content.top_logprobs.token`

当前 token

**message** `object`  |  消息

`choices.message`

模型输出的内容

**content** `string`  |  消息内容

`choices.message.content`

模型生成的消息内容

**role** `string`  |  角色

`choices.message.role`

内容输出的角色，此处固定为 `assistant`

**annotations** `object[]`  |  引用标注

`choices.message.annotations`

联网搜索引用标注列表。

仅当请求通过 `web_search_options` 触发联网搜索，且最终回答引用了搜索结果时返回。系统会对引用结果去重后返回。

> **说明**

* > 当前仅支持返回 `url_citation` 类型的引用标注。

* > 当前不支持返回 `start_index`、`end_index` 等文本位置字段。

**type** `string`  |  类型

`choices.message.annotations.type`

引用标注类型。当前固定为 `url_citation`。

**url_citation** `object`  |  URL 引用

`choices.message.annotations.url_citation`

URL 引用详情。

**title** `string`  |  标题

`choices.message.annotations.url_citation.title`

引用来源标题。

**url** `string`  |  链接

`choices.message.annotations.url_citation.url`

引用来源链接。

**encrypted_content** `string`  |  加密思考内容

`choices.message.encrypted_content`

思考内容加密原文。经加密及压缩处理后的思考内容原文。

相关文档：

* [关键规则](https://ark.volcengine.com/region:cn-beijing/docs/agent-model-invocation-practice#key-rules)

* [回传思考内容加密块使用示例](https://ark.volcengine.com/region:cn-beijing/docs/agent-model-invocation-practice#encrypted-thinking-block-examples)

**模型支持**：

* `doubao-seed-2-0-lite-260428 及后续版本`

**reasoning_content** `string`  |  思维链内容

`choices.message.reasoning_content`

模型处理问题的思维链内容。

**模型支持**：

* `seed 系列模型`

* `deepseek-v4-pro`

* `deepseek-v4-flash`

**tool_calls** `object[]`  |  工具调用

`choices.message.tool_calls`

模型生成的工具调用

**function** `object`  |  函数信息

`choices.message.tool_calls.function`

模型调用的函数

**arguments** `string`  |  函数参数

`choices.message.tool_calls.function.arguments`

模型生成的用于调用函数的参数，JSON 格式。 模型并不总是生成有效的 JSON，并且可能会虚构出一些您的函数参数规范中未定义的参数。在调用函数之前，请在您的代码中验证这些参数是否有效

**name** `string`  |  函数名

`choices.message.tool_calls.function.name`

模型调用的函数名称

**id** `string`  |  ID

`choices.message.tool_calls.id`

模型生成的工具调用 ID。开发者调用工具后，需要在后续工具消息的 `tool_call_id` 中回传该值，用于关联工具返回结果与对应的工具调用。响应中该字段始终返回。

**type** `string`  |  类型

`choices.message.tool_calls.type`

工具类型，当前仅支持`function`

**moderation_hit_type** `string`  |  审核命中类型

`choices.moderation_hit_type`

模型输出文字含有敏感信息时，会返回模型输出文字命中的风险分类标签。

* `severe_violation`：模型输出文字涉及严重违规。

* `violence`：模型输出文字涉及激进行为。

> **注意**

> 注意：当前只有 [视觉理解模型](https://ark.volcengine.com/region:cn-beijing/docs/image-understanding#f8d6cc48)支持返回该字段，且只有在方舟控制台 [接入点配置页面](https://ark.volcengine.com/region:cn-beijing/endpoint/create?customModelId=) 或者 CreateEndpoint 接口中，将内容护栏方案（ModerationStrategy）设置为基础方案（Basic）时，才会返回风险分类标签。

**created** `integer`  |  创建时间

本次请求创建时间的 Unix 时间戳（秒）

**id** `string`  |  请求 ID

本次请求的唯一标识

**model** `string`  |  模型名称

本次请求实际使用的模型名称和版本

**object** `string`  |  对象类型

固定为 `chat.completion`

**service_status** `object`  |  服务状态

本次请求附带的服务状态信息，例如是否触发了模型降级（fallback）

**model_fallback** `object`  |  模型降级状态

`service_status.model_fallback`

模型降级（fallback）相关的状态信息

**fallback_triggered** `boolean`  |  是否触发降级

`service_status.model_fallback.fallback_triggered`

本次请求是否触发了模型降级

**original_model** `string`  |  原始模型

`service_status.model_fallback.original_model`

触发降级前，请求最初指定的模型名称

**service_tier** `string`  |  推理模式

本次请求实际使用的推理模式。

* `scale`：本次请求使用 [在线推理（TPM 保障包）](https://ark.volcengine.com/region:cn-beijing/docs/tpm-guarantee-package) 模式。

* `default`：本次请求使用 [在线推理（常规）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-standard) 模式。

* `fast`：本次请求使用 [在线推理（低延迟）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-low-latency) 模式。

* `flex`：本次请求使用 [在线推理（低优）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-flex) 模式。

**usage** `object`  |  Token 用量

本次请求的 token 用量

**completion_tokens** `integer`  |  输出 Token 数

`usage.completion_tokens`

模型输出内容花费的 token

**completion_tokens_details** `object`  |  输出 Token 明细

`usage.completion_tokens_details`

模型输出内容花费的 token 的细节

**reasoning_tokens** `integer`  |  思维链 Token 数

`usage.completion_tokens_details.reasoning_tokens`

输出思维链内容花费的 token 数。 支持输出思维链的模型请参见 [文档](https://ark.volcengine.com/region:cn-beijing/docs/deep-thinking#14b5c6db)

**prompt_tokens** `integer`  |  输入 Token 数

`usage.prompt_tokens`

输入给模型处理的内容 token 数量

**prompt_tokens_details** `object`  |  输入 Token 明细

`usage.prompt_tokens_details`

输入给模型处理的内容 token 数量的细节

**cached_tokens** `integer`  |  缓存命中 Token 数

`usage.prompt_tokens_details.cached_tokens`

缓存命中的输入内容（含文本、音频等所有类型）所消耗的 token 总数

**audio_cached_tokens** `integer`  |  音频缓存 Token 数

`usage.prompt_tokens_details.audio_cached_tokens`

缓存命中的音频输入内容所消耗的 token 数量。仅在隐式缓存模式且命中音频缓存时返回；开启显式缓存时该字段不返回。

**audio_tokens** `integer`  |  音频 Token 数

`usage.prompt_tokens_details.audio_tokens`

音频输入内容所消耗的 token 数量

**total_tokens** `integer`  |  总 Token 数

`usage.total_tokens`

本次请求消耗的总 token 数量（输入 + 输出）

**tool_usage** `object`  |  工具用量

`usage.tool_usage`

本次请求内的工具调用次数。

**web_search** `integer`  |  联网搜索次数

`usage.tool_usage.web_search`

本次请求内实际执行的联网搜索次数。

### 流式调用响应

**choices** `object[]`  |  生成结果

本次请求的模型输出内容

**delta** `object`  |  增量消息

`choices.delta`

模型输出的增量内容

**content** `string`  |  消息内容

`choices.delta.content`

模型生成的消息内容

**encrypted_content** `string`  |  加密思考内容

`choices.delta.encrypted_content`

思考内容加密原文。经加密及压缩处理后的思考内容原文。

相关文档：

* [关键规则](https://ark.volcengine.com/region:cn-beijing/docs/agent-model-invocation-practice#key-rules)

* [回传思考内容加密块使用示例](https://ark.volcengine.com/region:cn-beijing/docs/agent-model-invocation-practice#encrypted-thinking-block-examples)

> **说明**

> 流式输出场景下，将在思考内容输出完成后、正式应答内容输出前，输出包含完整 `encrypted_content` 的数据。其中 `content` 与 `reasoning_content` 字段均为空。

**模型支持**：

* `doubao-seed-2-0-lite-260428 及后续版本`

**reasoning_content** `string`  |  思维链内容

`choices.delta.reasoning_content`

思考内容原文。

自 `doubao-seed-2-0-lite-260428` 版本起，返回思考内容摘要。

> **注意**

> 针对长文本生成、深度推理等耗时场景，建议适当调大首 Token 超时时间（TTFT）与逐 Token 生成超时时间（TPOT），避免请求因超时而中断。

**模型支持**：

* `seed 系列模型`

* `deepseek-v4-pro`

* `deepseek-v4-flash`

**role** `string`  |  角色

`choices.delta.role`

内容输出的角色，此处固定为 `assistant`

**tool_calls** `object[]`  |  工具调用

`choices.delta.tool_calls`

模型生成的工具调用

**index** `integer`  |  序号

`choices.delta.tool_calls.index`

工具调用在数组中的索引位置

**function** `object`  |  函数信息

`choices.delta.tool_calls.function`

模型调用的函数

**arguments** `string`  |  函数参数

`choices.delta.tool_calls.function.arguments`

模型生成的用于调用函数的参数，JSON 格式。 模型并不总是生成有效的 JSON，并且可能会虚构出一些您的函数参数规范中未定义的参数。在调用函数之前，请在您的代码中验证这些参数是否有效

**name** `string`  |  函数名

`choices.delta.tool_calls.function.name`

模型调用的函数名称

**id** `string`  |  ID

`choices.delta.tool_calls.id`

调用的工具的 ID

**type** `string`  |  类型

`choices.delta.tool_calls.type`

工具类型，当前仅支持`function`

**index** `integer`  |  序号

`choices.index`

当前元素在 **choices** 列表的索引

**finish_reason** `string`  |  结束原因

`choices.finish_reason`

模型停止生成 token 的原因。

* `stop`：模型输出自然结束，或因命中请求参数 `stop` 中指定的字段而被截断。

* `length`：模型输出因达到模型输出限制而被截断，有以下原因：

   * 触发 `max_tokens` 限制（回答内容的长度限制）。

   * 触发 `max_completion_tokens` 限制（思维链内容 + 回答内容的长度限制）。

   * 触发 `context_window` 限制（输入内容 + 思维链内容 + 回答内容的长度限制）。

* `content_filter`：模型输出被内容审核拦截。

* `tool_calls`：模型调用了工具。

**logprobs** `object`  |  选项对数概率详情

`choices.logprobs`

当前内容的对数概率信息

**content** `object[]`  |  消息内容

`choices.logprobs.content`

message 列表中每个 content 元素中的 token 对数概率信息

**bytes** `integer[]`  |  字节

`choices.logprobs.content.bytes`

当前 token 的 UTF\-8 值，格式为整数列表。当一个字符由多个 token 组成（表情符号或特殊字符等）时可以用于字符的编码和解码。如果 token 没有 UTF\-8 值则为空

**logprob** `number`  |  对数概率值

`choices.logprobs.content.logprob`

当前 token 的对数概率

**token** `string`  |  Token

`choices.logprobs.content.token`

当前 token

**top_logprobs** `object[]`  |  候选概率

`choices.logprobs.content.top_logprobs`

在当前 token 位置最有可能的标记及其对数概率的列表。在一些情况下，返回的数量可能比请求参数 top_logprobs 指定的数量要少

**bytes** `integer[]`  |  字节

`choices.logprobs.content.top_logprobs.bytes`

当前 token 的 UTF\-8 值，格式为整数列表。当一个字符由多个 token 组成（表情符号或特殊字符等）时可以用于字符的编码和解码。如果 token 没有 UTF\-8 值则为空

**logprob** `number`  |  对数概率值

`choices.logprobs.content.top_logprobs.logprob`

当前 token 的对数概率

**token** `string`  |  Token

`choices.logprobs.content.top_logprobs.token`

当前 token

**moderation_hit_type** `string`  |  审核命中类型

`choices.moderation_hit_type`

模型输出文字含有敏感信息时，会返回模型输出文字命中的风险分类标签。

* `severe_violation`：模型输出文字涉及严重违规。

* `violence`：模型输出文字涉及激进行为。

> **注意**

> 注意：当前只有 [视觉理解模型](https://ark.volcengine.com/region:cn-beijing/docs/image-understanding#f8d6cc48)支持返回该字段，且只有在方舟控制台 [接入点配置页面](https://ark.volcengine.com/region:cn-beijing/endpoint/create?customModelId=) 或者 CreateEndpoint 接口中，将内容护栏方案（ModerationStrategy）设置为基础方案（Basic）时，才会返回风险分类标签。

**created** `integer`  |  创建时间

本次请求创建时间的 Unix 时间戳（秒）

**id** `string`  |  请求 ID

本次请求的唯一标识

**model** `string`  |  模型名称

本次请求实际使用的模型名称和版本

**object** `string`  |  对象类型

固定为 `chat.completion.chunk`

**service_status** `object`  |  服务状态

本次请求附带的服务状态信息，例如是否触发了模型降级（fallback）

**model_fallback** `object`  |  模型降级状态

`service_status.model_fallback`

模型降级（fallback）相关的状态信息

**fallback_triggered** `boolean`  |  是否触发降级

`service_status.model_fallback.fallback_triggered`

本次请求是否触发了模型降级

**original_model** `string`  |  原始模型

`service_status.model_fallback.original_model`

触发降级前，请求最初指定的模型名称

**service_tier** `string`  |  推理模式

本次请求实际使用的推理模式。

* `scale`：本次请求使用 [在线推理（TPM 保障包）](https://ark.volcengine.com/region:cn-beijing/docs/tpm-guarantee-package) 模式。

* `default`：本次请求使用 [在线推理（常规）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-standard) 模式。

* `fast`：本次请求使用 [在线推理（低延迟）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-low-latency) 模式。

* `flex`：本次请求使用 [在线推理（低优）](https://ark.volcengine.com/region:cn-beijing/docs/online-inference-flex) 模式。

**usage** `object`  |  Token 用量

本次请求的 token 用量。

默认行为：

* 部分模型默认在输出结束前返回本次请求的 token 用量信息。适用模型：`doubao-seed-2-1-lite-260915`、`glm-5-3-flash-260828`、`glm-5-2-260617`、`deepseek-v4-1-flash-261017`、`deepseek-v4-1-flash-260910`、`deepseek-v4-1-flash-economy-261017`、`deepseek-v4-pro-ga-260813`、`deepseek-v4-flash-ga-260731`。其中，`deepseek-v4-1-flash-261017`、`deepseek-v4-1-flash-economy-261017` 默认在带有 `finish_reason` 的 chunk 中返回本次请求的 token 用量信息。

* 其他模型：默认不统计 token 用量信息，返回值为 `null`。如需统计，需设置 `stream_options.include_usage` 为 `true`。

**completion_tokens** `integer`  |  输出 Token 数

`usage.completion_tokens`

模型输出内容花费的 token

**completion_tokens_details** `object`  |  输出 Token 明细

`usage.completion_tokens_details`

模型输出内容花费的 token 的细节

**reasoning_tokens** `integer`  |  思维链 Token 数

`usage.completion_tokens_details.reasoning_tokens`

输出思维链内容花费的 token 数。 支持输出思维链的模型请参见 [文档](https://ark.volcengine.com/region:cn-beijing/docs/deep-thinking#14b5c6db)

**prompt_tokens** `integer`  |  输入 Token 数

`usage.prompt_tokens`

输入给模型处理的内容 token 数量

**prompt_tokens_details** `object`  |  输入 Token 明细

`usage.prompt_tokens_details`

输入给模型处理的内容 token 数量的细节

**cached_tokens** `integer`  |  缓存命中 Token 数

`usage.prompt_tokens_details.cached_tokens`

缓存命中的输入内容（含文本、音频等所有类型）所消耗的 token 总数

**audio_cached_tokens** `integer`  |  音频缓存 Token 数

`usage.prompt_tokens_details.audio_cached_tokens`

缓存命中的音频输入内容所消耗的 token 数量。仅在隐式缓存模式且命中音频缓存时返回；开启显式缓存时该字段不返回。

**audio_tokens** `integer`  |  音频 Token 数

`usage.prompt_tokens_details.audio_tokens`

音频输入内容所消耗的 token 数量

**total_tokens** `integer`  |  总 Token 数

`usage.total_tokens`

本次请求消耗的总 token 数量（输入 + 输出）

**tool_usage** `object`  |  工具用量

`usage.tool_usage`

本次请求内的工具调用次数。

**web_search** `integer`  |  联网搜索次数

`usage.tool_usage.web_search`

本次请求内实际执行的联网搜索次数。

```mixin-react
return (<ApiSample data={"{\"config\":{\"inputName\":\"Request\",\"outputName\":\"Response\",\"envItems\":[{\"label\":\"ARK_API_KEY\",\"value\":\"ARK_API_KEY\"}]},\"type\":\"multiple\",\"data\":[{\"title\":\"默认\",\"children\":[{\"title\":\"cURL\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"value\":[1]}},\"inputCode\":\"curl https://ark.cn-beijing.volces.com/api/v3/chat/completions \\\\\\n  -H \\\"Content-Type: application/json\\\" \\\\\\n  -H \\\"Authorization: Bearer $ARK_API_KEY\\\" \\\\\\n  -d '{\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"messages\\\": [\\n        {\\n            \\\"role\\\": \\\"system\\\",\\n            \\\"content\\\": \\\"You are a helpful assistant.\\\"\\n        },\\n        {\\n            \\\"role\\\": \\\"user\\\",\\n            \\\"content\\\": \\\"Hello!\\\"\\n        }\\n    ]\\n  }'\",\"inputLanguage\":\"bash\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"Hello! How can I help you today?\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742631811,\\n  \\\"id\\\": \\\"0217426318107460cfa43dc3f3683b1de1c09624ff49085a456ac\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 9,\\n    \\\"prompt_tokens\\\": 19,\\n    \\\"total_tokens\\\": 28,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"sT8dtecO\"},{\"title\":\"Python\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"arkruntime\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"import os\\nfrom arkruntime import Ark\\n\\nclient = Ark(\\n    api_key=os.environ.get(\\\"ARK_API_KEY\\\"),\\n    base_url=\\\"https://ark.cn-beijing.volces.com/api/v3\\\",\\n)\\n\\ncompletion = client.chat.completions.create(\\n    model=\\\"doubao-seed-2-1-pro-260915\\\",\\n    messages=[\\n        {\\\"role\\\": \\\"user\\\", \\\"content\\\": \\\"You are a helpful assistant.\\\"}\\n    ]\\n)\\nprint(completion.choices[0].message)\",\"inputLanguage\":\"python\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"Hello! How can I help you today?\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742631811,\\n  \\\"id\\\": \\\"0217426318107460cfa43dc3f3683b1de1c09624ff49085a456ac\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 9,\\n    \\\"prompt_tokens\\\": 19,\\n    \\\"total_tokens\\\": 28,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"Xnuiyh73\"},{\"title\":\"Go\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"github.com/volcengine/volcengine-go-sdk\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"package main\\n\\nimport (\\n    \\\"context\\\"\\n    \\\"fmt\\\"\\n    \\\"os\\\"\\n\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime\\\"\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime/model/chat\\\"\\n)\\n\\nfunc main() {\\n    client := arkruntime.NewClientWithApiKey(\\n        os.Getenv(\\\"ARK_API_KEY\\\"),\\n        arkruntime.WithBaseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\"),\\n    )\\n    ctx := context.Background()\\n    req := &chat.ChatCompletionRequest{\\n        Model: \\\"doubao-seed-2-1-pro-260915\\\",\\n        Messages: []chat.ChatCompletionRequestMessage{\\n            userMessage(\\\"You are a helpful assistant.\\\"),\\n        },\\n    }\\n    resp, err := client.CreateChatCompletion(ctx, req)\\n    if err != nil {\\n        fmt.Printf(\\\"standard chat error: %v\\\\n\\\", err)\\n        return\\n    }\\n    fmt.Println(resp.Choices[0].Message.Content)\\n}\\n\\nfunc userMessage(content string) chat.ChatCompletionRequestMessage {\\n    return chat.ChatCompletionRequestMessage{\\n        OneOf: chat.NewChatCompletionRequestUserMessageChatCompletionRequestMessageSum(\\n            chat.ChatCompletionRequestUserMessage{\\n                Role:    chat.ChatCompletionRequestUserMessageRoleUser,\\n                Content: chat.NewOptNilChatCompletionMessageContent(chat.NewStringChatCompletionMessageContent(content)),\\n            },\\n        ),\\n    }\\n}\",\"inputLanguage\":\"go\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"Hello! How can I help you today?\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742631811,\\n  \\\"id\\\": \\\"0217426318107460cfa43dc3f3683b1de1c09624ff49085a456ac\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 9,\\n    \\\"prompt_tokens\\\": 19,\\n    \\\"total_tokens\\\": 28,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"cA61SBPG\"},{\"title\":\"Java\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"com.fasterxml.jackson.core:jackson-core\",\"packageVersion\":\"2.21.3\"},{\"packageName\":\"com.volcengine:ark-runtime\",\"packageVersion\":\"0.9.0\"}],\"value\":[1,2]}},\"inputCode\":\"package com.volcengine.sample;\\n\\nimport com.fasterxml.jackson.core.JsonProcessingException;\\nimport com.volcengine.ark.runtime.models.chat.*;\\nimport com.volcengine.ark.runtime.models.chat.ChatCompletionRequest.*;\\nimport com.volcengine.ark.runtime.service.ArkService;\\nimport java.util.ArrayList;\\nimport java.util.List;\\nimport java.util.concurrent.TimeUnit;\\nimport okhttp3.ConnectionPool;\\nimport okhttp3.Dispatcher;\\n\\n/*\\n# pom.xml\\n<dependency>\\n  <groupId>com.volcengine</groupId>\\n  <artifactId>ark-runtime</artifactId>\\n  // 替换正式版本号\\n  <version>${ark-runtime.version}</version>\\n</dependency>\\n*/\\n\\npublic class Sample {\\n    //从环境变量中获取您的API KEY，配置方法见：https://ark.volcengine.com/region:cn-beijing/docs/quick-start\\n    static String apiKey = System.getenv(\\\"ARK_API_KEY\\\");\\n\\n    static ConnectionPool connectionPool = new ConnectionPool(5, 1, TimeUnit.SECONDS);\\n    static Dispatcher dispatcher = new Dispatcher();\\n    static ArkService service =\\n            ArkService.builder()\\n                    .dispatcher(dispatcher)\\n                    .connectionPool(connectionPool)\\n                    .apiKey(apiKey)\\n                    .baseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\")\\n                    .build();\\n\\n    public static void main(String[] args) throws JsonProcessingException {\\n\\n        List<ChatCompletionRequestMessage> messagesForReqList = new ArrayList<>();\\n\\n        ChatCompletionRequestMessage elementForMessagesForReqList0 =\\n                ChatCompletionRequestUserMessage.builder()\\n                        .role(ChatCompletionRequestMessageType.USER)\\n                        .content(ChatCompletionMessageContent.ofString(\\\"You are a helpful assistant.\\\"))\\n                        .build();\\n        messagesForReqList.add(elementForMessagesForReqList0);\\n\\n\\n        ChatCompletionRequest req =\\n                ChatCompletionRequest.builder()\\n                        .model(\\\"doubao-seed-2-1-pro-260915\\\")\\n                        .messages(messagesForReqList)\\n                        .build();\\n\\n        service.createChatCompletion(req)\\n                .getChoices()\\n                .forEach(choice -> System.out.println(choice.getMessage().getContent()));\\n        // shutdown service after all requests is finished\\n        service.shutdownExecutor();\\n    }\\n}\",\"inputLanguage\":\"java\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"Hello! How can I help you today?\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742631811,\\n  \\\"id\\\": \\\"0217426318107460cfa43dc3f3683b1de1c09624ff49085a456ac\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 9,\\n    \\\"prompt_tokens\\\": 19,\\n    \\\"total_tokens\\\": 28,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"zigrrq40\"}],\"key\":\"R4DcYn0G\"},{\"title\":\"流式输出\",\"children\":[{\"title\":\"cURL\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"value\":[1]}},\"inputCode\":\"curl https://ark.cn-beijing.volces.com/api/v3/chat/completions \\\\\\n  -H \\\"Content-Type: application/json\\\" \\\\\\n  -H \\\"Authorization: Bearer $ARK_API_KEY\\\" \\\\\\n  -d $'{\\n    \\\"messages\\\": [\\n        {\\n            \\\"content\\\": \\\"You are a helpful assistant.\\\",\\n            \\\"role\\\": \\\"system\\\"\\n        },\\n        {\\n            \\\"content\\\": \\\"hello\\\",\\n            \\\"role\\\": \\\"user\\\"\\n        }\\n    ],\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"stream\\\": true\\n}'\",\"inputLanguage\":\"bash\",\"outputCode\":\"{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"Hello\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"!\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" How\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" can\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" I\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" help\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" you\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" today\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"?\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"\\\",\\\"role\\\":\\\"assistant\\\"},\\\"finish_reason\\\":\\\"stop\\\",\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n[DONE]\",\"outputLanguage\":\"\",\"key\":\"GnjwtN6E\"},{\"title\":\"Python\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"arkruntime\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"import os\\n\\nfrom arkruntime import Ark\\n\\nclient = Ark(\\n    api_key=os.environ.get(\\\"ARK_API_KEY\\\"),\\n    base_url=\\\"https://ark.cn-beijing.volces.com/api/v3\\\",\\n)\\n\\nif __name__ == \\\"__main__\\\":\\n    resp = client.chat.completions.create(\\n        model=\\\"doubao-seed-2-1-pro-260915\\\",\\n        messages=[{\\\"content\\\":\\\"You are a helpful assistant.\\\",\\\"role\\\":\\\"system\\\"},{\\\"content\\\":\\\"hello\\\",\\\"role\\\":\\\"user\\\"}],\\n        stream=True,\\n    )\\n    for chunk in resp:\\n        if not chunk.choices:\\n            continue\\n\\n        print(chunk.choices[0].delta.content or \\\"\\\", end=\\\"\\\")\",\"inputLanguage\":\"python\",\"outputCode\":\"{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"Hello\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"!\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" How\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" can\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" I\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" help\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" you\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" today\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"?\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"\\\",\\\"role\\\":\\\"assistant\\\"},\\\"finish_reason\\\":\\\"stop\\\",\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n[DONE]\",\"outputLanguage\":\"\",\"key\":\"De7SoI5U\"},{\"title\":\"Go\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"github.com/volcengine/volcengine-go-sdk\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"package main\\n\\nimport (\\n    \\\"context\\\"\\n    \\\"fmt\\\"\\n    \\\"io\\\"\\n    \\\"os\\\"\\n\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime\\\"\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime/model/chat\\\"\\n)\\n\\nfunc main() {\\n    client := arkruntime.NewClientWithApiKey(\\n        os.Getenv(\\\"ARK_API_KEY\\\"),\\n        arkruntime.WithBaseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\"),\\n    )\\n    ctx := context.Background()\\n    req := &chat.ChatCompletionRequest{\\n        Model: \\\"doubao-seed-2-1-pro-260915\\\",\\n        Messages: []chat.ChatCompletionRequestMessage{\\n            systemMessage(\\\"You are a helpful assistant.\\\"),\\n            userMessage(\\\"hello\\\"),\\n        },\\n    }\\n    fmt.Println(\\\"----- streaming request -----\\\")\\n    stream, err := client.CreateChatCompletionStream(ctx, req)\\n    if err != nil {\\n        fmt.Printf(\\\"stream chat error: %v\\\\n\\\", err)\\n        return\\n    }\\n    defer stream.Close()\\n\\n    for {\\n        recv, err := stream.Recv()\\n        if err == io.EOF {\\n            return\\n        }\\n        if err != nil {\\n            fmt.Printf(\\\"Stream chat error: %v\\\\n\\\", err)\\n            return\\n        }\\n        if len(recv.Choices) > 0 {\\n            fmt.Print(recv.Choices[0].Delta.Content.Or(\\\"\\\"))\\n        }\\n    }\\n}\\n\\nfunc systemMessage(content string) chat.ChatCompletionRequestMessage {\\n    return chat.ChatCompletionRequestMessage{\\n        OneOf: chat.NewChatCompletionRequestSystemMessageChatCompletionRequestMessageSum(\\n            chat.ChatCompletionRequestSystemMessage{\\n                Role:    chat.ChatCompletionRequestSystemMessageRoleSystem,\\n                Content: chat.NewStringChatCompletionMessageContent(content),\\n            },\\n        ),\\n    }\\n}\\n\\nfunc userMessage(content string) chat.ChatCompletionRequestMessage {\\n    return chat.ChatCompletionRequestMessage{\\n        OneOf: chat.NewChatCompletionRequestUserMessageChatCompletionRequestMessageSum(\\n            chat.ChatCompletionRequestUserMessage{\\n                Role:    chat.ChatCompletionRequestUserMessageRoleUser,\\n                Content: chat.NewOptNilChatCompletionMessageContent(chat.NewStringChatCompletionMessageContent(content)),\\n            },\\n        ),\\n    }\\n}\",\"inputLanguage\":\"go\",\"outputCode\":\"{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"Hello\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"!\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" How\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" can\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" I\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" help\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" you\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" today\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"?\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"\\\",\\\"role\\\":\\\"assistant\\\"},\\\"finish_reason\\\":\\\"stop\\\",\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n[DONE]\",\"outputLanguage\":\"\",\"key\":\"88pMSqe0\"},{\"title\":\"Java\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"com.fasterxml.jackson.core:jackson-core\",\"packageVersion\":\"2.21.3\"},{\"packageName\":\"com.volcengine:ark-runtime\",\"packageVersion\":\"0.9.0\"}],\"value\":[1,2]}},\"inputCode\":\"package com.volcengine.sample;\\n\\nimport com.fasterxml.jackson.core.JsonProcessingException;\\nimport com.volcengine.ark.runtime.models.chat.*;\\nimport com.volcengine.ark.runtime.models.chat.ChatCompletionRequest.*;\\nimport com.volcengine.ark.runtime.service.ArkService;\\nimport java.util.ArrayList;\\nimport java.util.List;\\nimport java.util.concurrent.TimeUnit;\\nimport okhttp3.ConnectionPool;\\nimport okhttp3.Dispatcher;\\n\\n/*\\n# pom.xml\\n<dependency>\\n  <groupId>com.volcengine</groupId>\\n  <artifactId>ark-runtime</artifactId>\\n  // 替换正式版本号\\n  <version>${ark-runtime.version}</version>\\n</dependency>\\n*/\\n\\npublic class Sample {\\n\\n    static String apiKey = System.getenv(\\\"ARK_API_KEY\\\");\\n\\n    static ConnectionPool connectionPool = new ConnectionPool(5, 1, TimeUnit.SECONDS);\\n    static Dispatcher dispatcher = new Dispatcher();\\n    static ArkService service =\\n            ArkService.builder()\\n                    .dispatcher(dispatcher)\\n                    .connectionPool(connectionPool)\\n                    .apiKey(apiKey)\\n                    .baseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\")\\n                    .build();\\n\\n    public static void main(String[] args) throws JsonProcessingException {\\n\\n        List<ChatCompletionRequestMessage> messagesForReqList = new ArrayList<>();\\n\\n        ChatCompletionRequestMessage elementForMessagesForReqList0 =\\n                ChatCompletionRequestSystemMessage.builder()\\n                        .role(ChatCompletionRequestMessageType.SYSTEM)\\n                        .content(ChatCompletionMessageContent.ofString(\\\"You are a helpful assistant.\\\"))\\n                        .build();\\n\\n        ChatCompletionRequestMessage elementForMessagesForReqList1 =\\n                ChatCompletionRequestUserMessage.builder().role(ChatCompletionRequestMessageType.USER).content(ChatCompletionMessageContent.ofString(\\\"hello\\\")).build();\\n\\n        messagesForReqList.add(elementForMessagesForReqList0);\\n        messagesForReqList.add(elementForMessagesForReqList1);\\n\\n        ChatCompletionRequest req =\\n                ChatCompletionRequest.builder()\\n                        .model(\\\"doubao-seed-2-1-pro-260915\\\")\\n                        .messages(messagesForReqList)\\n                        .stream(true)\\n                        .build();\\n\\n        service.streamChatCompletion(req)\\n                .doOnError(Throwable::printStackTrace)\\n                .blockingForEach(\\n                        choice -> {\\n                            if (choice.getChoices().size() > 0) {\\n                                System.out.print(\\n                                        choice.getChoices().get(0).getDelta().getContent());\\n                            }\\n                        });\\n        // shutdown service after all requests is finished\\n        service.shutdownExecutor();\\n    }\\n}\",\"inputLanguage\":\"java\",\"outputCode\":\"{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"Hello\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"!\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" How\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" can\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" I\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" help\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" you\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\" today\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"?\\\",\\\"role\\\":\\\"assistant\\\"},\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n{\\\"choices\\\":[{\\\"delta\\\":{\\\"content\\\":\\\"\\\",\\\"role\\\":\\\"assistant\\\"},\\\"finish_reason\\\":\\\"stop\\\",\\\"index\\\":0}],\\\"created\\\":1742632436,\\\"id\\\":\\\"021742632435712396f12d018b5d576a7a55349c2eba0815061fc\\\",\\\"model\\\":\\\"doubao-seed-2-1-pro-260915\\\",\\\"service_tier\\\":\\\"default\\\",\\\"object\\\":\\\"chat.completion.chunk\\\",\\\"usage\\\":null}\\n\\n[DONE]\",\"outputLanguage\":\"\",\"key\":\"vMNzFHWK\"}],\"key\":\"UgirHVbs\"},{\"title\":\"联网搜索\",\"children\":[{\"title\":\"cURL\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"value\":[1]}},\"inputCode\":\"# web_search_options 传入空对象即可启用 Chat API 内置联网搜索，模型会按用户问题自行判断是否搜索。\\n# search_context_size 和 user_location 当前不生效，传入的值会被忽略。\\ncurl https://ark.cn-beijing.volces.com/api/v3/chat/completions \\\\\\n  -H \\\"Content-Type: application/json\\\" \\\\\\n  -H \\\"Authorization: Bearer $ARK_API_KEY\\\" \\\\\\n  -d '{\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"temperature\\\": 0,\\n    \\\"max_completion_tokens\\\": 320,\\n    \\\"messages\\\": [\\n      {\\n        \\\"role\\\": \\\"user\\\",\\n        \\\"content\\\": \\\"请搜索今天 AI 领域的一条热点新闻。只返回一行：标题 | 来源 URL\\\"\\n      }\\n    ],\\n    \\\"web_search_options\\\": {}\\n  }'\",\"inputLanguage\":\"bash\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"annotations\\\": [\\n          {\\n            \\\"type\\\": \\\"url_citation\\\",\\n            \\\"url_citation\\\": {\\n              \\\"title\\\": \\\"OpenAI 正式发布新一代旗舰大模型 GPT-6 Astra\\\",\\n              \\\"url\\\": \\\"https://news.sina.cn/2026-09-04/detail-iniqrpra63******.d.html\\\"\\n            }\\n          }\\n        ],\\n        \\\"content\\\": \\\"2026 年 9 月 4 日 AI 领域最受关注的热点之一是 OpenAI 正式发布新一代旗舰大模型 GPT-6 Astra。\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1788490760,\\n  \\\"id\\\": \\\"02178849076046900000****\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 1610,\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    },\\n    \\\"prompt_tokens\\\": 3666,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"total_tokens\\\": 5276,\\n    \\\"tool_usage\\\": {\\n      \\\"web_search\\\": 1\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"dcOQAlv5\"}],\"key\":\"zNThCfMf\"},{\"title\":\"续写模式\",\"children\":[{\"title\":\"cURL\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"value\":[1]}},\"inputCode\":\"curl https://ark.cn-beijing.volces.com/api/v3/chat/completions \\\\\\n  -H \\\"Content-Type: application/json\\\" \\\\\\n  -H \\\"Authorization: Bearer $ARK_API_KEY\\\" \\\\\\n  -d $'{\\n    \\\"messages\\\": [\\n        {\\n            \\\"content\\\": \\\"你是一个计算器，请计算： 1 + 1\\\",\\n            \\\"role\\\": \\\"user\\\"\\n        },\\n        {\\n            \\\"content\\\": \\\"=\\\",\\n            \\\"role\\\": \\\"assistant\\\"\\n        }\\n    ],\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\"\\n}'\",\"inputLanguage\":\"bash\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\" 2\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742634165,\\n  \\\"id\\\": \\\"0217426341647344ee2a242cadeb3c7acc981f0bd805884bc65fc\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 2,\\n    \\\"prompt_tokens\\\": 21,\\n    \\\"total_tokens\\\": 23,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"aisgK3I9\"},{\"title\":\"Python\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"arkruntime\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"import os\\n\\nfrom arkruntime import Ark\\n\\nclient = Ark(\\n    api_key=os.environ.get(\\\"ARK_API_KEY\\\"),\\n    base_url=\\\"https://ark.cn-beijing.volces.com/api/v3\\\",\\n)\\n\\nif __name__ == \\\"__main__\\\":\\n    resp = client.chat.completions.create(\\n        model=\\\"doubao-seed-2-1-pro-260915\\\",\\n        messages=[{\\\"content\\\":\\\"你是一个计算器，请计算： 1 + 1\\\",\\\"role\\\":\\\"user\\\"},{\\\"content\\\":\\\"=\\\",\\\"role\\\":\\\"assistant\\\"}],\\n    )\\n    print(resp.choices[0].message.content)\",\"inputLanguage\":\"python\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\" 2\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742634165,\\n  \\\"id\\\": \\\"0217426341647344ee2a242cadeb3c7acc981f0bd805884bc65fc\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 2,\\n    \\\"prompt_tokens\\\": 21,\\n    \\\"total_tokens\\\": 23,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"zxYxeKVW\"},{\"title\":\"Go\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"github.com/volcengine/volcengine-go-sdk\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"package main\\n\\nimport (\\n    \\\"context\\\"\\n    \\\"fmt\\\"\\n    \\\"os\\\"\\n\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime\\\"\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime/model/chat\\\"\\n)\\n\\nfunc main() {\\n    client := arkruntime.NewClientWithApiKey(\\n        os.Getenv(\\\"ARK_API_KEY\\\"),\\n        arkruntime.WithBaseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\"),\\n    )\\n    ctx := context.Background()\\n    req := &chat.ChatCompletionRequest{\\n        Model: \\\"doubao-seed-2-1-pro-260915\\\",\\n        Messages: []chat.ChatCompletionRequestMessage{\\n            userMessage(\\\"你是一个计算器，请计算：1 + 1\\\"),\\n            assistantMessage(\\\"=\\\"),\\n        },\\n    }\\n    fmt.Println(\\\"----- standard request -----\\\")\\n    resp, err := client.CreateChatCompletion(ctx, req)\\n    if err != nil {\\n        fmt.Printf(\\\"standard chat error: %v\\\\n\\\", err)\\n        return\\n    }\\n    fmt.Println(resp.Choices[0].Message.Content)\\n}\\n\\nfunc userMessage(content string) chat.ChatCompletionRequestMessage {\\n    return chat.ChatCompletionRequestMessage{\\n        OneOf: chat.NewChatCompletionRequestUserMessageChatCompletionRequestMessageSum(\\n            chat.ChatCompletionRequestUserMessage{\\n                Role:    chat.ChatCompletionRequestUserMessageRoleUser,\\n                Content: chat.NewOptNilChatCompletionMessageContent(chat.NewStringChatCompletionMessageContent(content)),\\n            },\\n        ),\\n    }\\n}\\n\\nfunc assistantMessage(content string) chat.ChatCompletionRequestMessage {\\n    return chat.ChatCompletionRequestMessage{\\n        OneOf: chat.NewChatCompletionRequestAssistantMessageChatCompletionRequestMessageSum(\\n            chat.ChatCompletionRequestAssistantMessage{\\n                Role: chat.ChatCompletionRequestAssistantMessageRoleAssistant,\\n                Content: chat.NewOptNilChatCompletionMessageContent(chat.NewStringChatCompletionMessageContent(content)),\\n            },\\n        ),\\n    }\\n}\",\"inputLanguage\":\"go\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\" 2\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742634165,\\n  \\\"id\\\": \\\"0217426341647344ee2a242cadeb3c7acc981f0bd805884bc65fc\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 2,\\n    \\\"prompt_tokens\\\": 21,\\n    \\\"total_tokens\\\": 23,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"NZqjLe8s\"},{\"title\":\"Java\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"com.fasterxml.jackson.core:jackson-core\",\"packageVersion\":\"2.21.3\"},{\"packageName\":\"com.volcengine:ark-runtime\",\"packageVersion\":\"0.9.0\"}],\"value\":[1,2]}},\"inputCode\":\"package com.volcengine.sample;\\n\\nimport com.fasterxml.jackson.core.JsonProcessingException;\\nimport com.volcengine.ark.runtime.models.chat.*;\\nimport com.volcengine.ark.runtime.models.chat.ChatCompletionRequest.*;\\nimport com.volcengine.ark.runtime.service.ArkService;\\nimport java.util.ArrayList;\\nimport java.util.List;\\nimport java.util.concurrent.TimeUnit;\\nimport okhttp3.ConnectionPool;\\nimport okhttp3.Dispatcher;\\n\\n/*\\n# pom.xml\\n<dependency>\\n  <groupId>com.volcengine</groupId>\\n  <artifactId>ark-runtime</artifactId>\\n  // 替换正式版本号\\n  <version>${ark-runtime.version}</version>\\n</dependency>\\n*/\\n\\npublic class Sample {\\n\\n    static String apiKey = System.getenv(\\\"ARK_API_KEY\\\");\\n\\n    static ConnectionPool connectionPool = new ConnectionPool(5, 1, TimeUnit.SECONDS);\\n    static Dispatcher dispatcher = new Dispatcher();\\n    static ArkService service =\\n            ArkService.builder()\\n                    .dispatcher(dispatcher)\\n                    .connectionPool(connectionPool)\\n                    .apiKey(apiKey)\\n                    .baseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\")\\n                    .build();\\n\\n    public static void main(String[] args) throws JsonProcessingException {\\n\\n        List<ChatCompletionRequestMessage> messagesForReqList = new ArrayList<>();\\n\\n        ChatCompletionRequestMessage elementForMessagesForReqList0 =\\n                ChatCompletionRequestUserMessage.builder()\\n                        .role(ChatCompletionRequestMessageType.USER)\\n                        .content(ChatCompletionMessageContent.ofString(\\\"你是一个计算器，请计算： 1 + 1\\\"))\\n                        .build();\\n\\n        ChatCompletionRequestMessage elementForMessagesForReqList1 =\\n                ChatCompletionRequestAssistantMessage.builder().role(ChatCompletionRequestMessageType.ASSISTANT).content(ChatCompletionMessageContent.ofString(\\\"=\\\")).build();\\n\\n        messagesForReqList.add(elementForMessagesForReqList0);\\n        messagesForReqList.add(elementForMessagesForReqList1);\\n\\n        ChatCompletionRequest req =\\n                ChatCompletionRequest.builder()\\n                        .model(\\\"doubao-seed-2-1-pro-260915\\\")\\n                        .messages(messagesForReqList)\\n                        .build();\\n\\n        service.createChatCompletion(req)\\n                .getChoices()\\n                .forEach(choice -> System.out.println(choice.getMessage().getContent()));\\n        // shutdown service after all requests is finished\\n        service.shutdownExecutor();\\n    }\\n}\",\"inputLanguage\":\"java\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\" 2\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742634165,\\n  \\\"id\\\": \\\"0217426341647344ee2a242cadeb3c7acc981f0bd805884bc65fc\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 2,\\n    \\\"prompt_tokens\\\": 21,\\n    \\\"total_tokens\\\": 23,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"q1L5BslP\"}],\"key\":\"Nhv3y7Gz\"},{\"title\":\"图片理解\",\"children\":[{\"title\":\"cURL\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"value\":[1]}},\"inputCode\":\"curl https://ark.cn-beijing.volces.com/api/v3/chat/completions \\\\\\n  -H \\\"Content-Type: application/json\\\" \\\\\\n  -H \\\"Authorization: Bearer $ARK_API_KEY\\\" \\\\\\n  -d $'{\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"messages\\\": [\\n        {\\n            \\\"content\\\": [\\n                {\\n                    \\\"image_url\\\": {\\n                        \\\"url\\\": \\\"https://arkdocs.tos-cn-beijing.volces.com/images/advanced-usage/view.jpeg\\\"\\n                    },\\n                    \\\"type\\\": \\\"image_url\\\"\\n                },\\n                {\\n                    \\\"text\\\": \\\"图片主要讲了什么?\\\",\\n                    \\\"type\\\": \\\"text\\\"\\n                }\\n            ],\\n            \\\"role\\\": \\\"user\\\"\\n        }\\n    ]\\n}'\",\"inputLanguage\":\"bash\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"画面中呈现了一幅宁静的户外景象。一个人乘坐在橙黄色的皮划艇上，手持船桨，正在平静的水面划行。水面如镜，倒映着周围景致。远处是茂密的森林，森林后方矗立着巍峨的雪山，山体覆盖着白雪。天空呈浅蓝色，飘浮着一些云朵。整体氛围静谧而美好，展现出自然的纯净与壮阔。 \\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742636149,\\n  \\\"id\\\": \\\"0217426361458116592a076493be583bc5e33f80ac2dcf1efc31b\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 85,\\n    \\\"prompt_tokens\\\": 521,\\n    \\\"total_tokens\\\": 606,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"MYI5XvZ6\"},{\"title\":\"Python\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"arkruntime\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"import os\\n\\nfrom arkruntime import Ark\\n\\nclient = Ark(\\n    api_key=os.environ.get(\\\"ARK_API_KEY\\\"),\\n    base_url=\\\"https://ark.cn-beijing.volces.com/api/v3\\\",\\n)\\n\\n\\nif __name__ == \\\"__main__\\\":\\n    resp = client.chat.completions.create(\\n        model=\\\"doubao-seed-2-1-pro-260915\\\",\\n        messages=[{\\\"content\\\":[{\\\"image_url\\\":{\\\"url\\\":\\\"https://arkdocs.tos-cn-beijing.volces.com/images/advanced-usage/view.jpeg\\\"},\\\"type\\\":\\\"image_url\\\"},{\\\"text\\\":\\\"图片主要讲了什么?\\\",\\\"type\\\":\\\"text\\\"}],\\\"role\\\":\\\"user\\\"}],\\n    )\\n    print(resp.choices[0].message.content)\",\"inputLanguage\":\"python\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"画面中呈现了一幅宁静的户外景象。一个人乘坐在橙黄色的皮划艇上，手持船桨，正在平静的水面划行。水面如镜，倒映着周围景致。远处是茂密的森林，森林后方矗立着巍峨的雪山，山体覆盖着白雪。天空呈浅蓝色，飘浮着一些云朵。整体氛围静谧而美好，展现出自然的纯净与壮阔。 \\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742636149,\\n  \\\"id\\\": \\\"0217426361458116592a076493be583bc5e33f80ac2dcf1efc31b\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 85,\\n    \\\"prompt_tokens\\\": 521,\\n    \\\"total_tokens\\\": 606,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"itjcXTmA\"},{\"title\":\"Go\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"github.com/volcengine/volcengine-go-sdk\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"package main\\n\\nimport (\\n    \\\"context\\\"\\n    \\\"fmt\\\"\\n    \\\"os\\\"\\n\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime\\\"\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime/model/chat\\\"\\n)\\n\\nfunc main() {\\n    client := arkruntime.NewClientWithApiKey(\\n        os.Getenv(\\\"ARK_API_KEY\\\"),\\n        arkruntime.WithBaseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\"),\\n    )\\n    ctx := context.Background()\\n    req := &chat.ChatCompletionRequest{\\n        Model: \\\"doubao-seed-2-1-pro-260915\\\",\\n        Messages: []chat.ChatCompletionRequestMessage{\\n            imageMessage(\\n                \\\"https://arkdocs.tos-cn-beijing.volces.com/images/advanced-usage/view.jpeg\\\",\\n                \\\"图片主要讲了什么？\\\",\\n            ),\\n        },\\n    }\\n    fmt.Println(\\\"----- standard request -----\\\")\\n    resp, err := client.CreateChatCompletion(ctx, req)\\n    if err != nil {\\n        fmt.Printf(\\\"standard chat error: %v\\\\n\\\", err)\\n        return\\n    }\\n    fmt.Println(resp.Choices[0].Message.Content)\\n}\\n\\nfunc imageMessage(imageURL, prompt string) chat.ChatCompletionRequestMessage {\\n    parts := []chat.ChatCompletionContentPart{\\n        {\\n            OneOf: chat.NewChatCompletionContentPartImageChatCompletionContentPartSum(\\n                chat.ChatCompletionContentPartImage{\\n                    Type: chat.ChatCompletionContentPartImageTypeImageURL,\\n                    ImageURL: chat.NewChatCompletionContentPartImageImageUrlChatCompletionContentPartImageImageURL(chat.ChatCompletionContentPartImageImageUrl{\\n                        URL: chat.NewOptString(imageURL),\\n                    }),\\n                },\\n            ),\\n        },\\n        {\\n            OneOf: chat.NewChatCompletionContentPartTextChatCompletionContentPartSum(\\n                chat.ChatCompletionContentPartText{\\n                    Type: chat.ChatCompletionContentPartTextTypeText,\\n                    Text: prompt,\\n                },\\n            ),\\n        },\\n    }\\n    return chat.ChatCompletionRequestMessage{\\n        OneOf: chat.NewChatCompletionRequestUserMessageChatCompletionRequestMessageSum(\\n            chat.ChatCompletionRequestUserMessage{\\n                Role: chat.ChatCompletionRequestUserMessageRoleUser,\\n                Content: chat.NewOptNilChatCompletionMessageContent(chat.NewChatCompletionContentPartArrayChatCompletionMessageContent(\\n                    parts,\\n                )),\\n            },\\n        ),\\n    }\\n}\",\"inputLanguage\":\"go\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"画面中呈现了一幅宁静的户外景象。一个人乘坐在橙黄色的皮划艇上，手持船桨，正在平静的水面划行。水面如镜，倒映着周围景致。远处是茂密的森林，森林后方矗立着巍峨的雪山，山体覆盖着白雪。天空呈浅蓝色，飘浮着一些云朵。整体氛围静谧而美好，展现出自然的纯净与壮阔。 \\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742636149,\\n  \\\"id\\\": \\\"0217426361458116592a076493be583bc5e33f80ac2dcf1efc31b\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 85,\\n    \\\"prompt_tokens\\\": 521,\\n    \\\"total_tokens\\\": 606,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"BHCSU3Ro\"},{\"title\":\"Java\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"com.fasterxml.jackson.core:jackson-core\",\"packageVersion\":\"2.21.3\"},{\"packageName\":\"com.volcengine:ark-runtime\",\"packageVersion\":\"0.9.0\"}],\"value\":[1,2]}},\"inputCode\":\"package com.volcengine.sample;\\n\\nimport com.fasterxml.jackson.core.JsonProcessingException;\\nimport com.volcengine.ark.runtime.models.chat.*;\\nimport com.volcengine.ark.runtime.models.chat.ChatCompletionContentPart.*;\\nimport com.volcengine.ark.runtime.models.chat.ChatCompletionRequest.*;\\nimport com.volcengine.ark.runtime.service.ArkService;\\nimport java.util.ArrayList;\\nimport java.util.List;\\nimport java.util.concurrent.TimeUnit;\\nimport okhttp3.ConnectionPool;\\nimport okhttp3.Dispatcher;\\n\\n/*\\n# pom.xml\\n<dependency>\\n  <groupId>com.volcengine</groupId>\\n  <artifactId>ark-runtime</artifactId>\\n  // 替换正式版本号\\n  <version>${ark-runtime.version}</version>\\n</dependency>\\n*/\\n\\npublic class Sample {\\n    static String apiKey = System.getenv(\\\"ARK_API_KEY\\\");\\n\\n    static ConnectionPool connectionPool = new ConnectionPool(5, 1, TimeUnit.SECONDS);\\n    static Dispatcher dispatcher = new Dispatcher();\\n    static ArkService service =\\n            ArkService.builder()\\n                    .dispatcher(dispatcher)\\n                    .connectionPool(connectionPool)\\n                    .apiKey(apiKey)\\n                    .baseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\")\\n                    .build();\\n\\n    public static void main(String[] args) throws JsonProcessingException {\\n\\n        List<ChatCompletionRequestMessage> messagesForReqList = new ArrayList<>();\\n\\n        List<ChatCompletionContentPart> contentForElementForMessagesForReqList0 = new ArrayList<>();\\n\\n        ChatCompletionContentPartImageImageUrl\\n                imageUrlForElementForContentForElementForMessagesForReqList00 =\\n                        ChatCompletionContentPartImageImageUrl.builder().build();\\n        imageUrlForElementForContentForElementForMessagesForReqList00.setUrl(\\n                \\\"https://arkdocs.tos-cn-beijing.volces.com/images/advanced-usage/view.jpeg\\\");\\n        ChatCompletionContentPart elementForContentForElementForMessagesForReqList00 =\\n                ChatCompletionContentPartImage.builder()\\n                        .type(ChatCompletionContentPartType.IMAGE_URL)\\n                        .imageUrl(ChatCompletionContentPartImageImageUrl2.ofChatCompletionContentPartImageImageUrl(imageUrlForElementForContentForElementForMessagesForReqList00))\\n                        .build();\\n        ChatCompletionContentPart elementForContentForElementForMessagesForReqList01 =\\n                ChatCompletionContentPartText.builder()\\n                        .type(ChatCompletionContentPartType.TEXT)\\n                        .text(\\\"图片主要讲了什么?\\\")\\n                        .build();\\n        contentForElementForMessagesForReqList0.add(\\n                elementForContentForElementForMessagesForReqList00);\\n        contentForElementForMessagesForReqList0.add(\\n                elementForContentForElementForMessagesForReqList01);\\n\\n        ChatCompletionRequestMessage elementForMessagesForReqList0 =\\n                ChatCompletionRequestUserMessage.builder()\\n                        .role(ChatCompletionRequestMessageType.USER)\\n                        .content(ChatCompletionMessageContent.ofList(contentForElementForMessagesForReqList0))\\n                        .build();\\n        messagesForReqList.add(elementForMessagesForReqList0);\\n\\n        ChatCompletionRequest req =\\n                ChatCompletionRequest.builder()\\n                        .model(\\\"doubao-seed-2-1-pro-260915\\\")\\n                        .messages(messagesForReqList)\\n                        .build();\\n\\n        service.createChatCompletion(req)\\n                .getChoices()\\n                .forEach(choice -> System.out.println(choice.getMessage().getContent()));\\n        // shutdown service after all requests is finished\\n        service.shutdownExecutor();\\n    }\\n}\",\"inputLanguage\":\"java\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"画面中呈现了一幅宁静的户外景象。一个人乘坐在橙黄色的皮划艇上，手持船桨，正在平静的水面划行。水面如镜，倒映着周围景致。远处是茂密的森林，森林后方矗立着巍峨的雪山，山体覆盖着白雪。天空呈浅蓝色，飘浮着一些云朵。整体氛围静谧而美好，展现出自然的纯净与壮阔。 \\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742636149,\\n  \\\"id\\\": \\\"0217426361458116592a076493be583bc5e33f80ac2dcf1efc31b\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 85,\\n    \\\"prompt_tokens\\\": 521,\\n    \\\"total_tokens\\\": 606,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 0\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"2UfCna19\"}],\"key\":\"fuXTPmiE\"},{\"title\":\"视频理解\",\"children\":[{\"title\":\"cURL\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"value\":[1]}},\"inputCode\":\"curl https://ark.cn-beijing.volces.com/api/v3/chat/completions \\\\\\n   -H \\\"Content-Type: application/json\\\" \\\\\\n   -H \\\"Authorization: Bearer $ARK_API_KEY\\\" \\\\\\n   -d '{\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"messages\\\": [\\n        {\\n            \\\"role\\\": \\\"user\\\",\\n            \\\"content\\\": [\\n                {\\\"type\\\": \\\"video_url\\\",\\\"video_url\\\": {\\\"url\\\":  \\\"https://arkdocs.tos-cn-beijing.volces.com/videos/advanced-usage/ark_vlm_video_input.mp4\\\"},\\\"fps\\\": \\\"2\\\"},\\n                {\\\"type\\\": \\\"text\\\", \\\"text\\\": \\\"What is in the video?\\\"}\\n            ]\\n        }\\n    ],\\n    \\\"max_tokens\\\": 300\\n  }'\",\"inputLanguage\":\"bash\",\"outputCode\":\"{\\n    \\\"choices\\\": [\\n        {\\n            \\\"finish_reason\\\": \\\"stop\\\",\\n            \\\"index\\\": 0,\\n            \\\"logprobs\\\": null,\\n            \\\"message\\\": {\\n                \\\"content\\\": \\\"The video showcases a cityscape featuring a prominent clock tower (resembling Big Ben) on the left side. A bridge spans across the scene, with a steady flow of vehicles—including cars and a red bus—moving along it. The background includes a mix of historic and modern buildings under a cloudy sky with warm, golden-hour lighting. The text \\\\\\\"AI生成\\\\\\\" (AI-generated) is visible in the bottom-right corner throughout the video.\\\",\\n                \\\"reasoning_content\\\": \\\"\\\\nGot it, let's see. The video shows a city scene with a famous clock tower (Big Ben-like) and a bridge with traffic. The clock is on the left, and there are cars and a red bus moving on the bridge. The sky is cloudy with a sunset or sunrise hue. Also, there are buildings in the background, and the word \\\\\\\"AI生成\\\\\\\" is in the bottom right corner. So I need to describe what's visible: the clock tower, the bridge with vehicles (including a red bus), the cityscape, the sky, and the AI-generated text.\\\",\\n                \\\"role\\\": \\\"assistant\\\"\\n            }\\n        }\\n    ],\\n    \\\"created\\\": 1769687250,\\n    \\\"id\\\": \\\"02176968724393181abbd6c16bee1cf75e33ac11302acbd610474\\\",\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"service_tier\\\": \\\"default\\\",\\n    \\\"object\\\": \\\"chat.completion\\\",\\n    \\\"usage\\\": {\\n        \\\"completion_tokens\\\": 210,\\n        \\\"prompt_tokens\\\": 10391,\\n        \\\"total_tokens\\\": 10601,\\n        \\\"prompt_tokens_details\\\": {\\n            \\\"cached_tokens\\\": 0\\n        },\\n        \\\"completion_tokens_details\\\": {\\n            \\\"reasoning_tokens\\\": 121\\n        }\\n    }\\n}\",\"outputLanguage\":\"\",\"key\":\"dyoqOsr6\"},{\"title\":\"Python\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"arkruntime\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"import os\\n# Install SDK: python -m pip install --upgrade arkruntime\\nfrom arkruntime import Ark\\n\\nclient = Ark(\\n    # The base URL for model invocation .\\n    base_url=\\\"https://ark.cn-beijing.volces.com/api/v3\\\",\\n    api_key=os.getenv('ARK_API_KEY'),\\n)\\n\\ncompletion = client.chat.completions.create(\\n    # Replace with Model ID .\\n    model = \\\"doubao-seed-2-1-pro-260915\\\",\\n    messages=[\\n        {\\n            \\\"role\\\": \\\"user\\\",\\n            \\\"content\\\": [\\n                {\\n                    \\\"type\\\": \\\"video_url\\\",\\n                    \\\"video_url\\\": {\\n                        \\\"url\\\":  \\\"https://arkdocs.tos-cn-beijing.volces.com/videos/advanced-usage/ark_vlm_video_input.mp4\\\",\\n                        \\\"fps\\\": 2,\\n                    }\\n                },\\n                {\\\"type\\\": \\\"text\\\", \\\"text\\\": \\\"What is in the video?\\\"},\\n            ],\\n        }\\n    ],\\n)\\n\\nprint(completion.choices[0])\",\"inputLanguage\":\"python\",\"outputCode\":\"{\\n    \\\"choices\\\": [\\n        {\\n            \\\"finish_reason\\\": \\\"stop\\\",\\n            \\\"index\\\": 0,\\n            \\\"logprobs\\\": null,\\n            \\\"message\\\": {\\n                \\\"content\\\": \\\"The video showcases a cityscape featuring a prominent clock tower (resembling Big Ben) on the left side. A bridge spans across the scene, with a steady flow of vehicles—including cars and a red bus—moving along it. The background includes a mix of historic and modern buildings under a cloudy sky with warm, golden-hour lighting. The text \\\\\\\"AI生成\\\\\\\" (AI-generated) is visible in the bottom-right corner throughout the video.\\\",\\n                \\\"reasoning_content\\\": \\\"\\\\nGot it, let's see. The video shows a city scene with a famous clock tower (Big Ben-like) and a bridge with traffic. The clock is on the left, and there are cars and a red bus moving on the bridge. The sky is cloudy with a sunset or sunrise hue. Also, there are buildings in the background, and the word \\\\\\\"AI生成\\\\\\\" is in the bottom right corner. So I need to describe what's visible: the clock tower, the bridge with vehicles (including a red bus), the cityscape, the sky, and the AI-generated text.\\\",\\n                \\\"role\\\": \\\"assistant\\\"\\n            }\\n        }\\n    ],\\n    \\\"created\\\": 1769687250,\\n    \\\"id\\\": \\\"02176968724393181abbd6c16bee1cf75e33ac11302acbd610474\\\",\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"service_tier\\\": \\\"default\\\",\\n    \\\"object\\\": \\\"chat.completion\\\",\\n    \\\"usage\\\": {\\n        \\\"completion_tokens\\\": 210,\\n        \\\"prompt_tokens\\\": 10391,\\n        \\\"total_tokens\\\": 10601,\\n        \\\"prompt_tokens_details\\\": {\\n            \\\"cached_tokens\\\": 0\\n        },\\n        \\\"completion_tokens_details\\\": {\\n            \\\"reasoning_tokens\\\": 121\\n        }\\n    }\\n}\",\"outputLanguage\":\"\",\"key\":\"jtgIneIU\"},{\"title\":\"Go\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"github.com/volcengine/volcengine-go-sdk\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"package main\\n\\nimport (\\n    \\\"context\\\"\\n    \\\"fmt\\\"\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime\\\"\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime/model/chat\\\"\\n    \\\"os\\\"\\n)\\n\\nfunc main() {\\n    client := arkruntime.NewClientWithApiKey(\\n        os.Getenv(\\\"ARK_API_KEY\\\"),\\n        arkruntime.WithBaseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\"),\\n    )\\n    ctx := context.Background()\\n    contentParts := []chat.ChatCompletionContentPart{\\n        {\\n            OneOf: chat.NewChatCompletionContentPartVideoChatCompletionContentPartSum(\\n                chat.ChatCompletionContentPartVideo{\\n                    Type: chat.ChatCompletionContentPartVideoTypeVideoURL,\\n                    VideoURL: chat.ChatCompletionContentPartVideoVideoUrl{\\n                        URL: chat.NewOptString(\\\"https://arkdocs.tos-cn-beijing.volces.com/videos/advanced-usage/ark_vlm_video_input.mp4\\\"),\\n                        Fps: chat.NewOptFloat64(2),\\n                    },\\n                },\\n            ),\\n        },\\n        {\\n            OneOf: chat.NewChatCompletionContentPartTextChatCompletionContentPartSum(\\n                chat.ChatCompletionContentPartText{\\n                    Type: chat.ChatCompletionContentPartTextTypeText,\\n                    Text: \\\"What is in the video?\\\",\\n                },\\n            ),\\n        },\\n    }\\n    req := &chat.ChatCompletionRequest{\\n        Model: \\\"doubao-seed-2-1-pro-260915\\\",\\n        Messages: []chat.ChatCompletionRequestMessage{\\n            userMessage(contentParts),\\n        },\\n        MaxTokens: chat.NewOptInt32(300),\\n    }\\n\\n    resp, err := client.CreateChatCompletion(ctx, req)\\n    if err != nil {\\n        fmt.Printf(\\\"standard chat error: %v\\\\n\\\", err)\\n        return\\n    }\\n    fmt.Println(resp.Choices[0].Message.Content)\\n}\\n\\nfunc userMessage(parts []chat.ChatCompletionContentPart) chat.ChatCompletionRequestMessage {\\n    return chat.ChatCompletionRequestMessage{\\n        OneOf: chat.NewChatCompletionRequestUserMessageChatCompletionRequestMessageSum(\\n            chat.ChatCompletionRequestUserMessage{\\n                Role: chat.ChatCompletionRequestUserMessageRoleUser,\\n                Content: chat.NewOptNilChatCompletionMessageContent(chat.NewChatCompletionContentPartArrayChatCompletionMessageContent(\\n                    parts,\\n                )),\\n            },\\n        ),\\n    }\\n}\",\"inputLanguage\":\"go\",\"outputCode\":\"{\\n    \\\"choices\\\": [\\n        {\\n            \\\"finish_reason\\\": \\\"stop\\\",\\n            \\\"index\\\": 0,\\n            \\\"logprobs\\\": null,\\n            \\\"message\\\": {\\n                \\\"content\\\": \\\"The video showcases a cityscape featuring a prominent clock tower (resembling Big Ben) on the left side. A bridge spans across the scene, with a steady flow of vehicles—including cars and a red bus—moving along it. The background includes a mix of historic and modern buildings under a cloudy sky with warm, golden-hour lighting. The text \\\\\\\"AI生成\\\\\\\" (AI-generated) is visible in the bottom-right corner throughout the video.\\\",\\n                \\\"reasoning_content\\\": \\\"\\\\nGot it, let's see. The video shows a city scene with a famous clock tower (Big Ben-like) and a bridge with traffic. The clock is on the left, and there are cars and a red bus moving on the bridge. The sky is cloudy with a sunset or sunrise hue. Also, there are buildings in the background, and the word \\\\\\\"AI生成\\\\\\\" is in the bottom right corner. So I need to describe what's visible: the clock tower, the bridge with vehicles (including a red bus), the cityscape, the sky, and the AI-generated text.\\\",\\n                \\\"role\\\": \\\"assistant\\\"\\n            }\\n        }\\n    ],\\n    \\\"created\\\": 1769687250,\\n    \\\"id\\\": \\\"02176968724393181abbd6c16bee1cf75e33ac11302acbd610474\\\",\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"service_tier\\\": \\\"default\\\",\\n    \\\"object\\\": \\\"chat.completion\\\",\\n    \\\"usage\\\": {\\n        \\\"completion_tokens\\\": 210,\\n        \\\"prompt_tokens\\\": 10391,\\n        \\\"total_tokens\\\": 10601,\\n        \\\"prompt_tokens_details\\\": {\\n            \\\"cached_tokens\\\": 0\\n        },\\n        \\\"completion_tokens_details\\\": {\\n            \\\"reasoning_tokens\\\": 121\\n        }\\n    }\\n}\",\"outputLanguage\":\"\",\"key\":\"KoVm4yLY\"},{\"title\":\"Java\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"com.fasterxml.jackson.core:jackson-core\",\"packageVersion\":\"2.21.3\"},{\"packageName\":\"com.volcengine:ark-runtime\",\"packageVersion\":\"0.9.0\"}],\"value\":[1,2]}},\"inputCode\":\"package com.ark.sample;\\n\\nimport com.volcengine.ark.runtime.models.chat.*;\\nimport com.volcengine.ark.runtime.models.chat.ChatCompletionContentPart.*;\\nimport com.volcengine.ark.runtime.service.ArkService;\\nimport java.util.ArrayList;\\nimport java.util.List;\\nimport java.util.concurrent.TimeUnit;\\nimport okhttp3.ConnectionPool;\\nimport okhttp3.Dispatcher;\\n\\npublic class VideoSample {\\n  static String apiKey = System.getenv(\\\"ARK_API_KEY\\\");\\n  static ConnectionPool connectionPool = new ConnectionPool(5, 1, TimeUnit.SECONDS);\\n  static Dispatcher dispatcher = new Dispatcher();\\n  static ArkService service = ArkService.builder()\\n      .dispatcher(dispatcher)\\n      .connectionPool(connectionPool)\\n      .baseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\")\\n      // The base URL for model invocation .\\n      .apiKey(apiKey)\\n      .build();\\n\\n  public static void main(String[] args) throws Exception {\\n\\n    List<ChatCompletionRequestMessage> messagesForReqList = new ArrayList<>();\\n\\n    List<ChatCompletionContentPart> contentParts = new ArrayList<>();\\n\\n    contentParts.add(ChatCompletionContentPartVideo.builder()\\n        .type(ChatCompletionContentPartType.VIDEO_URL)\\n        .videoUrl(ChatCompletionContentPartVideoVideoUrl.builder().url(\\\"https://arkdocs.tos-cn-beijing.volces.com/videos/advanced-usage/ark_vlm_video_input.mp4\\\").fps(2.0).build())\\n\\n        .build());\\n\\n    contentParts.add(ChatCompletionContentPartText.builder()\\n        .type(ChatCompletionContentPartType.TEXT)\\n        .text(\\\"What is in the video?\\\")\\n        .build());\\n\\n    messagesForReqList.add(ChatCompletionRequestUserMessage.builder()\\n        .role(ChatCompletionRequestMessageType.USER)\\n        .content(ChatCompletionMessageContent.ofList(contentParts))\\n        .build());\\n\\n    ChatCompletionRequest req = ChatCompletionRequest.builder()\\n        .model(\\\"doubao-seed-2-1-pro-260915\\\") //Replace with Model ID .\\n        .messages(messagesForReqList)\\n        .maxTokens(300)\\n        .build();\\n\\n    service.createChatCompletion(req)\\n        .getChoices()\\n        .forEach(choice -> System.out.println(choice.getMessage().getContent()));\\n    // shutdown service after all requests are finished\\n    service.shutdownExecutor();\\n  }\\n}\",\"inputLanguage\":\"java\",\"outputCode\":\"{\\n    \\\"choices\\\": [\\n        {\\n            \\\"finish_reason\\\": \\\"stop\\\",\\n            \\\"index\\\": 0,\\n            \\\"logprobs\\\": null,\\n            \\\"message\\\": {\\n                \\\"content\\\": \\\"The video showcases a cityscape featuring a prominent clock tower (resembling Big Ben) on the left side. A bridge spans across the scene, with a steady flow of vehicles—including cars and a red bus—moving along it. The background includes a mix of historic and modern buildings under a cloudy sky with warm, golden-hour lighting. The text \\\\\\\"AI生成\\\\\\\" (AI-generated) is visible in the bottom-right corner throughout the video.\\\",\\n                \\\"reasoning_content\\\": \\\"\\\\nGot it, let's see. The video shows a city scene with a famous clock tower (Big Ben-like) and a bridge with traffic. The clock is on the left, and there are cars and a red bus moving on the bridge. The sky is cloudy with a sunset or sunrise hue. Also, there are buildings in the background, and the word \\\\\\\"AI生成\\\\\\\" is in the bottom right corner. So I need to describe what's visible: the clock tower, the bridge with vehicles (including a red bus), the cityscape, the sky, and the AI-generated text.\\\",\\n                \\\"role\\\": \\\"assistant\\\"\\n            }\\n        }\\n    ],\\n    \\\"created\\\": 1769687250,\\n    \\\"id\\\": \\\"02176968724393181abbd6c16bee1cf75e33ac11302acbd610474\\\",\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n    \\\"service_tier\\\": \\\"default\\\",\\n    \\\"object\\\": \\\"chat.completion\\\",\\n    \\\"usage\\\": {\\n        \\\"completion_tokens\\\": 210,\\n        \\\"prompt_tokens\\\": 10391,\\n        \\\"total_tokens\\\": 10601,\\n        \\\"prompt_tokens_details\\\": {\\n            \\\"cached_tokens\\\": 0\\n        },\\n        \\\"completion_tokens_details\\\": {\\n            \\\"reasoning_tokens\\\": 121\\n        }\\n    }\\n}\",\"outputLanguage\":\"\",\"key\":\"s7TjobGl\"}],\"key\":\"0FCxRQzF\"},{\"title\":\"音频理解\",\"children\":[{\"title\":\"cURL\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"value\":[1]}},\"inputCode\":\"curl https://ark.cn-beijing.volces.com/api/v3/chat/completions \\\\\\n-H \\\"Content-Type: application/json\\\"  \\\\\\n-H \\\"Authorization: Bearer $ARK_API_KEY\\\"  \\\\\\n-d '{\\n    \\\"model\\\": \\\"doubao-seed-2-1-lite-260915\\\",\\n    \\\"messages\\\": [\\n        {\\n            \\\"role\\\": \\\"user\\\",\\n            \\\"content\\\": [\\n                {\\n                    \\\"type\\\": \\\"input_audio\\\",\\n                    \\\"input_audio\\\": {\\n                        \\\"url\\\": \\\"https://arkdocs.tos-cn-beijing.volces.com/files/advanced-usage/ark_demo_audio.mp3\\\",\\n                        \\\"format\\\": \\\"mp3\\\"\\n                    }\\n                },\\n                {\\n                    \\\"type\\\": \\\"text\\\",\\n                    \\\"text\\\": \\\"请识别音频中的内容\\\"\\n                }\\n            ]\\n        }\\n    ]\\n}'\",\"inputLanguage\":\"bash\",\"outputCode\":\"{\\n    \\\"choices\\\": [\\n        {\\n            \\\"finish_reason\\\": \\\"stop\\\",\\n            \\\"index\\\": 0,\\n            \\\"logprobs\\\": null,\\n            \\\"message\\\": {\\n                \\\"content\\\": \\\"识别到的音频内容为：绵如云朵入口即化，甜蜜尽在SEEDNS。这是一句偏向甜品相关品牌的宣传 slogan，描述对应食物口感像云朵般绵软、入口快速融化的特点，点出甜蜜的体验都来自名为SEEDNS的品牌。\\\",\\n                \\\"reasoning_content\\\": \\\"待识别的音频内容为“绵如云朵入口即化，甜蜜尽在SEEDNS。”音频内容的识别核对工作已经完成，确认识别结果准确无误，该内容为甜品宣传slogan，核心信息为“绵如云朵入口即化，甜蜜尽在SEEDNS”，接下来将直接输出识别到的准确内容。\\\\n\\\",\\n                \\\"encrypted_content\\\": \\\"djF5bw7BtwH3UvkWgRPtDQkv3RnL8tQuyAj2JwFajlts/zz7bkoX0IB1joHPJFjuOq/iVdheVGrSxFVTCmpGUzpK/2rDgeg1NBSkUp6u9pObv8mG0XtojzAPT92slvJuumKP07BgFrJQAXy36WIMXAsdNI/rOLNHMjvK/5Iqzg2zyFTU0kNnzs8ZQ1MMwbToi8PL1ycDuu9viZvwNUdPZ9jMsx4BwnHiDbMPppBUFlI7N2zLK4gyg6C+6ep/vfmGlnRRZdvocMmIK4SZQlAqxsL/hVMeGX7dOWBIhB+jaynY9cDS31pePmhXjxbNNGF7nfhwfjJS+IPqOi4IK+DIJyF5wVYCaTMgkGGJbDl0CgKf8c3Lr6Mw4mCovRKBcDuSmjMgsTUG2pXibe88mlGoNn7NLf1bO50BtcDkZiLagSuJ6PAcrbO6n34V0/SKZmVZbGfdhI2AijVvdtrsk3OVHM/XTrzca5SmhBwRqEKi1YKH8uEVkqjVGOJsR1SwpUDbZ/B6abc2Fq0qAlNJqDnf03ENMnudn1nQDecYLw/97qgGjjxb2H+VO0BNVgx7P6+nbQUIdko/DyOarnMGmloPR7f5az2iwkX6+Q5r4iro79IQ3EWV9AsQZjHI2ALMbnksNXxvFPhnmzWhy9s0lhG7pNUTbgyb7zCVCu2ymsE8610er01sS0wdYaflrq+GXeJ7njDrfvdDJNZ+TjdjAoSGwKvQO6eykepmcjjrro7+VSsEIfeYx8BVyCvNsmwRJEOE+63K/FklxKz65Qco7Ye8jQbY465EpQ7JuLZ58yYeKspNasS5PWJj2OZkrkecleuYtEV8uMYjaTaL87KmIxthfPJ0A8EQtGb1A98ER17oIxJ7sV2NPcxlKWoq38Ej3aGzZDPjgd+JQ23lmglPH3vNgKR0OyMmuA==\\\",\\n                \\\"role\\\": \\\"assistant\\\"\\n            }\\n        }\\n    ],\\n    \\\"created\\\": 1778829097,\\n    \\\"id\\\": \\\"02177882907049470efbf1cf5c1ae3d0b3f284807454d292b2912\\\",\\n    \\\"model\\\": \\\"doubao-seed-2-0-lite-260428\\\",\\n    \\\"service_tier\\\": \\\"default\\\",\\n    \\\"object\\\": \\\"chat.completion\\\",\\n    \\\"usage\\\": {\\n        \\\"completion_tokens\\\": 311,\\n        \\\"prompt_tokens\\\": 80,\\n        \\\"total_tokens\\\": 391,\\n        \\\"prompt_tokens_details\\\": {\\n            \\\"cached_tokens\\\": 0,\\n            \\\"audio_tokens\\\": 40\\n        },\\n        \\\"completion_tokens_details\\\": {\\n            \\\"reasoning_tokens\\\": 250\\n        }\\n    }\\n}\",\"outputLanguage\":\"\",\"key\":\"eRdE0aM1\"},{\"title\":\"Python\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"arkruntime\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"import os\\n# Install SDK: python -m pip install --upgrade arkruntime\\nfrom arkruntime import Ark\\n\\nclient = Ark(\\n    # The base URL for model invocation\\n    base_url=\\\"https://ark.cn-beijing.volces.com/api/v3\\\",\\n    # Get API Key: https://ark.volcengine.com/region:cn-beijing/apikey\\n    api_key=os.getenv('ARK_API_KEY'),\\n)\\n\\ncompletion = client.chat.completions.create(\\n    # Replace with Model ID\\n    model = \\\"doubao-seed-2-1-lite-260915\\\",\\n    messages=[\\n        {\\n            \\\"role\\\": \\\"user\\\",\\n            \\\"content\\\": [\\n                {\\n                    \\\"type\\\": \\\"input_audio\\\",\\n                    \\\"input_audio\\\": {\\n                        \\\"url\\\": \\\"https://arkdocs.tos-cn-beijing.volces.com/files/advanced-usage/ark_demo_audio.mp3\\\",\\n                        \\\"format\\\": \\\"mp3\\\"\\n                    }\\n                },\\n                {\\\"type\\\": \\\"text\\\", \\\"text\\\": \\\"请识别音频中的内容\\\"},\\n            ],\\n        }\\n    ],\\n)\\n\\nprint(completion.choices[0])\",\"inputLanguage\":\"python\",\"outputCode\":\"{\\n    \\\"choices\\\": [\\n        {\\n            \\\"finish_reason\\\": \\\"stop\\\",\\n            \\\"index\\\": 0,\\n            \\\"logprobs\\\": null,\\n            \\\"message\\\": {\\n                \\\"content\\\": \\\"识别到的音频内容为：绵如云朵入口即化，甜蜜尽在SEEDNS。这是一句偏向甜品相关品牌的宣传 slogan，描述对应食物口感像云朵般绵软、入口快速融化的特点，点出甜蜜的体验都来自名为SEEDNS的品牌。\\\",\\n                \\\"reasoning_content\\\": \\\"待识别的音频内容为“绵如云朵入口即化，甜蜜尽在SEEDNS。”音频内容的识别核对工作已经完成，确认识别结果准确无误，该内容为甜品宣传slogan，核心信息为“绵如云朵入口即化，甜蜜尽在SEEDNS”，接下来将直接输出识别到的准确内容。\\\\n\\\",\\n                \\\"encrypted_content\\\": \\\"djF5bw7BtwH3UvkWgRPtDQkv3RnL8tQuyAj2JwFajlts/zz7bkoX0IB1joHPJFjuOq/iVdheVGrSxFVTCmpGUzpK/2rDgeg1NBSkUp6u9pObv8mG0XtojzAPT92slvJuumKP07BgFrJQAXy36WIMXAsdNI/rOLNHMjvK/5Iqzg2zyFTU0kNnzs8ZQ1MMwbToi8PL1ycDuu9viZvwNUdPZ9jMsx4BwnHiDbMPppBUFlI7N2zLK4gyg6C+6ep/vfmGlnRRZdvocMmIK4SZQlAqxsL/hVMeGX7dOWBIhB+jaynY9cDS31pePmhXjxbNNGF7nfhwfjJS+IPqOi4IK+DIJyF5wVYCaTMgkGGJbDl0CgKf8c3Lr6Mw4mCovRKBcDuSmjMgsTUG2pXibe88mlGoNn7NLf1bO50BtcDkZiLagSuJ6PAcrbO6n34V0/SKZmVZbGfdhI2AijVvdtrsk3OVHM/XTrzca5SmhBwRqEKi1YKH8uEVkqjVGOJsR1SwpUDbZ/B6abc2Fq0qAlNJqDnf03ENMnudn1nQDecYLw/97qgGjjxb2H+VO0BNVgx7P6+nbQUIdko/DyOarnMGmloPR7f5az2iwkX6+Q5r4iro79IQ3EWV9AsQZjHI2ALMbnksNXxvFPhnmzWhy9s0lhG7pNUTbgyb7zCVCu2ymsE8610er01sS0wdYaflrq+GXeJ7njDrfvdDJNZ+TjdjAoSGwKvQO6eykepmcjjrro7+VSsEIfeYx8BVyCvNsmwRJEOE+63K/FklxKz65Qco7Ye8jQbY465EpQ7JuLZ58yYeKspNasS5PWJj2OZkrkecleuYtEV8uMYjaTaL87KmIxthfPJ0A8EQtGb1A98ER17oIxJ7sV2NPcxlKWoq38Ej3aGzZDPjgd+JQ23lmglPH3vNgKR0OyMmuA==\\\",\\n                \\\"role\\\": \\\"assistant\\\"\\n            }\\n        }\\n    ],\\n    \\\"created\\\": 1778829097,\\n    \\\"id\\\": \\\"02177882907049470efbf1cf5c1ae3d0b3f284807454d292b2912\\\",\\n    \\\"model\\\": \\\"doubao-seed-2-0-lite-260428\\\",\\n    \\\"service_tier\\\": \\\"default\\\",\\n    \\\"object\\\": \\\"chat.completion\\\",\\n    \\\"usage\\\": {\\n        \\\"completion_tokens\\\": 311,\\n        \\\"prompt_tokens\\\": 80,\\n        \\\"total_tokens\\\": 391,\\n        \\\"prompt_tokens_details\\\": {\\n            \\\"cached_tokens\\\": 0,\\n            \\\"audio_tokens\\\": 40\\n        },\\n        \\\"completion_tokens_details\\\": {\\n            \\\"reasoning_tokens\\\": 250\\n        }\\n    }\\n}\",\"outputLanguage\":\"\",\"key\":\"zlAs9qA3\"},{\"title\":\"Java\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"com.fasterxml.jackson.core:jackson-core\",\"packageVersion\":\"2.21.3\"},{\"packageName\":\"com.volcengine:ark-runtime\",\"packageVersion\":\"0.9.0\"}],\"value\":[1,2]}},\"inputCode\":\"package com.ark.sample;\\n\\nimport com.volcengine.ark.runtime.models.chat.*;\\nimport com.volcengine.ark.runtime.models.chat.ChatCompletionContentPart.*;\\nimport com.volcengine.ark.runtime.service.ArkService;\\nimport java.util.ArrayList;\\nimport java.util.List;\\nimport java.util.concurrent.TimeUnit;\\nimport okhttp3.ConnectionPool;\\nimport okhttp3.Dispatcher;\\n\\npublic class Sample {\\n    static String apiKey = System.getenv(\\\"ARK_API_KEY\\\");\\n    static ConnectionPool connectionPool = new ConnectionPool(5, 1, TimeUnit.SECONDS);\\n    static Dispatcher dispatcher = new Dispatcher();\\n    static ArkService service = ArkService.builder()\\n        .dispatcher(dispatcher)\\n        .connectionPool(connectionPool)\\n        .baseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\")\\n        .apiKey(apiKey)\\n        .build();\\n\\n    public static void main(String[] args) throws Exception {\\n\\n        List<ChatCompletionRequestMessage> messagesForReqList = new ArrayList<>();\\n\\n        List<ChatCompletionContentPart> contentParts = new ArrayList<>();\\n\\n        ChatCompletionContentPartAudioInputAudio inputAudio = new ChatCompletionContentPartAudioInputAudio();\\n        inputAudio.setUrl(\\\"https://arkdocs.tos-cn-beijing.volces.com/files/advanced-usage/ark_demo_audio.mp3\\\");\\n        inputAudio.setFormat(\\\"mp3\\\");\\n\\n        contentParts.add(ChatCompletionContentPartAudio.builder()\\n                .type(ChatCompletionContentPartType.INPUT_AUDIO)\\n                .inputAudio(inputAudio)\\n                .build());\\n\\n        contentParts.add(ChatCompletionContentPartText.builder()\\n                .type(ChatCompletionContentPartType.TEXT)\\n                .text(\\\"请识别音频中的内容\\\")\\n                .build());\\n\\n        messagesForReqList.add(ChatCompletionRequestUserMessage.builder()\\n                .role(ChatCompletionRequestMessageType.USER)\\n                .content(ChatCompletionMessageContent.ofList(contentParts))\\n                .build());\\n\\n        ChatCompletionRequest req = ChatCompletionRequest.builder()\\n                .model(\\\"doubao-seed-2-1-lite-260915\\\")\\n                .messages(messagesForReqList)\\n                .build();\\n\\n        service.createChatCompletion(req)\\n                .getChoices()\\n                .forEach(choice -> System.out.println(choice.getMessage().getContent()));\\n\\n        service.shutdownExecutor();\\n    }\\n}\",\"inputLanguage\":\"java\",\"outputCode\":\"{\\n    \\\"choices\\\": [\\n        {\\n            \\\"finish_reason\\\": \\\"stop\\\",\\n            \\\"index\\\": 0,\\n            \\\"logprobs\\\": null,\\n            \\\"message\\\": {\\n                \\\"content\\\": \\\"识别到的音频内容为：绵如云朵入口即化，甜蜜尽在SEEDNS。这是一句偏向甜品相关品牌的宣传 slogan，描述对应食物口感像云朵般绵软、入口快速融化的特点，点出甜蜜的体验都来自名为SEEDNS的品牌。\\\",\\n                \\\"reasoning_content\\\": \\\"待识别的音频内容为“绵如云朵入口即化，甜蜜尽在SEEDNS。”音频内容的识别核对工作已经完成，确认识别结果准确无误，该内容为甜品宣传slogan，核心信息为“绵如云朵入口即化，甜蜜尽在SEEDNS”，接下来将直接输出识别到的准确内容。\\\\n\\\",\\n                \\\"encrypted_content\\\": \\\"djF5bw7BtwH3UvkWgRPtDQkv3RnL8tQuyAj2JwFajlts/zz7bkoX0IB1joHPJFjuOq/iVdheVGrSxFVTCmpGUzpK/2rDgeg1NBSkUp6u9pObv8mG0XtojzAPT92slvJuumKP07BgFrJQAXy36WIMXAsdNI/rOLNHMjvK/5Iqzg2zyFTU0kNnzs8ZQ1MMwbToi8PL1ycDuu9viZvwNUdPZ9jMsx4BwnHiDbMPppBUFlI7N2zLK4gyg6C+6ep/vfmGlnRRZdvocMmIK4SZQlAqxsL/hVMeGX7dOWBIhB+jaynY9cDS31pePmhXjxbNNGF7nfhwfjJS+IPqOi4IK+DIJyF5wVYCaTMgkGGJbDl0CgKf8c3Lr6Mw4mCovRKBcDuSmjMgsTUG2pXibe88mlGoNn7NLf1bO50BtcDkZiLagSuJ6PAcrbO6n34V0/SKZmVZbGfdhI2AijVvdtrsk3OVHM/XTrzca5SmhBwRqEKi1YKH8uEVkqjVGOJsR1SwpUDbZ/B6abc2Fq0qAlNJqDnf03ENMnudn1nQDecYLw/97qgGjjxb2H+VO0BNVgx7P6+nbQUIdko/DyOarnMGmloPR7f5az2iwkX6+Q5r4iro79IQ3EWV9AsQZjHI2ALMbnksNXxvFPhnmzWhy9s0lhG7pNUTbgyb7zCVCu2ymsE8610er01sS0wdYaflrq+GXeJ7njDrfvdDJNZ+TjdjAoSGwKvQO6eykepmcjjrro7+VSsEIfeYx8BVyCvNsmwRJEOE+63K/FklxKz65Qco7Ye8jQbY465EpQ7JuLZ58yYeKspNasS5PWJj2OZkrkecleuYtEV8uMYjaTaL87KmIxthfPJ0A8EQtGb1A98ER17oIxJ7sV2NPcxlKWoq38Ej3aGzZDPjgd+JQ23lmglPH3vNgKR0OyMmuA==\\\",\\n                \\\"role\\\": \\\"assistant\\\"\\n            }\\n        }\\n    ],\\n    \\\"created\\\": 1778829097,\\n    \\\"id\\\": \\\"02177882907049470efbf1cf5c1ae3d0b3f284807454d292b2912\\\",\\n    \\\"model\\\": \\\"doubao-seed-2-0-lite-260428\\\",\\n    \\\"service_tier\\\": \\\"default\\\",\\n    \\\"object\\\": \\\"chat.completion\\\",\\n    \\\"usage\\\": {\\n        \\\"completion_tokens\\\": 311,\\n        \\\"prompt_tokens\\\": 80,\\n        \\\"total_tokens\\\": 391,\\n        \\\"prompt_tokens_details\\\": {\\n            \\\"cached_tokens\\\": 0,\\n            \\\"audio_tokens\\\": 40\\n        },\\n        \\\"completion_tokens_details\\\": {\\n            \\\"reasoning_tokens\\\": 250\\n        }\\n    }\\n}\",\"outputLanguage\":\"\",\"key\":\"izkcN8jo\"}],\"key\":\"ZOP85zlL\"},{\"title\":\"深度推理\",\"children\":[{\"title\":\"cURL\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"value\":[1]}},\"inputCode\":\"curl https://ark.cn-beijing.volces.com/api/v3/chat/completions \\\\\\n  -H \\\"Content-Type: application/json\\\" \\\\\\n  -H \\\"Authorization: Bearer $ARK_API_KEY\\\" \\\\\\n  -d $'{\\n    \\\"messages\\\": [\\n\\n        {\\n            \\\"content\\\": \\\"我要有研究推理模型与非推理模型区别的课题，怎么体现我的专业性\\\",\\n            \\\"role\\\": \\\"user\\\"\\n        }\\n    ],\\n    \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\"\\n}'\",\"inputLanguage\":\"bash\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"\\\\n\\\\n推理模型与非推理模型的主要区别在于其处理任务的方式、能力侧重点以及应用场景。以下是两者的核心区别分析：\\\\n\\\\n---\\\\n\\\\n### **1. 核心定义**\\\\n- **推理模型**  \\\\n  具备**逻辑推理、因果推断或复杂决策**能力，***  \\\\n\\\\n实际应用中，两类模型常配合使用（如用非推理模型提取特征，再交给推理模型决策），以平衡效率与准确性。\\\",\\n        \\\"reasoning_content\\\": \\\"嗯，用户问的是推理模型和非推理模型有什么区别。我需要先理解这两个术语的具体含义。可能用户对机器学习或深度学习有一定的了解，但需要更清晰的区分。首先，我应该明确这两个概念的定义，然后从不同角度进行比较。\\\\n\\\\n首先，推理模型可能指的是那些需要进行逻辑推理、处理复杂任务的模型，***，而非推理模型侧重于模式识别和直接映射，帮助用户形成清晰的概念框架。\\\\n\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742636537,\\n  \\\"id\\\": \\\"0217426364949596592a076493be583bc5e33f80ac2dcf1eeaf9b\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 1207,\\n    \\\"prompt_tokens\\\": 11,\\n    \\\"total_tokens\\\": 1218,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 419\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"7hay7naS\"},{\"title\":\"Python\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"arkruntime\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"import os\\n# 升级方舟 SDK 到最新版本 pip install -U arkruntime\\nfrom arkruntime import Ark\\n\\nclient = Ark(\\n    # 从环境变量中读取您的方舟API Key\\n    api_key=os.environ.get(\\\"ARK_API_KEY\\\"),\\n    base_url=\\\"https://ark.cn-beijing.volces.com/api/v3\\\",\\n    # 深度推理模型耗费时间会较长，请您设置较大的超时时间，避免超时，推荐30分钟以上\\n    timeout=1800,\\n    )\\nresponse = client.chat.completions.create(\\n    # 替换 <Model> 为模型的Model ID\\n    model=\\\"doubao-seed-2-1-pro-260915\\\",\\n    messages=[\\n        {\\\"role\\\": \\\"user\\\", \\\"content\\\": \\\"我要有研究推理模型与非推理模型区别的课题，怎么体现我的专业性\\\"}\\n    ]\\n)\\n# 当触发深度推理时，打印思维链内容\\nif hasattr(response.choices[0].message, 'reasoning_content'):\\n    print(response.choices[0].message.reasoning_content)\\nprint(response.choices[0].message.content)\",\"inputLanguage\":\"python\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"\\\\n\\\\n推理模型与非推理模型的主要区别在于其处理任务的方式、能力侧重点以及应用场景。以下是两者的核心区别分析：\\\\n\\\\n---\\\\n\\\\n### **1. 核心定义**\\\\n- **推理模型**  \\\\n  具备**逻辑推理、因果推断或复杂决策**能力，***  \\\\n\\\\n实际应用中，两类模型常配合使用（如用非推理模型提取特征，再交给推理模型决策），以平衡效率与准确性。\\\",\\n        \\\"reasoning_content\\\": \\\"嗯，用户问的是推理模型和非推理模型有什么区别。我需要先理解这两个术语的具体含义。可能用户对机器学习或深度学习有一定的了解，但需要更清晰的区分。首先，我应该明确这两个概念的定义，然后从不同角度进行比较。\\\\n\\\\n首先，推理模型可能指的是那些需要进行逻辑推理、处理复杂任务的模型，***，而非推理模型侧重于模式识别和直接映射，帮助用户形成清晰的概念框架。\\\\n\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742636537,\\n  \\\"id\\\": \\\"0217426364949596592a076493be583bc5e33f80ac2dcf1eeaf9b\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 1207,\\n    \\\"prompt_tokens\\\": 11,\\n    \\\"total_tokens\\\": 1218,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 419\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"9yR7sDvA\"},{\"title\":\"Go\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"github.com/volcengine/volcengine-go-sdk\",\"packageVersion\":\"\"}],\"value\":[1,2]}},\"inputCode\":\"package main\\n\\nimport (\\n    \\\"context\\\"\\n    \\\"fmt\\\"\\n    \\\"os\\\"\\n    \\\"time\\\"\\n\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime\\\"\\n    \\\"github.com/volcengine/ark-runtime-go/arkruntime/model/chat\\\"\\n)\\n\\nfunc main() {\\n    client := arkruntime.NewClientWithApiKey(\\n        os.Getenv(\\\"ARK_API_KEY\\\"),\\n        arkruntime.WithBaseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\"),\\n        arkruntime.WithTimeout(30*time.Minute),\\n    )\\n    ctx := context.Background()\\n    req := &chat.ChatCompletionRequest{\\n        Model: \\\"doubao-seed-2-1-pro-260915\\\",\\n        Messages: []chat.ChatCompletionRequestMessage{\\n            userMessage(\\\"我要研究推理模型与非推理模型的区别，如何体现课题的专业性？\\\"),\\n        },\\n    }\\n\\n    resp, err := client.CreateChatCompletion(ctx, req)\\n    if err != nil {\\n        fmt.Printf(\\\"standard chat error: %v\\\\n\\\", err)\\n        return\\n    }\\n    if reasoning, ok := resp.Choices[0].Message.ReasoningContent.Get(); ok {\\n        fmt.Println(reasoning)\\n    }\\n    fmt.Println(resp.Choices[0].Message.Content)\\n}\\n\\nfunc userMessage(content string) chat.ChatCompletionRequestMessage {\\n    return chat.ChatCompletionRequestMessage{\\n        OneOf: chat.NewChatCompletionRequestUserMessageChatCompletionRequestMessageSum(\\n            chat.ChatCompletionRequestUserMessage{\\n                Role:    chat.ChatCompletionRequestUserMessageRoleUser,\\n                Content: chat.NewOptNilChatCompletionMessageContent(chat.NewStringChatCompletionMessageContent(content)),\\n            },\\n        ),\\n    }\\n}\",\"inputLanguage\":\"go\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"\\\\n\\\\n推理模型与非推理模型的主要区别在于其处理任务的方式、能力侧重点以及应用场景。以下是两者的核心区别分析：\\\\n\\\\n---\\\\n\\\\n### **1. 核心定义**\\\\n- **推理模型**  \\\\n  具备**逻辑推理、因果推断或复杂决策**能力，***  \\\\n\\\\n实际应用中，两类模型常配合使用（如用非推理模型提取特征，再交给推理模型决策），以平衡效率与准确性。\\\",\\n        \\\"reasoning_content\\\": \\\"嗯，用户问的是推理模型和非推理模型有什么区别。我需要先理解这两个术语的具体含义。可能用户对机器学习或深度学习有一定的了解，但需要更清晰的区分。首先，我应该明确这两个概念的定义，然后从不同角度进行比较。\\\\n\\\\n首先，推理模型可能指的是那些需要进行逻辑推理、处理复杂任务的模型，***，而非推理模型侧重于模式识别和直接映射，帮助用户形成清晰的概念框架。\\\\n\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742636537,\\n  \\\"id\\\": \\\"0217426364949596592a076493be583bc5e33f80ac2dcf1eeaf9b\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 1207,\\n    \\\"prompt_tokens\\\": 11,\\n    \\\"total_tokens\\\": 1218,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 419\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"54XbtlZv\"},{\"title\":\"Java\",\"debug\":{\"openDebug\":true,\"debugParams\":{\"envs\":[\"ARK_API_KEY\"],\"packages\":[{\"packageName\":\"com.fasterxml.jackson.core:jackson-core\",\"packageVersion\":\"2.21.3\"},{\"packageName\":\"com.volcengine:ark-runtime\",\"packageVersion\":\"0.9.0\"}],\"value\":[1,2]}},\"inputCode\":\"package com.example;\\n\\nimport com.volcengine.ark.runtime.models.chat.*;\\nimport com.volcengine.ark.runtime.service.ArkService;\\n\\nimport java.time.Duration;\\nimport java.util.ArrayList;\\nimport java.util.List;\\n\\n/**\\n * 这是一个示例类，展示了如何使用ArkService来完成聊天功能。\\n */\\npublic class ChatCompletionsExample {\\n    public static void main(String[] args) {\\n        // 从环境变量中获取API密钥\\n        String apiKey = System.getenv(\\\"ARK_API_KEY\\\");\\n        // 创建ArkService实例\\n        ArkService arkService = ArkService.builder().apiKey(apiKey)\\n                .timeout(Duration.ofMinutes(30))// 深度推理模型耗费时间会较长，请您设置较大的超时时间，避免超时导致任务失败。推荐30分钟以上\\n                .baseUrl(\\\"https://ark.cn-beijing.volces.com/api/v3\\\")\\n                .build();\\n        // 初始化消息列表\\n        List<ChatCompletionRequestMessage> chatMessages = new ArrayList<>();\\n        // 创建用户消息\\n        ChatCompletionRequestMessage userMessage = ChatCompletionRequestUserMessage.builder()\\n                .role(ChatCompletionRequestMessageType.USER) // 设置消息角色为用户\\n                .content(ChatCompletionMessageContent.ofString(\\\"我要有研究推理模型与非推理模型区别的课题，怎么体现我的专业性\\\")) // 设置消息内容\\n                .build();\\n        // 将用户消息添加到消息列表\\n        chatMessages.add(userMessage);\\n        // 创建聊天完成请求\\n        ChatCompletionRequest chatCompletionRequest = ChatCompletionRequest.builder()\\n                .model(\\\"doubao-seed-2-1-pro-260915\\\")\\n                .messages(chatMessages) // 设置消息列表\\n                .build();\\n        // 发送聊天完成请求并打印响应\\n        try {\\n            // 获取响应并打印每个选择的消息内容\\n            arkService.createChatCompletion(chatCompletionRequest)\\n                    .getChoices()\\n                    .forEach(choice -> {\\n                        // 校验是否触发了深度思考，打印思维链内容\\n                        if (choice.getMessage().getReasoningContent() != null) {\\n                            System.out.println(\\\"推理内容: \\\" + choice.getMessage().getReasoningContent());\\n                        } else {\\n                            System.out.println(\\\"推理内容为空\\\");\\n                        }\\n                        // 打印消息内容\\n                        System.out.println(\\\"消息内容: \\\" + choice.getMessage().getContent());\\n                    });\\n        } catch (Exception e) {\\n            System.out.println(\\\"请求失败: \\\" + e.getMessage());\\n        } finally {\\n            // 关闭服务执行器\\n            arkService.shutdownExecutor();\\n        }\\n    }\\n}\",\"inputLanguage\":\"java\",\"outputCode\":\"{\\n  \\\"choices\\\": [\\n    {\\n      \\\"finish_reason\\\": \\\"stop\\\",\\n      \\\"index\\\": 0,\\n      \\\"logprobs\\\": null,\\n      \\\"message\\\": {\\n        \\\"content\\\": \\\"\\\\n\\\\n推理模型与非推理模型的主要区别在于其处理任务的方式、能力侧重点以及应用场景。以下是两者的核心区别分析：\\\\n\\\\n---\\\\n\\\\n### **1. 核心定义**\\\\n- **推理模型**  \\\\n  具备**逻辑推理、因果推断或复杂决策**能力，***  \\\\n\\\\n实际应用中，两类模型常配合使用（如用非推理模型提取特征，再交给推理模型决策），以平衡效率与准确性。\\\",\\n        \\\"reasoning_content\\\": \\\"嗯，用户问的是推理模型和非推理模型有什么区别。我需要先理解这两个术语的具体含义。可能用户对机器学习或深度学习有一定的了解，但需要更清晰的区分。首先，我应该明确这两个概念的定义，然后从不同角度进行比较。\\\\n\\\\n首先，推理模型可能指的是那些需要进行逻辑推理、处理复杂任务的模型，***，而非推理模型侧重于模式识别和直接映射，帮助用户形成清晰的概念框架。\\\\n\\\",\\n        \\\"role\\\": \\\"assistant\\\"\\n      }\\n    }\\n  ],\\n  \\\"created\\\": 1742636537,\\n  \\\"id\\\": \\\"0217426364949596592a076493be583bc5e33f80ac2dcf1eeaf9b\\\",\\n  \\\"model\\\": \\\"doubao-seed-2-1-pro-260915\\\",\\n  \\\"service_tier\\\": \\\"default\\\",\\n  \\\"object\\\": \\\"chat.completion\\\",\\n  \\\"usage\\\": {\\n    \\\"completion_tokens\\\": 1207,\\n    \\\"prompt_tokens\\\": 11,\\n    \\\"total_tokens\\\": 1218,\\n    \\\"prompt_tokens_details\\\": {\\n      \\\"cached_tokens\\\": 0\\n    },\\n    \\\"completion_tokens_details\\\": {\\n      \\\"reasoning_tokens\\\": 419\\n    }\\n  }\\n}\",\"outputLanguage\":\"\",\"key\":\"Ve5o5qwa\"}],\"key\":\"6TYqHu1M\"}]}"} />);
```
