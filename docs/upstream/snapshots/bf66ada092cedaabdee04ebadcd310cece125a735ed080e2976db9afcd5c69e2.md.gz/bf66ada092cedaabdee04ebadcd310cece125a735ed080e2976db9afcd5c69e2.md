<span id="在线音色列表"></span>
# 在线音色列表

<span id="e7951cad"></span>
##  **"豆包语音合成模型2.0、** S2S\-O2.0、 S2S\-全双工 **" 音色列表**

注：


1. Vivi 2.0、小何 2.0、云舟 2.0、小天 2.0 是S2S的主打音色。

2. 下列音色中，中文音色亦具备英文能力，但英文场景下更推荐使用英文音色。

3. 下列音色中，部分中英精品音色新增<ins>支持多语种自动识别</ins>的相关能力，新增<ins>自动语种识别参数</ins>，覆盖 30 个新增语种，需注意：

   * 覆盖语种：中、英、日、韩、俄罗斯语、印尼、德语、阿拉伯、法语、荷兰语、巴西葡萄牙语、墨西哥西语、菲律宾语、意大利语、泰语、越南语、波兰语、土耳其语、瑞典语、马来语、挪威、乌克兰语、芬兰、丹麦、捷克、匈牙利、希腊、罗马尼亚、印度

   * 特殊规则说明：葡萄牙语、西班牙西语需通过`explicitlanguage`指定才能生效，自动语种识别链路会默认将葡语文本识别为巴西葡萄牙语、西语文本识别为墨西哥西语；

   * 参数优先级：`explicitlanguage`（指定语种）优先级高于自动语种识别参数，若两个参数均未指定则默认走原有中英链路；

   * 接口适配范围：新增的多语种自动识别参数仅适用于单向流、双向流接口，不支持异步长文本、S2S 链路和播客场景



|**场景** |**音色名称** |**voice_type** |**语种/方言** |**支持能力** |**特殊标签** |
|---|---|---|---|---|---|
|通用场景 |Vivi 2.0 |zh_female_vv_uranus_bigtts |语种：中文、日文、印尼、墨西哥西班牙语、支持30+语种识别<br><br>方言：粤语、上海、河南、北京、天津、四川、陕西、东北 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |小何 2.0 |zh_female_xiaohe_uranus_bigtts |语种：中文、支持30+语种识别<br><br>方言：粤语、上海、河南、北京、天津、四川、陕西、东北 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |云舟 2.0 |zh_male_m191_uranus_bigtts |语种：中文、支持30+语种识别<br><br>方言：粤语、上海、河南、北京、天津、四川、陕西、东北 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |小天 2.0 |zh_male_taocheng_uranus_bigtts |语种：中文、支持30+语种识别<br><br>方言：粤语、上海、河南、北京、天津、四川、陕西、东北 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |刘飞 2.0 |zh_male_liufei_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |魅力苏菲 2.0 |zh_female_sophie_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |清新女声 2.0 |zh_female_qingxinnvsheng_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|角色扮演 |知性灿灿 2.0 |zh_female_cancan_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|角色扮演 |撒娇学妹 2.0 |zh_female_sajiaoxuemei_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |甜美小源 2.0 |zh_female_tianmeixiaoyuan_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |甜美桃子 2.0 |zh_female_tianmeitaozi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |爽快思思 2.0 |zh_female_shuangkuaisisi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|视频配音 |佩奇猪 2.0 |zh_female_peiqi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|通用场景 |邻家女孩 2.0 |zh_female_linjianvhai_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |少年梓辛 2.0 |zh_male_shaonianzixin_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|视频配音 |猴哥 2.0 |zh_male_sunwukong_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|教育场景 |Tina老师 2.0 |zh_female_yingyujiaoxue_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|客服场景 |暖阳女声 2.0 |zh_female_kefunvsheng_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|有声阅读 |儿童绘本 2.0 |zh_female_xiaoxue_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|视频配音 |大壹 2.0 |zh_male_dayi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|视频配音 |黑猫侦探社咪仔 2.0 |zh_female_mizai_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|视频配音 |鸡汤女 2.0 |zh_female_jitangnv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |魅力女友 2.0 |zh_female_meilinvyou_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|视频配音 |流畅女声 2.0 |zh_female_liuchangnv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|视频配音 |儒雅逸辰 2.0 |zh_male_ruyayichen_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|外语音色 |Tim |en_male_tim_uranus_bigtts |美式英语 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|外语音色 |Dacey |en_female_dacey_uranus_bigtts |美式英语 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|外语音色 |Stokie |en_female_stokie_uranus_bigtts |美式英语 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |温柔妈妈 2.0 |zh_female_wenroumama_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |解说小明 2.0 |zh_male_jieshuoxiaoming_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |TVB女声 2.0 |zh_female_tvbnv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |译制片男 2.0 |zh_male_yizhipiannan_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |俏皮女声 2.0 |zh_female_qiaopinv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|角色扮演 |直率英子 2.0 |zh_female_zhishuaiyingzi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|通用场景 |邻家男孩 2.0 |zh_male_linjiananhai_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|角色扮演 |四郎 2.0 |zh_male_silang_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|通用场景 |儒雅青年 2.0 |zh_male_ruyaqingnian_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |番茄小说同款,豆包同款,剪映同款 |
|角色扮演 |擎苍 2.0 |zh_male_qingcang_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |番茄小说同款,豆包同款,抖音同款,剪映同款 |
|角色扮演 |熊二 2.0 |zh_male_xionger_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|角色扮演 |樱桃丸子 2.0 |zh_female_yingtaowanzi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|通用场景 |温暖阿虎 2.0 |zh_male_wennuanahu_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |奶气萌娃 2.0 |zh_male_naiqimengwa_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |剪映同款,豆包同款 |
|通用场景 |婆婆 2.0 |zh_female_popo_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|通用场景 |高冷御姐 2.0 |zh_female_gaolengyujie_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |傲娇霸总 2.0 |zh_male_aojiaobazong_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|角色扮演 |懒音绵宝 2.0 |zh_male_lanyinmianbao_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |反卷青年 2.0 |zh_male_fanjuanqingnian_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |温柔淑女 2.0 |zh_female_wenroushunv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |番茄小说同款,豆包同款,剪映同款 |
|角色扮演 |古风少御 2.0 |zh_female_gufengshaoyu_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |活力小哥 2.0 |zh_male_huolixiaoge_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|有声阅读 |霸气青叔 2.0 |zh_male_baqiqingshu_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |番茄小说同款,豆包同款,剪映同款 |
|有声阅读 |悬疑解说 2.0 |zh_male_xuanyijieshuo_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|通用场景 |萌丫头 2.0 |zh_female_mengyatou_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |贴心女声 2.0 |zh_female_tiexinnvsheng_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |鸡汤妹妹 2.0 |zh_female_jitangmei_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款 |
|通用场景 |磁性解说男声 2.0 |zh_male_cixingjieshuonan_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,剪映同款 |
|通用场景 |亮嗓萌仔 2.0 |zh_male_liangsangmengzai_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |开朗姐姐 2.0 |zh_female_kailangjiejie_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |高冷沉稳 2.0 |zh_male_gaolengchenwen_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |猫箱同款 |
|通用场景 |深夜播客 2.0 |zh_male_shenyeboke_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|角色扮演 |鲁班七号 2.0 |zh_male_lubanqihao_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|通用场景 |娇喘女声 2.0 |zh_female_jiaochuannv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,剪映同款 |
|角色扮演 |林潇 2.0 |zh_female_linxiao_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|角色扮演 |玲玲姐姐 2.0 |zh_female_lingling_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|角色扮演 |春日部姐姐 2.0 |zh_female_chunribu_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款,剪映同款 |
|角色扮演 |唐僧 2.0 |zh_male_tangseng_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,豆包同款 |
|角色扮演 |庄周 2.0 |zh_male_zhuangzhou_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,剪映同款 |
|通用场景 |开朗弟弟 2.0 |zh_male_kailangdidi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,剪映同款 |
|角色扮演 |猪八戒 2.0 |zh_male_zhubajie_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |豆包同款,剪映同款 |
|角色扮演 |感冒电音姐姐 2.0 |zh_female_ganmaodianyin_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,剪映同款 |
|通用场景 |谄媚女声 2.0 |zh_female_chanmeinv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,剪映同款 |
|角色扮演 |女雷神 2.0 |zh_female_nvleishen_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |剪映同款,豆包同款 |
|通用场景 |亲切女声 2.0 |zh_female_qinqienv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |豆包同款 |
|通用场景 |快乐小东 2.0 |zh_male_kuailexiaodong_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |豆包同款 |
|通用场景 |开朗学长 2.0 |zh_male_kailangxuezhang_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |豆包同款 |
|通用场景 |悠悠君子 2.0 |zh_male_youyoujunzi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |豆包同款 |
|通用场景 |文静毛毛 2.0 |zh_female_wenjingmaomao_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |豆包同款 |
|通用场景 |知性女声 2.0 |zh_female_zhixingnv_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |清爽男大 2.0 |zh_male_qingshuangnanda_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |豆包同款 |
|通用场景 |渊博小叔 2.0 |zh_male_yuanboxiaoshu_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |阳光青年 2.0 |zh_male_yangguangqingnian_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |清澈梓梓 2.0 |zh_female_qingchezizi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |甜美悦悦 2.0 |zh_female_tianmeiyueyue_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |心灵鸡汤 2.0 |zh_female_xinlingjitang_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |温柔小哥 2.0 |zh_male_wenrouxiaoge_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |柔美女友 2.0 |zh_female_roumeinvyou_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |东方浩然 2.0 |zh_male_dongfanghaoran_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |温柔小雅 2.0 |zh_female_wenrouxiaoya_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|通用场景 |天才童声 2.0 |zh_male_tiancaitongsheng_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|角色扮演 |武则天 2.0 |zh_female_wuzetian_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |剪映同款 |
|角色扮演 |顾姐 2.0 |zh_female_gujie_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |抖音同款,剪映同款 |
|通用场景 |广告解说 2.0 |zh_male_guanggaojieshuo_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) |剪映同款 |
|有声阅读 |少儿故事 2.0 |zh_female_shaoergushi_uranus_bigtts |中文、支持30+语种识别 |[指令遵循](https://www.volcengine.com/docs/6561/1871062?lang=zh) | |
|外语音色 |Charlie 2.0 |ICL_uranus_en_female_charlie_tob |美式英语 | | |
|外语音色 |Ethan 2.0 |ICL_uranus_en_male_ethan_tob |澳洲英语 | | |
|外语音色 |Alastor 2.0 |ICL_uranus_en_male_alastor_tob |英式英语 | | |
|外语音色 |Chucky 2.0 |ICL_uranus_en_male_chucky_tob |美式英语 | | |
|外语音色 |Noah 2.0 |ICL_uranus_en_male_noah_tob |美式英语 | | |
|外语音色 |Jigsaw 2.0 |ICL_uranus_en_male_jigsaw_tob |美式英语 | | |
|外语音色 |Clown Man 2.0 |ICL_uranus_en_male_clown_man_tob |美式英语 | | |
|外语音色 |Cartoon Chef 2.0 |ICL_uranus_en_male_cartoon_chef_tob |美式英语 | | |
|外语音色 |Frosty Man 2.0 |ICL_uranus_en_male_frosty_man_tob |美式英语 | |豆包同款 |
|外语音色 |The Grinch 2.0 |ICL_uranus_en_male_the_grinch_tob |美式英语 | |豆包同款 |
|外语音色 |Kevin McCallister 2.0 |ICL_uranus_en_male_kevin_mccallister_tob |美式英语 | |豆包同款 |
|外语音色 |Michael 2.0 |ICL_uranus_en_male_michael_tob |美式英语 | |豆包同款 |
|外语音色 |Big Boogie 2.0 |ICL_uranus_en_male_big_boogie_tob |美式英语 | |豆包同款 |
|外语音色 |Xavier 2.0 |ICL_uranus_en_male_xavier_tob |美式英语 | | |
|外语音色 |Zayne 2.0 |ICL_uranus_en_male_zayne_tob |美式英语 | | |
|客服场景 |客服婉君 2.0 |ICL_uranus_zh_female_kefuwanjun_tob |中文 | | |
|客服场景 |营销小楠 2.0 |ICL_uranus_zh_female_yingxiaokefu_v2_tob |中文 | | |
|角色扮演,S2S\-SC |傲娇女友 2.0 |ICL_uranus_zh_female_aojiaonvyou_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |傲慢娇声 2.0 |ICL_uranus_zh_female_aomanjiaosheng_tob |中文 | |猫箱同款 |
|角色扮演 |邪魅女王 2.0 |ICL_uranus_zh_female_xiemeinvwang_tob |中文 | | |
|角色扮演,S2S\-SC |病娇姐姐 2.0 |ICL_uranus_zh_female_bingjiaojiejie_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |病娇萌妹 2.0 |ICL_uranus_zh_female_bingjiaomengmei_tob |中文 | |猫箱同款 |
|角色扮演 |病弱少女 2.0 |ICL_uranus_zh_female_bingruoshaonv_tob |中文 | | |
|角色扮演 |成熟温柔 2.0 |ICL_uranus_zh_female_chengshuwenrou_tob |中文 | |猫箱同款 |
|角色扮演,S2S\-SC |成熟姐姐 2.0 |ICL_uranus_zh_female_chengshujiejie_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |纯真少女 2.0 |ICL_uranus_zh_female_chunzhenshaonv_tob |中文 | |豆包同款 |
|通用场景 |纯澈女生 2.0 |ICL_uranus_zh_female_chunchenvsheng_tob |中文 | | |
|角色扮演 |妩媚可人 2.0 |ICL_uranus_zh_female_wumeikeren_tob |中文 | | |
|客服场景 |乖巧可儿 2.0 |ICL_uranus_zh_female_guaiqiaokeer_tob |中文 | | |
|视频配音 |和蔼奶奶 2.0 |ICL_uranus_zh_female_heainainai_tob |中文 | | |
|角色扮演 |活泼刁蛮 2.0 |ICL_uranus_zh_female_huopodiaoman_tob |中文 | |猫箱同款 |
|角色扮演 |活泼女孩 2.0 |ICL_uranus_zh_female_huoponvhai_tob |中文 | | |
|角色扮演 |娇憨女王 2.0 |ICL_uranus_zh_female_jiaohannvwang_tob |中文 | |猫箱同款 |
|角色扮演 |娇弱萝莉 2.0 |ICL_uranus_zh_female_jiaoruoluoli_tob |中文 | |猫箱同款 |
|角色扮演 |假小子 2.0 |ICL_uranus_zh_female_jiaxiaozi_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |精灵向导 2.0 |ICL_uranus_zh_female_jinglingxiangdao_tob |中文 | |豆包同款 |
|客服场景 |开朗婷婷 2.0 |ICL_uranus_zh_female_kailangtingting_tob |中文 | | |
|客服场景 |外呼凌凌 2.0 |ICL_uranus_zh_female_kefunvshengwenhecuishou_tob |中文 | | |
|客服场景 |开心小鸿 2.0 |ICL_uranus_zh_female_kaixinxiaohong_tob |中文 | | |
|角色扮演,S2S\-SC |可爱女生 2.0 |ICL_uranus_zh_female_keainvsheng_tob |中文 | |猫箱同款 |
|客服场景 |灵动欣欣 2.0 |ICL_uranus_zh_female_lingdongxinxin_tob |中文 | | |
|视频配音 |邻居阿姨 2.0 |ICL_uranus_zh_female_linjuayi_tob |中文 | | |
|角色扮演 |甜美娇俏 2.0 |ICL_uranus_zh_female_tianmeijiaoqiao_tob |中文 | |猫箱同款 |
|角色扮演 |清冷高雅 2.0 |ICL_uranus_zh_female_qinglenggaoya_tob |中文 | |猫箱同款 |
|客服场景 |理性圆子 2.0 |ICL_uranus_zh_female_lixingyuanzi_tob |中文 | | |
|角色扮演 |性感魅惑 2.0 |ICL_uranus_zh_female_xingganmeihuo_tob |中文 | | |
|客服场景 |暖心茜茜 2.0 |ICL_uranus_zh_female_nuanxinqianqian_tob |中文 | | |
|角色扮演,S2S\-SC |暖心学姐 2.0 |ICL_uranus_zh_female_nuanxinxuejie_tob |中文 | |猫箱同款 |
|客服场景 |清甜莓莓 2.0 |ICL_uranus_zh_female_qingtianmeimei_tob |中文 | | |
|客服场景 |清甜桃桃 2.0 |ICL_uranus_zh_female_qingtiantaotao_tob |中文 | | |
|客服场景 |清晰小雪 2.0 |ICL_uranus_zh_female_qingxixiaoxue_tob |中文 | | |
|视频配音 |倾心少女 2.0 |ICL_uranus_zh_female_qingxinshaonv_tob |中文 | | |
|角色扮演 |柔骨魂师 2.0 |ICL_uranus_zh_female_rouguhunshi_tob |中文 | |猫箱同款 |
|客服场景 |软萌糖糖 2.0 |ICL_uranus_zh_female_ruanmengtangtang_tob |中文 | | |
|客服场景 |软萌团子 2.0 |ICL_uranus_zh_female_ruanmengtuanzi_tob |中文 | | |
|角色扮演 |甜美活泼 2.0 |ICL_uranus_zh_female_tianmeihuopo_tob |中文 | |猫箱同款 |
|客服场景 |甜美小橘 2.0 |ICL_uranus_zh_female_tianmeixiaoju_tob |中文 | | |
|客服场景 |甜美小雨 2.0 |ICL_uranus_zh_female_tianmeixiaoyu_tob |中文 | | |
|角色扮演 |调皮公主 2.0 |ICL_uranus_zh_female_tiaopigongzhu_tob |中文 | |猫箱同款 |
|角色扮演,S2S\-SC |贴心女友 2.0 |ICL_uranus_zh_female_tiexinnvyou_tob |中文 | |豆包同款,猫箱同款 |
|通用场景 |温柔女神 2.0 |ICL_uranus_zh_female_wenrounvshen_tob |中文 | |豆包同款 |
|通用场景,S2S\-SC |温柔文雅 2.0 |ICL_uranus_zh_female_wenrouwenya_tob |中文 | |猫箱同款 |
|通用场景 |知心姐姐 2.0 |ICL_uranus_zh_female_zhixinjiejie_tob |中文 | | |
|角色扮演,S2S\-SC |妩媚御姐 2.0 |ICL_uranus_zh_female_wumeiyujie_tob |中文 | |豆包同款 |
|通用场景 |元气甜妹 2.0 |ICL_uranus_zh_female_yuanqitianmei_tob |中文 | | |
|角色扮演 |邪魅御姐 2.0 |ICL_uranus_zh_female_xiemeiyujie_tob |中文 | | |
|角色扮演,S2S\-SC |性感御姐 2.0 |ICL_uranus_zh_female_xingganyujie_tob |中文 | |豆包同款,猫箱同款 |
|客服场景 |秀丽倩倩 2.0 |ICL_uranus_zh_female_xiuliqianqian_tob |中文 | | |
|通用场景 |贴心闺蜜 2.0 |ICL_uranus_zh_female_tiexinguimi_tob |中文 | | |
|通用场景 |贴心妹妹 2.0 |ICL_uranus_zh_female_tiexinmeimei_tob |中文 | | |
|通用场景 |温柔白月光 2.0 |ICL_uranus_zh_female_wenroubaiyueguang_tob |中文 | | |
|通用场景 |初恋女友 2.0 |ICL_uranus_zh_female_chuliannvyou_tob |中文 | | |
|通用场景 |知性温婉 2.0 |ICL_uranus_zh_female_zhixingwenwan_tob |中文 | |猫箱同款 |
|角色扮演,S2S\-SC |傲气凌人 2.0 |ICL_uranus_zh_male_aoqilingren_tob |中文 | |猫箱同款 |
|角色扮演 |黯刃秦主 2.0 |ICL_uranus_zh_male_anrenqinzhu_tob |中文 | |豆包同款 |
|角色扮演,S2S\-SC |傲娇公子 2.0 |ICL_uranus_zh_male_aojiaogongzi_tob |中文 | | |
|角色扮演,S2S\-SC |傲娇精英 2.0 |ICL_uranus_zh_male_aojiaojingying_tob |中文 | | |
|角色扮演 |傲慢青年 2.0 |ICL_uranus_zh_male_aomanqingnian_tob |中文 | | |
|角色扮演,S2S\-SC |傲慢少爷 2.0 |ICL_uranus_zh_male_aomanshaoye_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |枕边低语 2.0 |ICL_uranus_zh_male_zhenbiandiyu_tob |中文 | |抖音同款 |
|角色扮演,S2S\-SC |霸道少爷 2.0 |ICL_uranus_zh_male_badaoshaoye_tob |中文 | | |
|角色扮演 |霸道总裁 2.0 |ICL_uranus_zh_male_badaozongcai_tob |中文 | | |
|角色扮演,S2S\-SC |病娇白莲 2.0 |ICL_uranus_zh_male_bingjiaobailian_tob |中文 | |猫箱同款 |
|角色扮演,S2S\-SC |病娇弟弟 2.0 |ICL_uranus_zh_male_bingjiaodidi_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |病娇哥哥 2.0 |ICL_uranus_zh_male_bingjiaogege_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |病娇男友 2.0 |ICL_uranus_zh_male_bingjiaonanyou_tob |中文 | | |
|角色扮演 |病娇少年 2.0 |ICL_uranus_zh_male_bingjiaoshaonian_tob |中文 | | |
|角色扮演 |病弱公子 2.0 |ICL_uranus_zh_male_bingruogongzi_tob |中文 | |豆包同款 |
|角色扮演 |病弱少年 2.0 |ICL_uranus_zh_male_bingruoshaonian_tob |中文 | | |
|角色扮演 |不羁青年 2.0 |ICL_uranus_zh_male_bujiqingnian_tob |中文 | | |
|视频配音 |醇厚低音 2.0 |ICL_uranus_zh_male_chunhoudiyin_tob |中文 | | |
|视频配音 |咆哮小哥 2.0 |ICL_uranus_zh_male_paoxiaoxiaoge_tob |中文 | | |
|通用场景 |炀炀 2.0 |ICL_uranus_zh_male_yangyang_tob |中文 | | |
|角色扮演 |孱弱少爷 2.0 |ICL_uranus_zh_male_chanruoshaoye_tob |中文 | | |
|角色扮演,S2S\-SC |成熟总裁 2.0 |ICL_uranus_zh_male_chengshuzongcai_tob |中文 | | |
|客服场景 |沉稳明仔 2.0 |ICL_uranus_zh_male_chenwenmingzai_tob |中文 | | |
|角色扮演 |清逸苏感 2.0 |ICL_uranus_zh_male_qingyisugan_tob |中文 | |猫箱同款 |
|角色扮演 |纯真学弟 2.0 |ICL_uranus_zh_male_chunzhenxuedi_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演,S2S\-SC |磁性男嗓 2.0 |ICL_uranus_zh_male_cixingnansang_tob |中文 | | |
|角色扮演 |醋精男生 2.0 |ICL_uranus_zh_male_cujingnansheng_tob |中文 | | |
|角色扮演,S2S\-SC |醋精男友 2.0 |ICL_uranus_zh_male_cujingnanyou_tob |中文 | | |
|角色扮演 |低音沉郁 2.0 |ICL_uranus_zh_male_diyinchenyu_tob |中文 | | |
|角色扮演,S2S\-SC |风发少年 2.0 |ICL_uranus_zh_male_fengfashaonian_tob |中文 | | |
|有声阅读 |儒雅公子 2.0 |ICL_uranus_zh_male_ruyagongzi_tob |中文 | | |
|角色扮演,S2S\-SC |腹黑公子 2.0 |ICL_uranus_zh_male_fuheigongzi_tob |中文 | |猫箱同款 |
|角色扮演 |干净少年 2.0 |ICL_uranus_zh_male_ganjingshaonian_tob |中文 | | |
|角色扮演 |高冷总裁 2.0 |ICL_uranus_zh_male_gaolengzongcai_tob |中文 | | |
|角色扮演 |孤傲公子 2.0 |ICL_uranus_zh_male_guaogongzi_tob |中文 | |豆包同款 |
|角色扮演 |孤高公子 2.0 |ICL_uranus_zh_male_gugaogongzi_tob |中文 | | |
|角色扮演 |诡异神秘 2.0 |ICL_uranus_zh_male_guiyishenmi_tob |中文 | |猫箱同款 |
|角色扮演 |固执病娇 2.0 |ICL_uranus_zh_male_guzhibingjiao_tob |中文 | |猫箱同款 |
|角色扮演 |憨厚敦实 2.0 |ICL_uranus_zh_male_hanhoudunshi_tob |中文 | |猫箱同款 |
|角色扮演 |活力青年 2.0 |ICL_uranus_zh_male_huoliqingnian_tob |中文 | | |
|角色扮演 |活泼男友 2.0 |ICL_uranus_zh_male_huoponanyou_tob |中文 | | |
|通用场景 |活泼爽朗 2.0 |ICL_uranus_zh_male_huoposhuanglang_tob |中文 | |猫箱同款 |
|角色扮演 |胡子叔叔 2.0 |ICL_uranus_zh_male_huzishushu_tob |中文 | | |
|角色扮演 |机甲智能 2.0 |ICL_uranus_zh_male_jijiazhineng_tob |中文 | | |
|角色扮演 |精英青年 2.0 |ICL_uranus_zh_male_jingyingqingnian_tob |中文 | | |
|角色扮演 |俊逸公子 2.0 |ICL_uranus_zh_male_junyigongzi_tob |中文 | | |
|通用场景 |开朗轻快 2.0 |ICL_uranus_zh_male_kailangqingkuai_tob |中文 | |猫箱同款 |
|角色扮演 |开朗青年 2.0 |ICL_uranus_zh_male_kailangqingnian_tob |中文 | | |
|角色扮演 |蓝银草魂师 2.0 |ICL_uranus_zh_male_lanyincaohunshi_tob |中文 | |猫箱同款 |
|角色扮演 |冷傲总裁 2.0 |ICL_uranus_zh_male_lengaozongcai_tob |中文 | | |
|角色扮演 |冷淡疏离 2.0 |ICL_uranus_zh_male_lengdanshuli_tob |中文 | |猫箱同款 |
|角色扮演 |冷峻高智 2.0 |ICL_uranus_zh_male_lengjungaozhi_tob |中文 | | |
|角色扮演 |冷峻上司 2.0 |ICL_uranus_zh_male_lengjunshangsi_tob |中文 | |豆包同款,猫箱同款 |
|通用场景 |冷酷哥哥 2.0 |ICL_uranus_zh_male_lengkugege_tob |中文 | |豆包同款 |
|角色扮演 |冷脸兄长 2.0 |ICL_uranus_zh_male_lenglianxiongzhang_tob |中文 | | |
|角色扮演 |冷脸学霸 2.0 |ICL_uranus_zh_male_lenglianxueba_tob |中文 | | |
|角色扮演 |冷漠男友 2.0 |ICL_uranus_zh_male_lengmonanyou_tob |中文 | | |
|角色扮演 |冷漠兄长 2.0 |ICL_uranus_zh_male_lengmoxiongzhang_tob |中文 | | |
|角色扮演 |凌云青年 2.0 |ICL_uranus_zh_male_lingyunqingnian_tob |中文 | | |
|角色扮演 |清冷矜贵 2.0 |ICL_uranus_zh_male_qinglengjingui_tob |中文 | |猫箱同款 |
|角色扮演 |绿茶小哥 2.0 |ICL_uranus_zh_male_lvchaxiaoge_tob |中文 | |猫箱同款 |
|角色扮演 |懵懂青年 2.0 |ICL_uranus_zh_male_mengdongqingnian_tob |中文 | | |
|角色扮演 |闷油瓶小哥 2.0 |ICL_uranus_zh_male_menyoupingxiaoge_tob |中文 | |豆包同款 |
|角色扮演 |嚣张小哥 2.0 |ICL_uranus_zh_male_xiaozhangxiaoge_tob |中文 | | |
|角色扮演 |粘人男友 2.0 |ICL_uranus_zh_male_nianrennanyou_tob |中文 | | |
|有声阅读 |内敛才俊 2.0 |ICL_uranus_zh_male_neiliancaijun_tob |中文 | | |
|通用场景 |暖心体贴 2.0 |ICL_uranus_zh_male_nuanxintitie_tob |中文 | |猫箱同款 |
|角色扮演 |翩翩公子 2.0 |ICL_uranus_zh_male_pianpiangongzi_tob |中文 | | |
|角色扮演 |沉稳优雅 2.0 |ICL_uranus_zh_male_chenwenyouya_tob |中文 | |猫箱同款 |
|角色扮演 |青涩小生 2.0 |ICL_uranus_zh_male_qingsexiaosheng_tob |中文 | |猫箱同款 |
|角色扮演 |青涩青年 2.0 |ICL_uranus_zh_male_qingseqingnian_tob |中文 | | |
|角色扮演 |清爽少年 2.0 |ICL_uranus_zh_male_qingshuangshaonian_tob |中文 | | |
|客服场景 |清新波波 2.0 |ICL_uranus_zh_male_qingxinbobo_tob |中文 | | |
|角色扮演 |亲切青年 2.0 |ICL_uranus_zh_male_qinqieqingnian_tob |中文 | | |
|客服场景 |亲切小卓 2.0 |ICL_uranus_zh_male_qinqiexiaozhuo_tob |中文 | | |
|角色扮演 |清朗温润 2.0 |ICL_uranus_zh_male_qinglangwenrun_tob |中文 | |猫箱同款 |
|角色扮演 |热血少年 2.0 |ICL_uranus_zh_male_rexueshaonian_tob |中文 | | |
|角色扮演 |儒雅才俊 2.0 |ICL_uranus_zh_male_ruyacaijun_tob |中文 | |猫箱同款 |
|角色扮演 |儒雅君子 2.0 |ICL_uranus_zh_male_ruyajunzi_tob |中文 | | |
|角色扮演 |儒雅总裁 2.0 |ICL_uranus_zh_male_ruyazongcai_tob |中文 | | |
|角色扮演 |撒娇男生 2.0 |ICL_uranus_zh_male_sajiaonansheng_tob |中文 | | |
|角色扮演 |撒娇男友 2.0 |ICL_uranus_zh_male_sajiaonanyou_tob |中文 | | |
|角色扮演 |撒娇粘人 2.0 |ICL_uranus_zh_male_sajiaonianren_tob |中文 | |猫箱同款 |
|角色扮演 |洒脱青年 2.0 |ICL_uranus_zh_male_satuoqingnian_tob |中文 | | |
|角色扮演 |少年将军 2.0 |ICL_uranus_zh_male_shaonianjiangjun_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |深沉总裁 2.0 |ICL_uranus_zh_male_shenchenzongcai_tob |中文 | | |
|通用场景 |机灵小伙 2.0 |ICL_uranus_zh_male_jilingxiaohuo_tob |中文 | | |
|角色扮演 |神秘法师 2.0 |ICL_uranus_zh_male_shenmifashi_tob |中文 | |豆包同款,猫箱同款 |
|通用场景 |率真小伙 2.0 |ICL_uranus_zh_male_shuaizhenxiaohuo_tob |中文 | |猫箱同款 |
|客服场景 |爽朗小阳 2.0 |ICL_uranus_zh_male_shuanglangxiaoyang_tob |中文 | | |
|角色扮演 |低沉缱绻 2.0 |ICL_uranus_zh_male_dichenqianquan_tob |中文 | |猫箱同款 |
|角色扮演 |斯文青年 2.0 |ICL_uranus_zh_male_siwenqingnian_tob |中文 | | |
|角色扮演 |甜系男友 2.0 |ICL_uranus_zh_male_tianxinanyou_tob |中文 | | |
|角色扮演 |贴心男友 2.0 |ICL_uranus_zh_male_tiexinnanyou_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |温柔男同桌 2.0 |ICL_uranus_zh_male_wenrounantongzhuo_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |温柔男友 2.0 |ICL_uranus_zh_male_wenrounanyou_tob |中文 | | |
|角色扮演 |温柔学长 2.0 |ICL_uranus_zh_male_wenrouxuezhang_tob |中文 | | |
|角色扮演 |温润学者 2.0 |ICL_uranus_zh_male_wenrunxuezhe_tob |中文 | | |
|角色扮演 |温顺少年 2.0 |ICL_uranus_zh_male_wenshunshaonian_tob |中文 | | |
|角色扮演 |寡言小哥 2.0 |ICL_uranus_zh_male_guayanxiaoge_tob |中文 | |猫箱同款 |
|角色扮演 |小侯爷 2.0 |ICL_uranus_zh_male_xiaohouye_tob |中文 | | |
|角色扮演 |奶气小生 2.0 |ICL_uranus_zh_male_naiqixiaosheng_tob |中文 | |豆包同款 |
|角色扮演 |潇洒随性 2.0 |ICL_uranus_zh_male_xiaosasuixing_tob |中文 | |猫箱同款 |
|角色扮演 |温柔内敛 2.0 |ICL_uranus_zh_male_wenrouneilian_tob |中文 | |猫箱同款 |
|角色扮演 |学霸男同桌 2.0 |ICL_uranus_zh_male_xuebanantongzhuo_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |学霸同桌 2.0 |ICL_uranus_zh_male_xuebatongzhuo_tob |中文 | | |
|客服场景 |阳光洋洋 2.0 |ICL_uranus_zh_male_yangguangyangyang_tob |中文 | | |
|有声阅读 |温暖少年 2.0 |ICL_uranus_zh_male_wennuanshaonian_tob |中文 | | |
|角色扮演 |意气少年 2.0 |ICL_uranus_zh_male_yiqishaonian_tob |中文 | | |
|角色扮演 |油腻大叔 2.0 |ICL_uranus_zh_male_younidashu_tob |中文 | | |
|角色扮演 |幽默大爷 2.0 |ICL_uranus_zh_male_youmodaye_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |幽默叔叔 2.0 |ICL_uranus_zh_male_youmoshushu_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |优柔帮主 2.0 |ICL_uranus_zh_male_youroubangzhu_tob |中文 | |猫箱同款 |
|角色扮演 |优柔公子 2.0 |ICL_uranus_zh_male_yourougongzi_tob |中文 | |豆包同款,猫箱同款 |
|角色扮演 |元气少年 2.0 |ICL_uranus_zh_male_yuanqishaonian_tob |中文 | | |
|角色扮演 |仗剑君子 2.0 |ICL_uranus_zh_male_zhangjianjunzi_tob |中文 | | |
|角色扮演 |仗剑侠客 2.0 |ICL_uranus_zh_male_zhangjianxiake_tob |中文 | | |
|角色扮演 |正直青年 2.0 |ICL_uranus_zh_male_zhengzhiqingnian_tob |中文 | |猫箱同款 |
|角色扮演 |直率青年 2.0 |ICL_uranus_zh_male_zhishuaiqingnian_tob |中文 | | |
|角色扮演 |中二青年 2.0 |ICL_uranus_zh_male_zhongerqingnian_tob |中文 | | |
|角色扮演 |自负青年 2.0 |ICL_uranus_zh_male_zifuqingnian_tob |中文 | | |
|角色扮演 |自信青年 2.0 |ICL_uranus_zh_male_zixinqingnian_tob |中文 | | |
|角色扮演 |天才同桌 2.0 |ICL_uranus_zh_male_tiancaitongzhuo_tob |中文 | | |
|客服场景 |清新沐沐 2.0 |ICL_uranus_zh_male_qingxinmumu_tob |中文 | | |
|客服场景 |温婉珊珊 2.0 |ICL_uranus_zh_female_wenwanshanshan_tob |中文 | | |
|客服场景 |热情艾娜 2.0 |ICL_uranus_zh_female_reqingaina_tob |中文 | | |
|角色扮演 |爽朗少年 2.0 |ICL_uranus_zh_male_shuanglangshaonian_tob |中文 | | |
|客服场景 |轻盈朵朵 2.0 |ICL_uranus_zh_female_qingyingduoduo_tob |中文 | | |


<span id="7833abf9"></span>
##  **"豆包语音合成模型2.0" 外语音色列表**

> 注意：有16个音色仅限单向流使用，不支持双向流，具体可见表格备注部分；



|**场景** |**音色名称** |**voice_type** |**语种/方言** |**推荐推理模式** |**支持能力** |**备注** |
|---|---|---|---|---|---|---|
|通用场景, 视频配音,外语音色,阿拉伯语 |Dina |ar_female_dina_uranus_bigtts |阿拉伯语（埃及口音） |QA |情感变化、指令遵循 | |
|趣味口音,外语音色,阿拉伯语 |Fatma |ar_female_fatma_uranus_bigtts |阿拉伯语 |QA |情感变化、指令遵循 | |
|通用场景,有声阅读,外语音色,阿拉伯语 |Youssef |ar_male_youssef_uranus_bigtts |阿拉伯语 |QA |情感变化、指令遵循 | |
|教学场景, 客服场景,外语音色,德语 |Stella |de_female_bv081_uranus_bigtts |德语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,外语音色,德语 |Sven |de_male_sven_uranus_bigtts |德语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|通用场景,有声阅读,美式英语,外语音色 |Rowan |en_male_adam\-imitation_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,美式英语,外语音色 |Alberto |en_male_alberto_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Alex |en_male_alex_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|视频配音,美式英语,外语音色 |Allison |en_female_allison_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|教学场景, 视频配音,英式英语,外语音色 |Charlotte |en_female_authoritative\-british_uranus_bigtts |英式英语 |QA |情感变化、指令遵循 | |
|通用场景,有声阅读,美式英语,外语音色 |Margaret |en_female_authoritative\-informative_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音,美式英语,外语音色 |Jones |en_male_bill\-jones_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Bill |en_male_bill_jones_corey_uranus_bigtts |美式英语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|通用场景, 视频配音,美式英语,外语音色 |Brad_Pitt |en_male_brad_pitt_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Brittney |en_female_brittney_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|有声阅读, 客服场景,美式英语,外语音色 |Zoe |en_female_brittney_pimintel_uranus_bigtts |美式英语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|通用场景, 视频配音,美式英语,外语音色 |Adrian |en_male_bruce_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音,美式英语,外语音色 |Leo |en_male_chandler_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,美式英语,外语音色 |Bob |en_male_cowboy\-bob_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音, 角色扮演,美式英语,外语音色 |John |en_male_cowboy_john_b_uranus_bigtts |美式英语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|通用场景,有声阅读,美式英语,外语音色 |David |en_male_david_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音, 角色扮演,美式英语,外语音色 |Orion |en_male_deep\-voice_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|有声阅读,美式英语,外语音色 |Julian |en_male_diyuwenrounan_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|视频配音,美式英语,外语音色 |Harrison |en_male_evil\-guy\-oxley_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音,美式英语,外语音色 |Jasper |en_male_excited\-male\-voice_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景,有声阅读, 视频配音,英式英语,外语音色 |Alfred |en_male_father\-christmas_uranus_bigtts |英式英语 |QA |情感变化、指令遵循 | |
|教学场景, 视频配音,美式英语,外语音色 |Holly |en_female_female_tutor_ms\-jenny_uranus_bigtts |美式英语 |Context |情感变化、上下文遵循 | |
|通用场景, 教学场景,美式英语,外语音色 |Felix |en_male_fernando\-martinez_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|有声阅读, 角色扮演,美式英语,外语音色 |Godfather |en_male_godfather_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|角色扮演,美式英语,外语音色 |Gollum |en_male_gollum_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Beau |en_male_hades_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|教学场景, 视频配音,美式英语,外语音色 |Hayley |en_female_hayley_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景, 视频配音,美式英语,外语音色 |Jamie |en_male_jamie_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|视频配音,美式英语,外语音色 |Jane |en_female_jane_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,美式英语,外语音色 |Jenny |en_female_jenny_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音, 角色扮演,美式英语,外语音色 |Blaze |en_male_jidongchuanjiaoshi_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Jimmy |en_male_jimmy_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景,有声阅读, 视频配音,美式英语,外语音色 |Joanne |en_female_joanne_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音, 视频配音,美式英语,外语音色 |Joker |en_male_joker_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|视频配音,美式英语,外语音色 |Josh |en_male_josh_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|教学场景, 视频配音,美式英语,外语音色 |Josiah |en_male_josh_coery_uranus_bigtts |美式英语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|教学场景, 视频配音,美式英语,外语音色 |Kevin |en_male_kevin_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|有声阅读,英式英语,外语音色 |Knightley |en_male_knightley_uranus_bigtts |英式英语 |QA |情感变化、指令遵循 | |
|角色扮演,美式英语,外语音色 |Lynn |en_female_lana_del_rey_kelley_d_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|客服场景,美式英语,外语音色 |Ivy |en_female_lana_del_rey_parky_s_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景,有声阅读,美式英语,外语音色 |Marcus |en_male_marcus_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|教学场景, 客服场景,美式英语,外语音色 |Mel |en_female_mel_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,美式英语,外语音色 |Hank |en_male_michael_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音, 角色扮演,美式英语,外语音色 |Chip |en_male_michael\-mouse_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,美式英语,外语音色 |Michael_Kevin |en_male_michael_kevin_uranus_bigtts |美式英语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|趣味口音, 视频配音,美式英语,外语音色 |Rory |en_male_motivational\-coach_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|教学场景,美式英语,外语音色 |Myra |en_female_myra_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|教学场景, 客服场景,美式英语,外语音色 |Sunny |en_female_myra_cmb_uranus_bigtts |美式英语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|通用场景, 视频配音,美式英语,外语音色 |Blair |en_female_nadia_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Natasha |en_female_natasha_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|有声阅读,视频配音,美式英语,外语音色 |Elaine |en_female_pleasant\-female_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音,美式英语,外语音色 |Rachel |en_female_rachel_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|有声阅读,美式英语,外语音色 |Ronald |en_male_ronald_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,英式英语,外语音色 |Russell |en_male_russell_uranus_bigtts |英式英语 |QA |情感变化、指令遵循 | |
|客服场景,美式英语,外语音色 |Scarlet |en_female_scarlet_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|趣味口音,美式英语,外语音色 |Sharron |en_female_sharron_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Simba |en_male_simba_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景,美式英语,外语音色 |Skye |en_female_skye_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景,有声阅读,美式英语,外语音色 |Tom |en_male_tom_hiddleston_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Valentino |en_male_valentino_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|视频配音,美式英语,外语音色 |Clark |en_male_valentino_corey_uranus_bigtts |美式英语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|客服场景,美式英语,外语音色 |Megan |en_female_wenrouzhishijieshuonv_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|角色扮演,美式英语,外语音色 |Kayla |en_female_xinwenjieshuonv_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,美式英语,外语音色 |Dylan |en_male_yangguangjieshuonan_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|教学场景, 客服场景,美式英语,外语音色 |Zendaya |en_female_zendaya_p1_uranus_bigtts |美式英语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,外语音色,西班牙语 |Gracie |es_female_bv084_uranus_bigtts |西班牙语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,西班牙语 |Dani |es_male_dani_uranus_bigtts |西班牙语 |QA |情感变化、指令遵循 | |
|有声阅读,外语音色,西班牙语 |Guillem |es_male_guillem_uranus_bigtts |西班牙语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,西班牙语 |Marisol |es_female_ht_mx_f6_uranus_bigtts |西班牙语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,法语 |Simone |fr_female_fr_bv078_uranus_bigtts |法语 |QA |情感变化、指令遵循 | |
|教学场景, 客服场景,外语音色,法语 |Camille |fr_female_fr_f47_uranus_bigtts |法语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,法语 |Maurice |fr_male_fr_m29_uranus_bigtts |法语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,外语音色,法语 |Usseau |fr_male_usseau_uranus_bigtts |法语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|通用场景, 视频配音,外语音色,印尼语 |Rocco |id_male_bv160_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,印尼语 |Jude |id_male_bv160dialogue_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,印尼语 |Hugo |id_male_bv160narration_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,印尼语 |Clara |id_female_bv161_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,印尼语 |Sylvia |id_female_bv161dialogue_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,印尼语 |Celeste |id_female_bv161narration_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,印尼语 |Crew |id_female_bv164_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|视频配音,外语音色,印尼语 |Elian |id_male_bv164dialogue_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,印尼语 |Ronan |id_male_bv164narration_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|视频配音,外语音色,印尼语 |Chloe |id_female_f20_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|通用场景,外语音色,印尼语 |Han |id_male_han_uranus_bigtts |印尼语 |Context |情感变化、指令遵循、上下文遵循 | |
|通用场景, 教学场景,外语音色,印尼语 |Kyle |id_male_m08_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,印尼语 |Phulia |id_female_phulia_uranus_bigtts |印尼语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,外语音色,日语 |Bonnie |ja_female_bv024_uranus_bigtts |日语 |QA |情感变化、指令遵循 | |
|视频配音, 角色扮演,外语音色,日语 |Poppy |ja_female_bv520_uranus_bigtts |日语 |QA |情感变化、指令遵循 | |
|趣味口音, 角色扮演,外语音色,日语 |Aoi |ja_female_bv521_uranus_bigtts |日语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景, 客服场景,外语音色,日语 |Hana |ja_female_bv522_uranus_bigtts |日语 |QA |情感变化、指令遵循 | |
|趣味口音, 角色扮演,外语音色,日语 |Lily |ja_female_bv523_uranus_bigtts |日语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,日语 |Ken |ja_male_bv524_uranus_bigtts |日语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,日语 |Minimi |ja_female_minimi_uranus_bigtts |日语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|视频配音, 角色扮演,外语音色,日语 |Shirou |ja_female_shirou_uranus_bigtts |日语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,韩语 |Jay |ko_male_bv545_uranus_bigtts |韩语 |QA |情感变化、指令遵循 | |
|视频配音, 角色扮演,外语音色,韩语 |Momo |ko_female_bv546_uranus_bigtts |韩语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,外语音色,韩语 |Minho |ko_male_m03_uranus_bigtts |韩语 |QA |情感变化、指令遵循 | |
|有声阅读, 教学场景, 视频配音,外语音色,韩语 |Shane |ko_male_shane_uranus_bigtts |韩语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|通用场景, 教学场景,外语音色,马来语 |Ham |ms_male_ham_uranus_bigtts |马来语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,外语音色,马来语 |Naim |ms_male_naim_uranus_bigtts |马来语 |QA |情感变化、指令遵循 | |
|教学场景, 视频配音,外语音色,墨西哥西语 |Irene |mx_female_bv065_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,墨西哥西语 |Diego |mx_male_bv165dialogue_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,墨西哥西语 |Marcos |mx_male_bv165narrator_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,墨西哥西语 |Lucy |mx_female_bv166dialogue_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,墨西哥西语 |Rosa |mx_female_bv166emotion_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|有声阅读, 视频配音, 客服场景,外语音色,墨西哥西语 |Freya |mx_female_bv166narrator_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|通用场景,有声阅读,外语音色,墨西哥西语 |Felipe |mx_male_felipe_uranus_bigtts |墨西哥西语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|教学场景, 视频配音,外语音色,墨西哥西语 |Derek |mx_male_ht_mx_m012_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,外语音色,墨西哥西语 |Leslie |mx_female_leslie_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,墨西哥西语 |Marcelo |mx_male_marcelo_uranus_bigtts |墨西哥西语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,外语音色,巴西葡萄牙语 |Sam |pt_male_bv172_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|视频配音,外语音色,巴西葡萄牙语 |Walter |pt_male_bv172dialogue_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|教学场景, 视频配音,外语音色,巴西葡萄牙语 |Vincent |pt_male_bv172emotion_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|有声阅读, 角色扮演,外语音色,巴西葡萄牙语 |Miles |pt_male_bv172narrator_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,外语音色,巴西葡萄牙语 |Diana |pt_female_bv173_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|视频配音, 客服场景,外语音色,巴西葡萄牙语 |Elena |pt_female_bv173dialogue_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,外语音色,巴西葡萄牙语 |Lola |pt_female_bv173emotion_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|视频配音, 客服场景,外语音色,巴西葡萄牙语 |Emma |pt_female_bv173narrator_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,巴西葡萄牙语 |Sofia |pt_female_bv530_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,外语音色,巴西葡萄牙语 |Arthur |pt_male_bv531_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|教学场景, 视频配音,外语音色,巴西葡萄牙语 |Mari |pt_female_mari_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,外语音色,巴西葡萄牙语 |Toby |pt_male_martins_uranus_bigtts |巴西葡萄牙语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |
|教学场景, 视频配音,外语音色,巴西葡萄牙语 |Rael |pt_male_rael_uranus_bigtts |巴西葡萄牙语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,俄语 |Amelia |ru_female_af07_uranus_bigtts |俄语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,俄语 |Irinae |ru_female_irinae_uranus_bigtts |俄语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,俄语 |Pavel |ru_male_pavel_uranus_bigtts |俄语 |QA |情感变化、指令遵循 | |
|通用场景,外语音色,俄语 |Ksenia |ru_female_sophie_uranus_bigtts |俄语 |QA |情感变化、指令遵循 | |
|趣味口音,外语音色,俄语 |Silas |ru_male_vlad_uranus_bigtts |俄语 |QA |情感变化、指令遵循 | |
|教学场景, 视频配音,外语音色,泰语 |Valeria |th_female_bv568_angry_uranus_bigtts |泰语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,泰语 |Iris |th_female_bv568_fear_uranus_bigtts |泰语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,泰语 |Zara |th_female_bv568_happy_uranus_bigtts |泰语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,泰语 |Valentina |th_female_bv568_hate_uranus_bigtts |泰语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,泰语 |Mildred |th_female_bv568_neutral_uranus_bigtts |泰语 |QA |情感变化、指令遵循 | |
|视频配音, 客服场景,外语音色,泰语 |Lydia |th_female_bv568_sad_uranus_bigtts |泰语 |QA |情感变化、指令遵循 | |
|有声阅读,视频配音,外语音色,泰语 |Phoebe |th_female_bv568_suprise_uranus_bigtts |泰语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,菲律宾语 |Annika |tl_female_annika_uranus_bigtts |菲律宾语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,菲律宾语 |Ed |tl_male_ed_uranus_bigtts |菲律宾语 |QA |情感变化、指令遵循 | |
|有声阅读, 视频配音, 客服场景,外语音色,菲律宾语 |Hervie |tl_female_hervie_uranus_bigtts |菲律宾语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,外语音色,越南语 |Hong |vi_female_hong_uranus_bigtts |越南语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,越南语 |Ling |vi_female_ling_uranus_bigtts |越南语 |QA |情感变化、指令遵循 | |
|视频配音,外语音色,越南语 |Linh |vi_female_linh_uranus_bigtts |越南语 |QA |情感变化、指令遵循 | |
|视频配音, 客服场景,外语音色,越南语 |Partner |vi_female_partner_uranus_bigtts |越南语 |QA |情感变化、指令遵循 | |
|通用场景,有声阅读, 角色扮演,外语音色,越南语 |Ruan |vi_female_ruan_uranus_bigtts |越南语 |QA |情感变化、指令遵循 | |
|通用场景, 视频配音,外语音色,越南语 |Wu |vi_female_wu_uranus_bigtts |越南语 |QA |情感变化、指令遵循 | |
|通用场景, 客服场景,外语音色,越南语 |Wumg |vi_male_wumg_uranus_bigtts |越南语 |QA |情感变化、指令遵循 | |
|通用场景, 教学场景,外语音色,意大利语 |Enzo |it_male_enzo_uranus_bigtts |意大利语 |Context |情感变化、上下文遵循 |仅限单向流使用，不支持双向流，双向流调用会直接报错； |


<span id="fb89ea33"></span>
## "端到端实时语音大模型 S2S\-O版本、SC\-2.0版本 "音色列表


|**场景** |**音色名称** |**voice_type** |**语种** |
|---|---|---|---|
|S2S\-Omni |vivi |zh_female_vv_jupiter_bigtts |中文 |
||小何 |zh_female_xiaohe_jupiter_bigtts |中文 |
||云舟 |zh_male_yunzhou_jupiter_bigtts |中文 |
||小天 |zh_male_xiaotian_jupiter_bigtts |中文 |
|SC 2.0版本 |傲娇女友 |saturn_zh_female_aojiaonvyou_tob |中文 |
||病娇姐姐 |saturn_zh_female_bingjiaojiejie_tob |中文 |
||成熟姐姐 |saturn_zh_female_chengshujiejie_tob |中文 |
||可爱女生 |saturn_zh_female_keainvsheng_tob |中文 |
||暖心学姐 |saturn_zh_female_nuanxinxuejie_tob |中文 |
||贴心女友 |saturn_zh_female_tiexinnvyou_tob |中文 |
||温柔文雅 |saturn_zh_female_wenrouwenya_tob |中文 |
||妩媚御姐 |saturn_zh_female_wumeiyujie_tob |中文 |
||性感御姐 |saturn_zh_female_xingganyujie_tob |中文 |
||傲气凌人 |saturn_zh_male_aiqilingren_tob |中文 |
||傲娇公子 |saturn_zh_male_aojiaogongzi_tob |中文 |
||傲娇精英 |saturn_zh_male_aojiaojingying_tob |中文 |
||傲慢少爷 |saturn_zh_male_aomanshaoye_tob |中文 |
||霸道少爷 |saturn_zh_male_badaoshaoye_tob |中文 |
||病娇白莲 |saturn_zh_male_bingjiaobailian_tob |中文 |
||不羁青年 |saturn_zh_male_bujiqingnian_tob |中文 |
||成熟总裁 |saturn_zh_male_chengshuzongcai_tob |中文 |
||磁性男嗓 |saturn_zh_male_cixingnansang_tob |中文 |
||醋精男友 |saturn_zh_male_cujingnanyou_tob |中文 |
||风发少年 |saturn_zh_male_fengfashaonian_tob |中文 |
||腹黑公子 |saturn_zh_male_fuheigongzi_tob |中文 |


<span id="b912c0ff"></span>
##  **"豆包语音合成模型1.0" 音色列表**

<span id="cc4435ee"></span>
### **情感参数（emotion）：**

括号内为对应的情感参数：

**中文音色：** 开心（`happy`），悲伤（`sad`），生气（`angry`），惊讶（`surprised`），恐惧（`fear`），厌恶（`hate`），激动（`excited`），冷漠（`coldness`），中性（`neutral`），沮丧（`depressed`），撒娇（`lovey-dovey`），害羞（`shy`），安慰鼓励（`comfort`），咆哮/焦急（`tension`），温柔（`tender`），讲故事 / 自然讲述（`storytelling`），情感电台（`radio`），磁性（`magnetic`），广告营销（`advertising`），气泡音（`vocal-fry`），低语 (`ASMR`)，新闻播报（`news`），娱乐八卦（`entertainment`），方言（`dialect`）

**英文音色：** 中性（`neutral`），愉悦（`happy`），愤怒（`angry`），悲伤（`sad`），兴奋（`excited`），对话 / 闲聊（`chat`），低语 (`ASMR`)，温暖（`warm`），深情（`affectionate`），权威（`authoritative`）


|**场景** |**音色名称** |**voice_type** |**语种** |**支持的情感** |**特殊标签** |**对应2.0音色** |**是否支持MIX** |
|---|---|---|---|---|---|---|---|
|多情感 |冷酷哥哥（多情感） |zh_male_lengkugege_emo_v2_mars_bigtts |中文 |生气、冷漠、恐惧、开心、厌恶、中性、悲伤、沮丧 | |冷酷哥哥 2.0 |否 |
||甜心小美（多情感） |zh_female_tianxinxiaomei_emo_v2_mars_bigtts |中文 |悲伤、恐惧、厌恶、中性 |剪映同款 | |否 |
||广州德哥（多情感） |zh_male_guangzhoudege_emo_mars_bigtts |中文 |生气、恐惧、中性 |剪映同款 | |是 |
||京腔侃爷（多情感） |zh_male_jingqiangkanye_emo_mars_bigtts |中文 |开心、生气、惊讶、厌恶、中性 |剪映同款 | |是 |
||邻居阿姨（多情感） |zh_female_linjuayi_emo_v2_mars_bigtts |中文 |中性、愤怒、冷漠、沮丧、惊讶 |剪映同款 |邻居阿姨 2.0 |否 |
||优柔公子（多情感） |zh_male_yourougongzi_emo_v2_mars_bigtts |中文 |开心、生气、恐惧、厌恶、激动、中性、沮丧 |剪映同款 |优柔公子 2.0 |否 |
||儒雅男友（多情感） |zh_male_ruyayichen_emo_v2_mars_bigtts |中文 |开心、悲伤、生气、恐惧、激动、冷漠、中性 |剪映同款 |儒雅逸辰 2.0 |否 |
||俊朗男友（多情感） |zh_male_junlangnanyou_emo_v2_mars_bigtts |中文 |开心、悲伤、生气、惊讶、恐惧、中性 |剪映同款 | |否 |
||北京小爷（多情感） |zh_male_beijingxiaoye_emo_v2_mars_bigtts |中文 |生气，惊讶，恐惧，激动，冷漠，中性 | | |否 |
||柔美女友（多情感） |zh_female_roumeinvyou_emo_v2_mars_bigtts |中文 |开心，悲伤，生气，惊讶，恐惧，厌恶，激动，冷漠，中性 | |柔美女友 2.0 |否 |
||阳光青年（多情感） |zh_male_yangguangqingnian_emo_v2_mars_bigtts |中文 |开心，悲伤，生气，恐惧，激动，冷漠，中性 | |阳光青年 2.0 |否 |
||魅力女友（多情感） |zh_female_meilinvyou_emo_v2_mars_bigtts |中文 |悲伤，恐惧，中性 | |魅力女友 2.0 |否 |
||爽快思思（多情感） |zh_female_shuangkuaisisi_emo_v2_mars_bigtts |中文,英式英语 |开心，悲伤，生气，惊讶，激动，冷漠，中性 | |爽快思思 2.0 |否 |
||深夜播客（多情感） |zh_male_shenyeboke_emo_v2_mars_bigtts |中文 |惊讶、悲伤、中性、厌恶、开心、恐惧、激动、沮丧、冷漠、生气 |猫箱同款 |深夜播客 2.0 |否 |
||Candice |en_female_candice_emo_v2_mars_bigtts |美式英语 |深情、愤怒、ASMR、对话/闲聊、兴奋、愉悦、中性、温暖 | | |否 |
|教育场景 |Tina老师 |zh_female_yingyujiaoyu_mars_bigtts |中文,英式英语 | | |Tina老师 2.0 |是 |
|通用场景 |亲切女声 |zh_female_qinqienvsheng_moon_bigtts |中文 | |豆包同款 |亲切女声 2.0 |是 |
||阳光阿辰 |zh_male_qingyiyuxuan_mars_bigtts |中文 | | | |是 |
||快乐小东 |zh_male_xudong_conversation_wvae_bigtts |中文 | |豆包同款 |快乐小东 2.0 |是 |
||开朗学长 |en_male_jason_conversation_wvae_bigtts |中文 | |豆包同款 |开朗学长 2.0 |是 |
||甜美桃子 |zh_female_tianmeitaozi_mars_bigtts |中文 | | |甜美桃子 2.0 |是 |
||清新女声 |zh_female_qingxinnvsheng_mars_bigtts |中文 | | |清新女声 2.0 |是 |
||知性女声 |zh_female_zhixingnvsheng_mars_bigtts |中文 | | |知性女声 2.0 |是 |
||清爽男大 |zh_male_qingshuangnanda_mars_bigtts |中文 | |豆包同款 |清爽男大 2.0 |是 |
||邻家女孩 |zh_female_linjianvhai_moon_bigtts |中文 | |豆包同款 |邻家女孩 2.0 |是 |
||渊博小叔 |zh_male_yuanboxiaoshu_moon_bigtts |中文 | |豆包同款、剪映同款 |渊博小叔 2.0 |是 |
||阳光青年 |zh_male_yangguangqingnian_moon_bigtts |中文 | |豆包同款 |阳光青年 2.0 |是 |
||甜美小源 |zh_female_tianmeixiaoyuan_moon_bigtts |中文 | |豆包同款 |甜美小源 2.0 |是 |
||清澈梓梓 |zh_female_qingchezizi_moon_bigtts |中文 | |豆包同款 |清澈梓梓 2.0 |是 |
||解说小明 |zh_male_jieshuoxiaoming_moon_bigtts |中文 | |豆包同款 |解说小明 2.0 |是 |
||开朗姐姐 |zh_female_kailangjiejie_moon_bigtts |中文 | |豆包同款 |开朗姐姐 2.0 |是 |
||邻家男孩 |zh_male_linjiananhai_moon_bigtts |中文 | |豆包同款 |邻家男孩 2.0 |是 |
||甜美悦悦 |zh_female_tianmeiyueyue_moon_bigtts |中文 | |豆包同款 |甜美悦悦 2.0 |是 |
||心灵鸡汤 |zh_female_xinlingjitang_moon_bigtts |中文 | |豆包同款 |心灵鸡汤 2.0 |是 |
||温柔小哥 |zh_male_wenrouxiaoge_mars_bigtts |中文 | | |温柔小哥 2.0 |是 |
||灿灿/Shiny |zh_female_cancan_mars_bigtts |中文,美式英语 | | |知性灿灿 2.0 |是 |
||爽快思思/Skye |zh_female_shuangkuaisisi_moon_bigtts |中文,美式英语 | |豆包同款 |爽快思思 2.0 |是 |
||温暖阿虎/Alvin |zh_male_wennuanahu_moon_bigtts |中文,美式英语 | |豆包同款 |温暖阿虎/Alvin 2.0 |是 |
||少年梓辛/Brayan |zh_male_shaonianzixin_moon_bigtts |中文,美式英语 | |豆包同款、剪映同款 |少年梓辛/Brayan 2.0 |是 |
|趣味口音 |粤语小溏 |zh_female_yueyunv_mars_bigtts |中文 | | | |是 |
||豫州子轩 |zh_male_yuzhouzixuan_moon_bigtts |中文\-河南口音 | |豆包同款 | |是 |
||呆萌川妹 |zh_female_daimengchuanmei_moon_bigtts |中文\-四川口音 | |豆包同款 | |是 |
||广西远舟 |zh_male_guangxiyuanzhou_moon_bigtts |中文\-广西口音 | |豆包同款 | |是 |
||双节棍小哥 |zh_male_zhoujielun_emo_v2_mars_bigtts |中文\-台湾口音 | |抖音同款、剪映同款、豆包同款 | |否 |
||湾湾小何 |zh_female_wanwanxiaohe_moon_bigtts |中文\-台湾口音 | |豆包同款 |小何 2.0 |是 |
||湾区大叔 |zh_female_wanqudashu_moon_bigtts |中文\-广东口音 | |豆包同款 | |是 |
||广州德哥 |zh_male_guozhoudege_moon_bigtts |中文\-广东口音 | |豆包同款 | |是 |
||浩宇小哥 |zh_male_haoyuxiaoge_moon_bigtts |中文\-青岛口音 | |豆包同款 | |是 |
||北京小爷 |zh_male_beijingxiaoye_moon_bigtts |中文\-北京口音 | |豆包同款 | |是 |
||京腔侃爷/Harmony |zh_male_jingqiangkanye_moon_bigtts |中文\-北京口音,美式英语 | |豆包同款 | |是 |
||妹坨洁儿 |zh_female_meituojieer_moon_bigtts |中文\-长沙口音 | |豆包同款、剪映同款 | |是 |
|角色扮演 |奶气萌娃 |zh_male_naiqimengwa_mars_bigtts |中文 | |剪映同款、豆包同款 |奶气萌娃 2.0 |是 |
||婆婆 |zh_female_popo_mars_bigtts |中文 | |剪映同款、抖音同款、豆包同款 |婆婆 2.0 |是 |
||高冷御姐 |zh_female_gaolengyujie_moon_bigtts |中文 | |豆包同款 |高冷御姐 2.0 |是 |
||傲娇霸总 |zh_male_aojiaobazong_moon_bigtts |中文 | |豆包同款 |傲娇霸总 2.0 |是 |
||魅力女友 |zh_female_meilinvyou_moon_bigtts |中文 | |豆包同款、剪映同款 |魅力女友 2.0 |是 |
||深夜播客 |zh_male_shenyeboke_moon_bigtts |中文 | |豆包同款 |深夜播客 2.0 |是 |
||柔美女友 |zh_female_sajiaonvyou_moon_bigtts |中文 | |豆包同款、剪映同款 |柔美女友 2.0 |是 |
||撒娇学妹 |zh_female_yuanqinvyou_moon_bigtts |中文 | |豆包同款、剪映同款 |撒娇学妹 2.0 |是 |
||东方浩然 |zh_male_dongfanghaoran_moon_bigtts |中文 | |豆包同款 |东方浩然 2.0 |是 |
|外语音色 |Lucas |zh_male_M100_conversation_wvae_bigtts |美式英语 | |豆包同款 | |是 |
||Adam |en_male_adam_mars_bigtts |美式英语 | | | |是 |
||Amanda |en_female_amanda_mars_bigtts |美式英语 | | | |是 |
||Jackson |en_male_jackson_mars_bigtts |美式英语 | | | |是 |
||Daniel |zh_male_xudong_conversation_wvae_bigtts |美式英语 | |豆包同款 | |是 |
||Smith |en_male_smith_mars_bigtts |英式英语 | | | |是 |
||Anna |en_female_anna_mars_bigtts |英式英语 | | | |是 |
||Sarah |en_female_sarah_mars_bigtts |澳洲英语 | | | |是 |
||Dryw |en_male_dryw_mars_bigtts |澳洲英语 | | | |是 |
||Diana |multi_female_maomao_conversation_wvae_bigtts |西语 | | | |否 |
||Lucía |multi_male_M100_conversation_wvae_bigtts |西语 | | | |否 |
||Sofía |multi_female_sophie_conversation_wvae_bigtts |西语 | | | |否 |
||Daníel |multi_male_xudong_conversation_wvae_bigtts |西语 | | | |否 |
||ひかる（光） |multi_zh_male_youyoujunzi_moon_bigtts |日语 | | | |否 |
||さとみ（智美） |multi_female_sophie_conversation_wvae_bigtts |日语 | | | |否 |
||まさお（正男） |multi_male_xudong_conversation_wvae_bigtts |日语 | | | |否 |
||つき（月） |multi_female_maomao_conversation_wvae_bigtts |日语 | | | |否 |
||あけみ（朱美） |multi_female_gaolengyujie_moon_bigtts |日语 | | | |否 |
||かずね（和音）/JavierorÁlvaro |multi_male_jingqiangkanye_moon_bigtts |日语,西语 | | | |否 |
||はるこ（晴子）/Esmeralda |multi_female_shuangkuaisisi_moon_bigtts |日语,西语 | | | |否 |
||ひろし（広志）/Roberto |multi_male_wanqudashu_moon_bigtts |日语,西语 | | | |否 |
|视频配音 |悠悠君子 |zh_male_M100_conversation_wvae_bigtts |中文 | |豆包同款 |悠悠君子 2.0 |是 |
||文静毛毛 |zh_female_maomao_conversation_wvae_bigtts |中文 | |豆包同款 |文静毛毛 2.0 |是 |
||温柔小雅 |zh_female_wenrouxiaoya_moon_bigtts |中文 | |豆包同款 |温柔小雅 2.0 |是 |
||天才童声 |zh_male_tiancaitongsheng_mars_bigtts |中文 | | |天才童声 2.0 |是 |
||猴哥 |zh_male_sunwukong_mars_bigtts |中文 | | |猴哥 2.0 |是 |
||熊二 |zh_male_xionger_mars_bigtts |中文 | |抖音同款、剪映同款、豆包同款 |熊二 2.0 |是 |
||佩奇猪 |zh_female_peiqi_mars_bigtts |中文 | |抖音同款、剪映同款、豆包同款 |佩奇猪 2.0 |是 |
||武则天 |zh_female_wuzetian_mars_bigtts |中文 | |剪映同款 |武则天 2.0 |是 |
||顾姐 |zh_female_gujie_mars_bigtts |中文 | |抖音同款、剪映同款 |顾姐 2.0 |是 |
||樱桃丸子 |zh_female_yingtaowanzi_mars_bigtts |中文 | |剪映同款、抖音同款、豆包同款 |樱桃丸子 2.0 |是 |
||广告解说 |zh_male_chunhui_mars_bigtts |中文 | |剪映同款 |广告解说 2.0 |是 |
||少儿故事 |zh_female_shaoergushi_mars_bigtts |中文 | | |少儿故事 2.0 |是 |
||四郎 |zh_male_silang_mars_bigtts |中文 | |抖音同款、剪映同款、豆包同款 |四郎 2.0 |是 |
||俏皮女声 |zh_female_qiaopinvsheng_mars_bigtts |中文 | | |俏皮女声 2.0 |是 |
||懒音绵宝 |zh_male_lanxiaoyang_mars_bigtts |中文 | | |懒音绵宝 2.0 |是 |
||亮嗓萌仔 |zh_male_dongmanhaimian_mars_bigtts |中文 | | |亮嗓萌仔 2.0 |是 |
||鸡汤妹妹/Hope |zh_female_jitangmeimei_mars_bigtts |中文,美式英语 | |抖音同款、豆包同款 |鸡汤妹妹/Hope 2.0 |是 |
||贴心女声/Candy |zh_female_tiexinnvsheng_mars_bigtts |中文,美式英语 | | |贴心女声/Candy 2.0 |是 |
||萌丫头/Cutey |zh_female_mengyatou_mars_bigtts |中文,美式英语 | | |萌丫头/Cutey 2.0 |是 |
|有声阅读 |悬疑解说 |zh_male_changtianyi_mars_bigtts |中文 | |剪映同款、抖音同款、豆包同款 |悬疑解说 2.0 |是 |
||儒雅青年 |zh_male_ruyaqingnian_mars_bigtts |中文 | |番茄小说同款、豆包同款、剪映同款 |儒雅青年 2.0 |是 |
||霸气青叔 |zh_male_baqiqingshu_mars_bigtts |中文 | |番茄小说同款、豆包同款、剪映同款 |霸气青叔 2.0 |是 |
||擎苍 |zh_male_qingcang_mars_bigtts |中文 | |番茄小说同款、剪映同款、豆包同款、抖音同款 |擎苍 2.0 |是 |
||活力小哥 |zh_male_yangguangqingnian_mars_bigtts |中文 | | |活力小哥 2.0 |是 |
||古风少御 |zh_female_gufengshaoyu_mars_bigtts |中文 | | |古风少御 2.0 |是 |
||温柔淑女 |zh_female_wenroushunv_mars_bigtts |中文 | |番茄小说同款、豆包同款、剪映同款 |温柔淑女 2.0 |是 |
||反卷青年 |zh_male_fanjuanqingnian_mars_bigtts |中文 | | |反卷青年 2.0 |是 |
